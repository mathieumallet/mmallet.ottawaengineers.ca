/*
 * Created on Sep 21, 2005
 */
package fileMover;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

/**
 * @author emh
 *
 * Contains code taken from JFace package for convenience.
 */

public abstract class ButtonsSizer {
	/**
	 * Number of horizontal dialog units per character, value <code>4</code>.
	 */
	private static final int HORIZONTAL_DIALOG_UNIT_PER_CHAR = 4;

	/**
	 * Number of vertical dialog units per character, value <code>8</code>.
	 */
	private static final int VERTICAL_DIALOG_UNITS_PER_CHAR = 8;

	/**
	 * Button width in dialog units (value 61).
	 */
	private static final int BUTTON_WIDTH = 61;	
	
    // Margins, spacings, and sizes
    /**
     * Vertical margin in dialog units (value 7).
     */
    public static final int VERTICAL_MARGIN = 7;

    /**
     * Vertical spacing in dialog units (value 4).
     */
    public static final int VERTICAL_SPACING = 4;

    /**
     * Horizontal margin in dialog units (value 7).
     */
    public static final int HORIZONTAL_MARGIN = 7;

    /**
     * Horizontal spacing in dialog units (value 4).
     */
    public static final int HORIZONTAL_SPACING = 4;
	
	
	public static void setButtonLayoutData(Button button)
	{
		GC gc = new GC(button);
	    gc.setFont(button.getFont());
	    FontMetrics fontMetrics = gc.getFontMetrics();
	    gc.dispose();
		
		GridData data = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
	    int widthHint = convertHorizontalDLUsToPixels(fontMetrics, BUTTON_WIDTH);
	    Point minSize = button.computeSize(SWT.DEFAULT, SWT.DEFAULT, true);
	    data.widthHint = Math.max(widthHint, minSize.x);
	    button.setLayoutData(data);		
	}
	
    private static int convertHorizontalDLUsToPixels(FontMetrics fontMetrics,
            int dlus)
    {
        return (fontMetrics.getAverageCharWidth() * dlus + HORIZONTAL_DIALOG_UNIT_PER_CHAR / 2)
                / HORIZONTAL_DIALOG_UNIT_PER_CHAR;
    }
    
    public static int convertVerticalDLUsToPixels(FontMetrics fontMetrics,
            int dlus) {
        // round to the nearest pixel
        return (fontMetrics.getHeight() * dlus + VERTICAL_DIALOG_UNITS_PER_CHAR / 2)
                / VERTICAL_DIALOG_UNITS_PER_CHAR;
    }
    
    
    /**
     * Creates and returns the contents of this dialog's button bar.
     * <p>
     * The <code>Dialog</code> implementation of this framework method lays
     * out a button bar and calls the <code>createButtonsForButtonBar</code>
     * framework method to populate it. Subclasses may override.
     * </p>
     * <p>
     * The returned control's layout data must be an instance of
     * <code>GridData</code>.
     * </p>
     * 
     * @param parent
     *            the parent composite to contain the button bar
     * @return the button bar control
     */
    protected static Composite createButtonBar(Composite parent)
    {
    	return createButtonBar(parent, true);
    }
    
    protected static Composite createButtonBar(Composite parent, boolean makeColumnsEqualWidth) {
        Composite composite = new Composite(parent, SWT.NONE);
        
        
    	GC gc = new GC(composite);
	    gc.setFont(composite.getFont());
	    FontMetrics fontMetrics = gc.getFontMetrics();
	    gc.dispose();        
        
        // create a layout with spacing and margins appropriate for the font
        // size.
        GridLayout layout = new GridLayout();
        layout.numColumns = 0; // this is incremented by createButton
        layout.makeColumnsEqualWidth = makeColumnsEqualWidth;
        layout.marginWidth = convertHorizontalDLUsToPixels(fontMetrics, HORIZONTAL_MARGIN);
        layout.marginHeight = convertVerticalDLUsToPixels(fontMetrics, VERTICAL_MARGIN);
        layout.horizontalSpacing = convertHorizontalDLUsToPixels(fontMetrics, HORIZONTAL_SPACING);
        layout.verticalSpacing = convertVerticalDLUsToPixels(fontMetrics, VERTICAL_SPACING);
        composite.setLayout(layout);
        GridData data = new GridData(GridData.HORIZONTAL_ALIGN_END
                | GridData.VERTICAL_ALIGN_CENTER);
        composite.setLayoutData(data);
        composite.setFont(parent.getFont());
        // Add the buttons to the button bar.
        //createButtonsForButtonBar(composite);
        return composite;
    }    
    
    protected static void addButton(Composite buttonBar, Button button)
	{
    	GridLayout layout;
    	layout = (GridLayout)buttonBar.getLayout();
    	if (layout != null)
    		layout.numColumns++;
	}
}