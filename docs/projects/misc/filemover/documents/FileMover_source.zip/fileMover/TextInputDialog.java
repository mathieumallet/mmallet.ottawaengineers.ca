package fileMover;

/*******************************************************************************
 * All Right Reserved. Copyright (c) 1998, 2004 Jackwind Li Guojie
 * Modified by Mathieu 'emh_mark3' Mallet
 * 
 * Created on Mar 18, 2004 1:01:54 AM by JACK $Id$
 *  
 ******************************************************************************/
 
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class TextInputDialog extends Dialog {
  String value;

  /**
   * @param parent
   */
  public TextInputDialog(Shell parent) {
    super(parent);
  }

  /**
   * @param parent
   * @param style
   */
  public TextInputDialog(Shell parent, int style) {
    super(parent, style);
  }

  /**
   * Makes the dialog visible.
   * 
   * @return
   */
  public String open(String text)
  {
  	return open(text, "");
  }
  
  public String open(String text, String defaulttext) {
    Shell parent = getParent();
    final Shell shell =
      new Shell(parent, SWT.TITLE | SWT.BORDER | SWT.APPLICATION_MODAL);
    shell.setText("TextInputDialog");

    shell.setLayout(new GridLayout(2, false));

    Label label = new Label(shell, SWT.NULL);
    label.setText(text);

    final Text textbox = new Text(shell, SWT.SINGLE | SWT.BORDER);
    

    final Composite buttonBar = ButtonsSizer.createButtonBar(shell, false);
    ((GridData)buttonBar.getLayoutData()).horizontalSpan = 2;

    final Button buttonOK = new Button(buttonBar, SWT.PUSH);
    buttonOK.setText("Ok");
    shell.setDefaultButton(buttonOK);
    Button buttonCancel = new Button(buttonBar, SWT.PUSH);
    buttonCancel.setText("Cancel");
    
    ButtonsSizer.addButton(buttonBar, buttonOK);
    ButtonsSizer.addButton(buttonBar, buttonCancel);
    ButtonsSizer.setButtonLayoutData(buttonOK);
    ButtonsSizer.setButtonLayoutData(buttonCancel);
    
    textbox.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
    textbox.addListener(SWT.Modify, new Listener() {
      public void handleEvent(Event event) {
        try {
          value = textbox.getText();
          buttonOK.setEnabled(true);
        } catch (Exception e) {
          buttonOK.setEnabled(false);
        }
      }
    });

    buttonOK.addListener(SWT.Selection, new Listener() {
      public void handleEvent(Event event) {
        shell.dispose();
      }
    });

    buttonCancel.addListener(SWT.Selection, new Listener() {
      public void handleEvent(Event event) {
        value = null;
        shell.dispose();
      }
    });
    shell.addListener(SWT.Traverse, new Listener() {
      public void handleEvent(Event event) {
        if(event.detail == SWT.TRAVERSE_ESCAPE)
          event.doit = false;
      }
    });

    //textbox.setText("");
    shell.pack();
    shell.open();
    shell.setSize((int)(shell.getSize().x * 1.5), (int)(shell.getSize().y));
    
    textbox.setText(defaulttext);
    textbox.setSelection(0, textbox.getText().length());

    Display display = parent.getDisplay();
    while (!shell.isDisposed()) {
      if (!display.readAndDispatch())
        display.sleep();
    }

    return value;
  }
  
}