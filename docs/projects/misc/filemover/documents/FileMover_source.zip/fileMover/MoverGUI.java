/*
 * Created on Aug 9, 2005
 */
package fileMover;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.sql.Date;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.*;

/**
 * @author emh
 */
public class MoverGUI {
	Display display;

	Shell shell;

	Label folderName, numSelected;

	Table folderTable;

	TableData[] folderData;

	String currentPath = "";

	ProgressBar progress;

	Menu menu;

	boolean tableSortReverseOrder = false;

	int lastSortedColumn = 0;
	
	final String APP_NAME = "File Mover";
	
	final String IMAGE_DIMENSIONS_UNKNOWN = "Unknown";
	final int DIMENSIONS_COLUMN = 3;
	final int DEFAULT_MIN_NUMBER_OF_FILES_NEEDED_FOR_AUTO_SORT = 5;
	
	int min_number_of_files_needed_for_auto_sort = DEFAULT_MIN_NUMBER_OF_FILES_NEEDED_FOR_AUTO_SORT;
	
	Image programIcon;
	
	// Properties
	int version_major;
	int version_minor;
	String build_date;

	public static void main(String[] args) {
		new MoverGUI().run();
	}

	public void run() {
		// Load version number
		Properties versionProps = new Properties();
		InputStream in = getClass().getClassLoader().getResourceAsStream("version.properties");
		try {
			if (in != null)
			{
				versionProps.load(in);
				in.close();
				version_major = Integer.valueOf(versionProps.getProperty("version_major")).intValue();
				version_minor = Integer.valueOf(versionProps.getProperty("version_minor")).intValue();
				build_date = versionProps.getProperty("build_date");
			}
		}
		catch (IOException e) {}
		
		display = new Display();

		shell = new Shell(display);
		shell.setLayout(new GridLayout());
		shell.setText(APP_NAME);

		InputStream stream = getClass().getClassLoader().getResourceAsStream("filemover.ico");
		if (stream == null)
			stream = getClass().getClassLoader().getResourceAsStream("misc/filemover.ico");
		programIcon = new Image(display, stream);
		shell.setImage(programIcon);

		createContents(shell);

		shell.pack();
		shell.setSize(800, 600);
		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}

		display.dispose();
	}

	private void createContents(Shell shell) {
		createMenus(shell);

		// Create label
		folderName = new Label(shell, SWT.NONE);
		folderName.setText("No folder selected.");
		folderName.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// Create list widget
		folderTable = new Table(shell, SWT.MULTI);

		TableColumn col1 = new TableColumn(folderTable, SWT.LEFT);
		col1.setText("Filename");
		col1.setWidth(200);
		col1.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent arg0) {
			}

			public void widgetSelected(SelectionEvent arg0) {
				sort(0);
			}
		});
		TableColumn col2 = new TableColumn(folderTable, SWT.LEFT);
		col2.setText("Size");
		col2.setWidth(80);
		col2.setAlignment(SWT.RIGHT);
		col2.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent arg0) {
			}

			public void widgetSelected(SelectionEvent arg0) {
				sort(1);
			}
		});
		TableColumn col3 = new TableColumn(folderTable, SWT.LEFT);
		col3.setText("Filetype");
		col3.setWidth(150);
		col3.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent arg0) {
			}

			public void widgetSelected(SelectionEvent arg0) {
				sort(2);
			}
		});
		TableColumn col4 = new TableColumn(folderTable, SWT.LEFT);
		col4.setText("Dimensions");
		col4.setWidth(100);
		col4.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent arg0) {
			}

			public void widgetSelected(SelectionEvent arg0) {
				sort(3);
			}
		});

		TableColumn col5 = new TableColumn(folderTable, SWT.LEFT);
		col5.setText("Last Modification");
		col5.setWidth(150);
		col5.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent arg0) {
			}

			public void widgetSelected(SelectionEvent arg0) {
				sort(4);
			}
		});

		folderTable.setLayoutData(new GridData(GridData.FILL_BOTH));
		folderTable.setHeaderVisible(true);
		folderTable.setLinesVisible(true);
		folderTable.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				SelectionUpdated();
			}
		});

		// Resize first column automatically when control is resized
		folderTable.addControlListener(new ControlListener() {
			public void controlMoved(ControlEvent e) {
			}

			public void controlResized(ControlEvent e) {
				int width, i;
				Table table = (Table) e.getSource();
				if (table == null)
					return;

				width = table.getSize().x;
				for (i = 1; i < table.getColumnCount(); i++)
					width -= table.getColumn(i).getWidth();

				width -= table.getVerticalBar().getSize().x;

				if (width > 0)
					table.getColumn(0).setWidth(width);
			}

		});

		// Create status bar
		Composite statusbar = new Composite(shell, SWT.NONE);
		GridLayout gridlayout = new GridLayout(2, false);
		gridlayout.marginHeight = 0;
		gridlayout.marginWidth = 0;
		statusbar.setLayout(gridlayout);
		statusbar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// Create label
		numSelected = new Label(statusbar, SWT.NONE);
		numSelected.setText("No items selected.");
		numSelected.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// Create progress bar
		progress = new ProgressBar(statusbar, SWT.NONE);
	}

	private void createMenus(Shell shell) {
		// Create menu bar
		menu = new Menu(shell, SWT.BAR);

		// Create menus items for menu bar
		MenuItem fileItem = new MenuItem(menu, SWT.CASCADE);
		fileItem.setText("&File");
		MenuItem listItem = new MenuItem(menu, SWT.CASCADE);
		listItem.setText("&List");
		MenuItem actionItem = new MenuItem(menu, SWT.CASCADE);
		actionItem.setText("&Action");
		MenuItem optionsItem = new MenuItem(menu, SWT.CASCADE);
		optionsItem.setText("&Options");		
		MenuItem helpItem = new MenuItem(menu, SWT.CASCADE);
		helpItem.setText("&Help");		

		// Create file drop down menu
		Menu fileMenu = new Menu(menu);
		fileItem.setMenu(fileMenu);

		// Create sub items for 'File' drop down menu
		MenuItem openFolder = new MenuItem(fileMenu, SWT.NONE);
		openFolder.setText("&Open Folder...");
		openFolder.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				OpenFolder();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		/*
		 * MenuItem openTestFolder = new MenuItem(fileMenu, SWT.NONE);
		 * openTestFolder.setText("Open &Test Folder");
		 * openTestFolder.addSelectionListener(new SelectionListener() { public
		 * void widgetSelected(SelectionEvent e) { ProcessFolder("C:\\Documents
		 * and Settings\\emh\\Desktop\\You Can Delete Me\\comics_test_folder"); }
		 * 
		 * public void widgetDefaultSelected(SelectionEvent e) {} });
		 */
		MenuItem refreshFolder = new MenuItem(fileMenu, SWT.NONE);
		refreshFolder.setText("&Refresh Folder");
		refreshFolder.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				RefreshFolder();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		new MenuItem(fileMenu, SWT.SEPARATOR);
		MenuItem exitItem = new MenuItem(fileMenu, SWT.NONE);
		exitItem.setText("&Exit");
		exitItem.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				Exit();
			}
		});

		// Create list drop down menu
		Menu listMenu = new Menu(menu);
		listItem.setMenu(listMenu);

		// Create sub items for 'List' drop down menu
		MenuItem selectAll = new MenuItem(listMenu, SWT.NONE);
		selectAll.setText("Select &All");
		selectAll.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				folderTable.selectAll();
				SelectionUpdated();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		MenuItem selectNone = new MenuItem(listMenu, SWT.NONE);
		selectNone.setText("Select &None");
		selectNone.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				folderTable.deselectAll();
				SelectionUpdated();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		MenuItem invertSelection = new MenuItem(listMenu, SWT.NONE);
		invertSelection.setText("&Invert Selection");
		invertSelection.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				InvertSelection();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		MenuItem filterSelect = new MenuItem(listMenu, SWT.NONE);
		filterSelect.setText("&Add to selection using filter...");
		filterSelect.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				FilterSelect();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		MenuItem imagesSelect = new MenuItem(listMenu, SWT.NONE);
		imagesSelect.setText("&Select image files");
		imagesSelect.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				ImagesSelect();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		new MenuItem(listMenu, SWT.SEPARATOR);
		MenuItem removeSelectedFromList = new MenuItem(listMenu, SWT.NONE);
		removeSelectedFromList.setText("&Remove selected from list");
		removeSelectedFromList.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				RemoveSelectedFromList();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		MenuItem removeUnSelectedFromList = new MenuItem(listMenu, SWT.NONE);
		removeUnSelectedFromList.setText("&Remove non-selected from list");
		removeUnSelectedFromList.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				RemoveUnSelectedFromList();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		new MenuItem(listMenu, SWT.SEPARATOR);
		MenuItem readImageDimensions = new MenuItem(listMenu, SWT.NONE);
		readImageDimensions.setText("&Read image dimensions (slow)");
		readImageDimensions.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				ReadImageDimensions();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		// Create file drop down menu
		Menu actionMenu = new Menu(menu);
		actionItem.setMenu(actionMenu);

		// Create sub items for 'Action' drop down menu
		MenuItem moveItemsToFolder = new MenuItem(actionMenu, SWT.NONE);
		moveItemsToFolder.setText("&Move selected files...");
		moveItemsToFolder.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				MoveSelectedFiles();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});

		MenuItem quickMoveItemsToFolder = new MenuItem(actionMenu, SWT.NONE);
		quickMoveItemsToFolder.setText("&Quick move selected files...");
		quickMoveItemsToFolder.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				QuickMoveSelectedFiles();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		new MenuItem(actionMenu, SWT.SEPARATOR);
		MenuItem flattenFolders = new MenuItem(actionMenu, SWT.NONE);
		flattenFolders.setText("&Flatten selected folders");
		flattenFolders.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				FlattenFolders();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		new MenuItem(actionMenu, SWT.SEPARATOR);
		MenuItem mergeFolders = new MenuItem(actionMenu, SWT.NONE);
		mergeFolders.setText("&Merge selected folders...");
		mergeFolders.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				MergeFolders();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});		
		MenuItem autoMerge = new MenuItem(actionMenu, SWT.NONE);
		autoMerge.setText("&Auto Merge selected folders");
		autoMerge.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				AutoMergeFolders();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});		

		new MenuItem(actionMenu, SWT.SEPARATOR);
		MenuItem intelligentFileSort = new MenuItem(actionMenu, SWT.NONE);
		intelligentFileSort.setText("&Intelligent File Sort on selected files");
		intelligentFileSort.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				IntelligentFileSort();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		MenuItem autoSortUsingImageDimensions = new MenuItem(actionMenu, SWT.NONE);
		autoSortUsingImageDimensions.setText("&Auto Sort Using Image Dimensions on selected files");
		autoSortUsingImageDimensions.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				AutoSortUsingResolution();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
			
		// Create options drop down menu
		Menu optionsMenu = new Menu(menu);
		optionsItem.setMenu(optionsMenu);

		// Create sub items for 'options' drop down menu
		MenuItem numItemsItem = new MenuItem(optionsMenu, SWT.CASCADE);
		numItemsItem.setText("&Required number of matches for auto sort");
		
		// Create sub items for 'num items' drop down menu
		Menu numItemsMenu = new Menu(optionsMenu);
		numItemsItem.setMenu(numItemsMenu);
		int numItemsValues[] = {1, 2, 5, 10, 20, 50, 100, 500};
		MenuItem item;
		for (int i = 0; i < numItemsValues.length; i++)
		{
			item = new MenuItem(numItemsMenu, SWT.RADIO);
			item.setText(String.valueOf(numItemsValues[i]));
			
			if (numItemsValues[i] == DEFAULT_MIN_NUMBER_OF_FILES_NEEDED_FOR_AUTO_SORT)
				item.setSelection(true);
			
			item.addSelectionListener(new SelectionListener() {
				public void widgetSelected(SelectionEvent e) {
					min_number_of_files_needed_for_auto_sort = Integer.valueOf(((MenuItem)e.getSource()).getText()).intValue();
				}

				public void widgetDefaultSelected(SelectionEvent e) {
				}
			});
		}
		
		// Create help drop down menu
		Menu helpMenu = new Menu(menu);
		helpItem.setMenu(helpMenu);

		// Create sub items for 'Help' drop down menu
		MenuItem instructions = new MenuItem(helpMenu, SWT.NONE);
		instructions.setText("&Instructions...");
		instructions.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				Instructions();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		MenuItem about = new MenuItem(helpMenu, SWT.NONE);
		about.setText("&About...");
		about.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				About();
			}

			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		
		// Set menu bar
		shell.setMenuBar(menu);
	}

	private void Exit() {
		shell.dispose();
	}

	private void sort(int column) {
		Object item1, item2;
		String text1, text2;
		int sortModifier;
		
		if (folderData == null)
			return;

		if (lastSortedColumn == column)
			tableSortReverseOrder = !tableSortReverseOrder;
		else
			tableSortReverseOrder = false;
		lastSortedColumn = column;

		if (tableSortReverseOrder)
			sortModifier = 1;
		else
			sortModifier = -1;

		Arrays.sort(folderData, new TableDataComparator(column,
				tableSortReverseOrder));

		RefreshTable();
	}

	public void OpenFolder() {
		DirectoryDialog dialog = new DirectoryDialog(shell, SWT.NONE);
		dialog.setFilterPath(currentPath);
		String path = dialog.open();
		if (path == null)
			return;

		ProcessFolder(path);
	}

	public void RefreshFolder() {
		if (!currentPath.equalsIgnoreCase(""))
			ProcessFolder(currentPath);
	}

	private String SizeAsString(long size) {
		return String.valueOf(size / 1024) + " KB";
	}

	private void ReadImageDimensions() {
		if (folderData == null)
			return;

		File file;
		numSelected.setText("Loading image dimensions...");
		SetupLongEvent(folderData.length);
		String[] text;
		for (int i = 0; i < folderData.length; i++) {
			if (!folderData[i].dimensions.equalsIgnoreCase(IMAGE_DIMENSIONS_UNKNOWN))
				continue;
			
			UpdateLongEvent(i);
			file = new File(folderData[i].path + "\\" + folderData[i].filename);
			folderData[i].dimensions = GetImageSize(file);

			// Update size as we're reading
			folderTable.getItem(i).setText(3, folderData[i].dimensions);
		}
		EndLongEvent();
		SelectionUpdated();
	}

	private String GetImageSize(File file) {
		// Check if we should even try getting image height
		String extension = file.toString();
		if (extension.length() < 4)
			return "(Not an image file)";
		extension = extension.substring(extension.length() - 4, extension
				.length());
		if (!extension.equalsIgnoreCase(".gif")
				&& !extension.equalsIgnoreCase(".png")
				&& !extension.equalsIgnoreCase(".jpg")
				&& !extension.equalsIgnoreCase("jpeg"))
			return "(Not an image file)";

		try {
			FileInputStream stream = new FileInputStream(file);
			FileChannel channel = stream.getChannel();
			ByteBuffer buf = ByteBuffer.allocate((int) channel.size());
			channel.read(buf);

			ImageIcon icon = new ImageIcon(buf.array());
			
			// Close image
			channel.close();
			stream.close();
			
			int width = icon.getIconWidth();
			if (width < 0)
				return "(Unable to read image)";
			return String.valueOf(width) + " x "
					+ String.valueOf(icon.getIconHeight());

		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}
		return "(Error reading image)";
	}

	private void ProcessFolder(String path) {
		File folder = new File(path);
		String[] files = folder.list();

		// Set references
		currentPath = path;
		folderName.setText(path);

		// Clear data
		folderData = new TableData[files.length];

		// Add items to table
		File file;
		JFileChooser chooser = new JFileChooser();
		numSelected.setText("Loading folder information...");
		progress.setMaximum(folderData.length);

		for (int i = 0; i < files.length; i++) {
			progress.setSelection(i);
			file = new File(path + "\\" + files[i]);
			folderData[i] = new TableData();
			folderData[i].filename = files[i];
			folderData[i].path = path;
			folderData[i].fileSize = file.length();
			folderData[i].dimensions = IMAGE_DIMENSIONS_UNKNOWN;
			folderData[i].fileType = chooser.getTypeDescription(file);
			folderData[i].lastModified = file.lastModified();
			folderData[i].bIsFolder = file.isDirectory();
		}
		progress.setSelection(0);
		RefreshTable();
	}

	public void RefreshTable() {
		folderTable.clearAll();
		folderTable.setItemCount(0);

		if (folderData == null)
			return;

		TableItem item;

		numSelected.setText("Updating display...");
		for (int i = 0; i < folderData.length; i++) {
			item = new TableItem(folderTable, 0);
			item.setText(new String[] { folderData[i].filename,
					SizeAsString(folderData[i].fileSize),
					folderData[i].fileType, folderData[i].dimensions,
					LastModifiedAsString(folderData[i].lastModified) });
			if (folderData[i].bIsFolder)
				item.setForeground(new Color(display, 0,0,192));
		}
		SelectionUpdated();
	}

	public void InvertSelection() {
		int[] selection = folderTable.getSelectionIndices();
		folderTable.selectAll();
		folderTable.deselect(selection);
		SelectionUpdated();
	}

	public void RemoveSelectedFromList() {
		if (folderTable.getSelectionCount() == 0)
			return;

		InvertSelection();

		numSelected.setText("Removing selected...");

		int count = 0;
		int[] indices = folderTable.getSelectionIndices();
		TableData[] newData = new TableData[indices.length];
		for (int i = 0; i < indices.length; i++)
			newData[i] = folderData[indices[i]];
		folderData = newData;

		RefreshTable();
	}

	public void RemoveUnSelectedFromList() {
		InvertSelection();
		RemoveSelectedFromList();
	}

	public void QuickMoveSelectedFiles() {
		if (folderTable.getSelectionCount() == 0)
			return;

		int[] indices = folderTable.getSelectionIndices();
		TextInputDialog dialog = new TextInputDialog(shell);
		String filter = dialog.open("Enter target folder name:",
				getSuggestedFilename(folderData[indices[0]].filename, folderData[indices[0]].bIsFolder));
		if (filter == null)
			return;

		String folderPath = folderData[indices[0]].path + "\\" + filter;
		File file = new File(folderPath);
		file.mkdir();
		
		if (file.exists())
			MoveSelectedFilesTo(folderPath);
	}

	public void MoveSelectedFiles() {
		if (folderTable.getSelectionCount() == 0)
			return;

		DirectoryDialog dialog = new DirectoryDialog(shell, SWT.NONE);
		dialog.setFilterPath(currentPath);
		dialog.setText("Select a target folder");
		String path = dialog.open();
		if (path == null)
			return;

		MoveSelectedFilesTo(path);
	}

	public void MoveSelectedFilesTo(String path) {
		int[] indices = folderTable.getSelectionIndices();
		File file;
		numSelected.setText("Moving files...");
		progress.setMaximum(indices.length);
		for (int i = 0; i < indices.length; i++) {
			progress.setSelection(i);
			file = new File(folderData[indices[i]].path + "\\"
					+ folderData[indices[i]].filename);
			file.renameTo(new File(path + "\\"
					+ folderData[indices[i]].filename));
		}
		progress.setSelection(0);
		RemoveSelectedFromList();
	}
	
	public void FlattenFolders()
	{
		if (folderTable.getSelectionCount() == 0)
			return;
		
		int[] indices = folderTable.getSelectionIndices();
		numSelected.setText("Flattening selected folders...");
		progress.setMaximum(indices.length);
		String sourceFolder, targetFolder;
		File folder, file;
		String[] files;
		targetFolder = folderData[indices[0]].path;
		for (int i = 0; i < indices.length; i++) {
			progress.setSelection(i);
			if (!folderData[indices[i]].bIsFolder)
				continue;
			
			sourceFolder = folderData[indices[i]].path + "\\" + folderData[indices[i]].filename;
			
			folder = new File(sourceFolder);
			files = folder.list();
			for (int j = 0; j < files.length; j++)
			{
				file = new File(sourceFolder + "\\" + files[j]);
				file.renameTo(new File(targetFolder + "\\" + files[j]));
			}
			files = folder.list();
			if (files.length == 0)
				folder.delete();
		}
		
		progress.setSelection(0);
		RefreshFolder();
	}
	
	public void AutoMergeFolders()
	{
		if (folderTable.getSelectionCount() < 2)
			return;
		
		int[] indices = folderTable.getSelectionIndices();
		String targetFolder = folderData[indices[0]].path + "\\" + folderData[indices[0]].filename;
		MergeFolders(targetFolder);
	}
	
	public void MergeFolders()
	{
		if (folderTable.getSelectionCount() < 2)
			return;
		
		int[] indices = folderTable.getSelectionIndices();
		TextInputDialog dialog = new TextInputDialog(shell);
		String filter = dialog.open("Enter target folder name:",
				getSuggestedFilename(folderData[indices[0]].filename, folderData[indices[0]].bIsFolder));
		if (filter == null)
			return;

		String folderPath = folderData[indices[0]].path + "\\" + filter;
		File file = new File(folderPath);
		file.mkdir();
		
		if (file.exists())
			MergeFolders(folderPath);
	}
	
	public void MergeFolders(String targetFolder)
	{
		if (folderTable.getSelectionCount() < 2)
			return;
		
		int[] indices = folderTable.getSelectionIndices();
		numSelected.setText("Merging selected folders...");
		progress.setMaximum(indices.length);
		String sourceFolder;
		File folder, file;
		String[] files;
		
		for (int i = 0; i < indices.length; i++) {
			progress.setSelection(i);
			if (!folderData[indices[i]].bIsFolder)
				continue;
			
			sourceFolder = folderData[indices[i]].path + "\\" + folderData[indices[i]].filename;
			if (sourceFolder.compareTo(targetFolder) == 0)
				continue;
			
			folder = new File(sourceFolder);
			files = folder.list();
			for (int j = 0; j < files.length; j++)
			{
				file = new File(sourceFolder + "\\" + files[j]);
				file.renameTo(new File(targetFolder + "\\" + files[j]));
			}
			files = folder.list();
			if (files.length == 0)
				folder.delete();
		}
		
		progress.setSelection(0);
		RefreshFolder();
	}

	public void FilterSelect() {
		if (folderData == null || folderData.length == 0)
			return;
		
		TextInputDialog dialog = new TextInputDialog(shell);
		String filter = dialog.open("Enter filtering text:");
		if (filter == null)
			return;
		
		for (int i = 0; i < folderData.length; i++)
			if (folderData[i].filename.indexOf(filter) != -1)
				folderTable.select(i);

		SelectionUpdated();
	}
	
	public void ImagesSelect()
	{
		folderTable.deselectAll();
		
		if (folderData == null || folderData.length == 0)
			return;
		
		String[] splits;
		String extension;
		for (int i = 0; i < folderData.length; i++)
		{
			splits = folderData[i].filename.split("\\.");
			if (splits.length > 1)
			{
				extension = splits[splits.length - 1].toLowerCase();
				if (extension.matches("jpg"))
					folderTable.select(i);
				else if (extension.matches("jpeg"))
					folderTable.select(i);
				else if (extension.matches("bmp"))
					folderTable.select(i);
				else if (extension.matches("png"))
					folderTable.select(i);
				else if (extension.matches("gif"))
					folderTable.select(i);
				else if (extension.matches("tif"))
					folderTable.select(i);
				else if (extension.matches("tiff"))
					folderTable.select(i);
			}
		}
		
		SelectionUpdated();
	}

	public void SelectionUpdated() {
		int count = folderTable.getSelectionCount();
		if (count == 0)
			numSelected.setText("No items selected.");
		else if (count == 1)
			numSelected.setText("1 item selected.");
		else
			numSelected.setText(count + " items selected.");
	}

	public String LastModifiedAsString(long lastModified) {
		DateFormat formatter = DateFormat.getDateTimeInstance();
		return formatter.format(new Date(lastModified));
	}

	public void SetupLongEvent(int numEvents) {
		progress.setMaximum(numEvents);

		// Disable menus
		menu.setEnabled(false);
		for (int i = 0; i < menu.getItemCount(); i++)
			menu.getItem(i).setEnabled(false);
	}

	public void UpdateLongEvent(int current) {
		if (display.isDisposed())
			return;
		progress.setSelection(current);
		display.readAndDispatch();
	}

	public void EndLongEvent() {
		progress.setSelection(0);

		// Enable menus
		menu.setEnabled(true);
		for (int i = 0; i < menu.getItemCount(); i++)
			menu.getItem(i).setEnabled(true);
	}

	public void IntelligentFileSort() {
		int i, k, p, originalNumFiles;
		String matchingPattern;
		String targetFolder;
		File file;

		// Only keep selected files in list
		InvertSelection();
		RemoveSelectedFromList();

		// Can't do anything if there's not at least 2 files selected
		if (folderData == null || folderData.length < 2)
			return;

		// Setup progress bar
		numSelected.setText("Initializing Intelligent File Sort...");
		progress.setMaximum(folderData.length);

		// Scan all files
		numSelected.setText("Scanning files for matching patterns...");
		String matchingPatterns[] = new String[folderData.length]; // What the
																   // matching
																   // pattern is
		int matchingIndex[] = new int[folderData.length]; // Tells which file
														  // index this file
														  // matches with
		int matchingCharacters[] = new int[folderData.length]; // How many
															   // characters
															   // were matched
		originalNumFiles = folderData.length;

		// Initialize indexes to -1
		for (i = 0; i < folderData.length; i++)
			matchingIndex[i] = -1;

		// No point in checking last file -- it won't match the next one since
		// there is no next one
		i = 0;
		while (i < folderData.length - 1) {
			// Set progress
			progress.setSelection(i);

			matchingPattern = folderData[i].filename;
			
			// Strip extension from filename (but only if it's not a folder)
			if (!folderData[i].bIsFolder)
				matchingPattern = removeExtension(matchingPattern);

			// Get acceptable pattern from filename
			matchingPattern = getAcceptablePattern(matchingPattern);

			// Store matching pattern for future use
			matchingPatterns[i] = matchingPattern;

			// Check if next file matches pattern
			k = i + 1;
			while (k < folderData.length) {
				if (folderData[k].filename.regionMatches(0, matchingPattern, 0,
						matchingPattern.length())) {
					// The next file matches pattern. Check if this match is
					// better than any previously recorded match
					if (matchingCharacters[k] < matchingPattern.length())
					{
						if (matchingCharacters[k] > 0
								&& k != folderData.length - 1)
						{
							// There were some matches made further down the
							// list -- remove them.
							for (p = k + 1; p < folderData.length; p++)
								matchingCharacters[p] = 0;
						}

						// Mark that we had a match on this file.
						matchingCharacters[k] = matchingPattern.length();
						matchingIndex[k] = i;
						matchingPatterns[k] = matchingPattern;
					}
					else
						break; // stop checking for matches
				}
				else
					break; // stop checking for matches
				
				k++;
			}

			i++;
		}

		// Print match list
		/*for (i = 0; i < folderData.length; i++)
			System.out.println("File " + i + " matched "
					+ matchingCharacters[i] + " characters with string "
					+ matchingIndex[i] + " (matching pattern was "
					+ matchingPatterns[i]);*/

		// Go through list backwards
		i = folderData.length - 1;
		numSelected.setText("Moving files into proper folders...");
		while (i >= 0) {
			progress.setSelection(originalNumFiles - i);

			if (matchingIndex[i] != -1 &&
					i - matchingIndex[i] + 1 >= min_number_of_files_needed_for_auto_sort) {

				// We want to move the files k to i inclusively
				k = matchingIndex[i];

				// Create folder to move files to
				targetFolder = getTargetFolderFromMatchingPattern(matchingPatterns[k]);
				numSelected.setText("Moving " + (i - k + 1)
						+ " files into folder '" + targetFolder + "'...");
				targetFolder = folderData[i].path + "\\" + targetFolder;
				file = new File(targetFolder);
				file.mkdir();

				// Move files to newly-created folder
				for (p = k; p <= i; p++) {
					file = new File(folderData[p].path + "\\"
							+ folderData[p].filename);
					file.renameTo(new File(targetFolder + "\\"
							+ folderData[p].filename));
				}

				i = k;
				numSelected.setText("Moving files into proper folders...");
			} else
				i--;
		}

		// Intelligent File Sort completed.
		progress.setSelection(0);
		RefreshFolder();
	}

	public String removeExtension(String filename) {
		if (filename.indexOf(".") == -1)
			return filename;

		return filename.substring(0, filename.indexOf("."));
	}

	public String getAcceptablePattern(String pattern) {
		String resultPattern;
		boolean bOneDigitFound = false;
		resultPattern = pattern;
		
		bOneDigitFound = true;
		for (int i = 0; i < pattern.length(); i++)
			if (Character.isDigit(pattern.charAt(i)))
				bOneDigitFound = false;
		
		while (resultPattern.length() > 1) {
			if (Character.isDigit((resultPattern.charAt(resultPattern.length() - 1))))
			{
				resultPattern = resultPattern.substring(0, resultPattern.length() - 1);
				bOneDigitFound = true;
			}
			else if (resultPattern.charAt(resultPattern.length() - 1) == '-' || !bOneDigitFound)
			{
				resultPattern = resultPattern.substring(0, resultPattern.length() - 1);
			}
			else
				break;
		}

		// Get a better pattern by removing non-alphanumerical characters from
		// the end of the string
		resultPattern = stripNonAlphaNumFromEnd(resultPattern);

		return resultPattern;
	}

	public String getTargetFolderFromMatchingPattern(String pattern) {
		String result = pattern;

		// Remove common '_p' pattern from end of filename
		if (result.length() > 2)
			if (result.substring(result.length() - 2, result.length())
					.equalsIgnoreCase("_p"))
				result = result.substring(0, result.length() - 2);

		// Replace _ by spaces
		result = result.replace('_', ' ');

		// Remove any non-alphanumeric characters from the end of the pattern
		result = stripNonAlphaNumFromEnd(result);

		return result;
	}

	public String stripNonAlphaNumFromEnd(String pattern) {
		String result = pattern;
		char c;
		while (result.length() > 1) {
			c = result.charAt(result.length() - 1);
			if (Character.isLetterOrDigit(c))
				break;
			else
				result = result.substring(0, result.length() - 1);
		}
		return result;
	}
	
	public String getSuggestedFilename(String filename, boolean bIsFolder)
	{
		String result = filename;
		if (bIsFolder)
			filename = removeExtension(filename);

		// Get acceptable pattern from filename
		filename = getAcceptablePattern(filename);
		
		return filename;
	}
	
	public String GetAboutText()
	{
		String text = APP_NAME + "\n";
		text += "Version " + version_major + "." + version_minor + ", built on " + build_date + "\n\n";
		text += "Copyright 2005 Mathieu Mallet\n";
		text += "Visit http://mmallet.ottawaengineers.ca/ for more information.";
		
		return text;
	}
	
	public StyleRange GetAboutStyleRange()
	{
		StyleRange style = new StyleRange();
		style.start = 0;
		style.length = APP_NAME.length();
		style.fontStyle = SWT.BOLD + SWT.ITALIC;
		return style;
	}	
	
	private void About()
	{
		// Create new dialog
		Shell myShell = new Shell(display, SWT.APPLICATION_MODAL + SWT.DIALOG_TRIM);
		myShell.setLayout(new GridLayout());
		myShell.setText("About " + APP_NAME);
		myShell.setImage(programIcon);
		
		// Create image
		//InputStream stream = getClass().getClassLoader().getResourceAsStream("morpheus_splash.jpg");
		//Image splash = new Image(display, stream);
		//Label image = new Label(myShell, SWT.NONE);
		//image.setImage(splash);
			
		// Create text box
		StyledText textBox = new StyledText(myShell, SWT.WRAP);
		textBox.setText(GetAboutText());
		textBox.setStyleRange(GetAboutStyleRange());
		textBox.setEditable(false);
		textBox.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		textBox.setBackground(myShell.getBackground());
		
		// Create separator
		Label bar = new Label(myShell, SWT.HORIZONTAL | SWT.SEPARATOR);
		bar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		// Create button bar
		Composite buttonBar = ButtonsSizer.createButtonBar(myShell);
		
		// Create close button
		Button close = new Button(buttonBar, SWT.NONE);
		close.setText("Close");
		close.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				((Button)e.getSource()).getParent().getParent().dispose();
			}
			
			public void widgetDefaultSelected(SelectionEvent e) {}				
		});
		myShell.setDefaultButton(close);
		ButtonsSizer.setButtonLayoutData(close);
		ButtonsSizer.addButton(buttonBar, close);
		
		myShell.pack();
		myShell.open();			
	}	
	
	private void Instructions()
	{
		// Create new dialog
		Shell myShell = new Shell(display, SWT.APPLICATION_MODAL + SWT.DIALOG_TRIM);
		myShell.setLayout(new GridLayout());
		myShell.setText("Using " + APP_NAME);
		myShell.setImage(programIcon);
		
		// Create image
		//InputStream stream = getClass().getClassLoader().getResourceAsStream("morpheus_splash.jpg");
		//Image splash = new Image(display, stream);
		//Label image = new Label(myShell, SWT.NONE);
		//image.setImage(splash);
			
		// Create text box
		StyledText textBox = new StyledText(myShell, SWT.WRAP + SWT.V_SCROLL);
		textBox.setText(GetInstructionsText());
		textBox.setStyleRange(GetAboutStyleRange());
		textBox.setEditable(false);
		textBox.setLayoutData(new GridData(GridData.FILL_HORIZONTAL + GridData.FILL_VERTICAL));
		textBox.setBackground(myShell.getBackground());
		
		
		// Create separator
		Label bar = new Label(myShell, SWT.HORIZONTAL | SWT.SEPARATOR);
		bar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		// Create button bar
		Composite buttonBar = ButtonsSizer.createButtonBar(myShell);
		
		// Create close button
		Button close = new Button(buttonBar, SWT.NONE);
		close.setText("Close");
		close.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				((Button)e.getSource()).getParent().getParent().dispose();
			}
			
			public void widgetDefaultSelected(SelectionEvent e) {}				
		});
		myShell.setDefaultButton(close);
		ButtonsSizer.setButtonLayoutData(close);
		ButtonsSizer.addButton(buttonBar, close);
		
		myShell.setSize(400, 300);
		//myShell.pack();
		myShell.open();			
	}	
	
	public String GetInstructionsText()
	{
		String text = APP_NAME + "\n\n";
		text += APP_NAME + " is an application used to sort similar files. In addition to " +
				"providing various tools to aid in the sorting of files, " + APP_NAME +
				" includes automatic sorting tools.\n\n";

		text += "To begin, open the folder which contains the files which are to be sorted. " +
				"This is done by using the 'File\\Open Folder...' command. Note that it might take " +
				"a while to load the folder content if the folder contains many files.\n\n";
		
		text += "Once a folder has been opened, the menu items from the 'List' menu can be used " +
				"to modify the file list. Note that none of the items in the List have any effect on " +
				"the actual files -- they only operate on the in-memory list of files.\n\n";

		text += "After having selected the files on which you want to work on, the 'Action' menu can " +
				"be used to perform actions on those files. Here are the descriptions of the various " +
				"commands available:\n\n";
		text += "- Move Selected Files:  Moves the selected files to a folder of your choice.\n\n";
		text += "- Quick Move Selected Files:  Creates, in the current folder, a folder with the " +
				"name of your choice, after which the selected files are moved to the newly " +
				"created folder.\n\n";
		text += "- Flatten Selected Folders:  Moves all the files contained in the selected folder " +
				"into the current folder. The selected folders are then removed.\n\n";
		text += "- Merge Selected Folders:  Moves the content of the selected folders into the " +
				"folder of your choice. The selected folders are then removed.\n\n";
		text += "- Auto Merge Selected Folders:  Moves the content of the selected folders into the " +
				"first selected folder (first in the selected folders list). The selected " +
				"folders are then removed, with the exception of the first folder.\n\n";
		text += "- Intelligent File Sort:  Automatically sorts files based on their filename. " +
				"Folders are automatically created to contain similar files.\n\n";
		text += "- Auto Sort Using Image Dimensions:  Similar to Intelligent File Sort. Automatically creates " +
				"folders for selected images based on image dimensions. Images with identical dimensions " +
				"are placed in the same folder.";
		
		return text;
	}
	
	public void AutoSortUsingResolution()
	{
		// Can't do anything if there's not at least 2 files selected
		if (folderData == null || folderData.length < 1 || folderTable.getSelectionCount() == 0)
			return;		
		
		// Change file list to have only selected files
		InvertSelection();
		RemoveSelectedFromList();
		
		// Check if selected filenames have their resolution in memory
		boolean bLacksResolution = false;
		for (int i = 0; i < folderData.length; i++)
			if (folderData[i].dimensions.equalsIgnoreCase(IMAGE_DIMENSIONS_UNKNOWN))
			{
				bLacksResolution = true;
				break;
			}
		
		if (bLacksResolution)
		{
			// Ask user if he wants to read images dimensions
			MessageBox msg = new MessageBox(shell,
					SWT.YES | SWT.NO | SWT.ICON_QUESTION | SWT.APPLICATION_MODAL);
			msg.setText("Image dimensions missing");
			msg.setMessage("The image dimensions data is missing. That data is required " +
					"to perform a sort based on image dimensions.\n\nDo you want to " +
					"read the image dimensions now? (Warning: This process can take " +
					"a long while)");
			if (msg.open() == SWT.YES)
				ReadImageDimensions();
			else
				return;			
		}
		
		// Check if at least one selected file has a resolution available
		boolean bHasResolution = false;
		for (int i = 0; i < folderData.length; i++)
			if (folderData[i].dimensions.charAt(0) != '(')
			{
				bHasResolution = true;
				break;
			}
			
	    // Sort array based on image dimensions
		numSelected.setText("Sorting images based on dimensions...");
		Arrays.sort(folderData, new TableDataComparator(DIMENSIONS_COLUMN, false));
		
		// Print files + dimensions list
		for (int i = 0; i < folderData.length; i++)
			System.out.println("File: " + folderData[i].filename + ", Dimensions: " + folderData[i].dimensions);

		// Search for the first resolution
		String currentResolution, folderName, targetFolder;
		File file;
		int k;
		numSelected.setText("Auto sorting images...");
		progress.setMaximum(folderData.length);
		for (int i = 0; i < folderData.length; i++)
		{
			//System.out.println("Entering loop, i = " + i);
			progress.setSelection(i);
			currentResolution = folderData[i].dimensions;
			if (currentResolution.charAt(0) != '(')
			{
				// check if there's at least 5 images that match this
				if (i + min_number_of_files_needed_for_auto_sort - 1 >= folderData.length)
					continue;
				else if (!folderData[i + min_number_of_files_needed_for_auto_sort - 1]
									 .dimensions.equalsIgnoreCase(currentResolution))
					continue;
				
				// Create a folder with appropriate name
				folderName = "Serie - Resolution (" + currentResolution + ")";
				//System.out.println("Creating folder: '" + folderName + "'");
				folderName = folderData[i].path + "\\" + folderName;
				file = new File(folderName);
				file.mkdir();
				
				// Move files to that folder
				k = i;
				while (true)
				{
					file = new File(folderData[k].path + "\\"
						+ folderData[k].filename);
					file.renameTo(new File(folderName + "\\"
						+ folderData[k].filename));
					
					//System.out.println("Moving " + folderData[k].filename);
					
					k++;
					
					// Check if next file should be moved too
					if (k == folderData.length ||
							!folderData[k].dimensions.equalsIgnoreCase(currentResolution))
						break;
					
					progress.setSelection(k);
				}
				i = k - 1;
				//System.out.println("Finished moving, i = " + i);
			}
		}
		
		// Sort completed.
		progress.setSelection(0);
		RefreshFolder();			
	}
	
}
