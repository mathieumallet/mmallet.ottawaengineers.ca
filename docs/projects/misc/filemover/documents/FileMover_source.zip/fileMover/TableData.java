/*
 * Created on Aug 10, 2005
 */
package fileMover;

/**
 * @author emh
 */
public class TableData {
	public String filename;
	public String path;
	public long fileSize;
	public String dimensions;
	public int width;
	public int height;
	public String fileType;
	public long lastModified;
	public boolean bIsFolder;
}
