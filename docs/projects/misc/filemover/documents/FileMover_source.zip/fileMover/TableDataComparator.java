/*
 * Created on Aug 10, 2005
 */
package fileMover;

import java.util.*;

public class TableDataComparator implements Comparator
{
	int column;
	boolean bReverseSort;
	public TableDataComparator(int column, boolean bReverseSort)
	{
		this.column = column;
		this.bReverseSort = bReverseSort;
	}
	
	public int compare(Object o1, Object o2) {
		if (o1 == o2)
			return 0;
		
		TableData a, b;
		a = (TableData)o1;
		b = (TableData)o2;
		if (a == null || b == null)
			return 0;
		
		int sortModifier;
		if (bReverseSort)
			sortModifier = -1;
		else
			sortModifier = 1;
		
		switch (column)
		{
			case 0: // filename
				return (a.filename.compareToIgnoreCase(b.filename)) * sortModifier;
			case 1: // size
				return (new Long(a.fileSize).compareTo(new Long(b.fileSize))) * sortModifier;
			case 2: // filetype
				return (a.fileType.compareToIgnoreCase(b.fileType)) * sortModifier;
			case 3: // dimensions
				return (a.dimensions.compareToIgnoreCase(b.dimensions)) * sortModifier;
			case 4: // last modified
				return (new Long(a.lastModified).compareTo(new Long(b.lastModified))) * sortModifier;			
				
		}
		
		
		return 0;
		
	}
}
