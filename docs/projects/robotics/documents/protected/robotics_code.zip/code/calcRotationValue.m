function result = calcRotationValue(whichOne, angle)
%CALCROTATIONVALUE Calculate actual actuator value for the robot based on
%an angle (in radians)
%
%   CALCROTATIONVALUE(N,a) Turns the actuator #N to the angle a
%
%   Note that the returned value might be impossible to reach -- the
%   actuators can only receive values between -1400 and 1400.

temp = angle * 180/pi;

switch whichOne
    case 1
        result = round(-18.66666666*angle+37.333333333);
    case 2
        result = round(-16.09195402*angle-32.18);
    case 3 
        result = round(-16.37426901*angle+24.5614035);
    case 4
        result = round(16.37426901*angle+40.93567251);
    case 5
        result = round(-15.45*angle-145);
end