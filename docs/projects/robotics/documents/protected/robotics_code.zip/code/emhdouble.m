function D = emhdouble(X)
%EMHDOUBLE Converts symbolic matrix to MATLAB double.
%   EMHDOUBLE(S) converts the symbolic matrix S to a matrix of double
%   precision floating point numbers.  S must not contain any symbolic
%   variables, except 'eps'.
%
%   See also SYM, VPA.
%
%   Update by Mathieu Mallet: Fixed a problem with symbolics

%   Copyright 1993-2002 The MathWorks, Inc.
%   $Revision: 1.21 $  $Date: 2002/03/13 14:05:07 $
%

if ~isempty(findstr('eps',char(X)))
   X = subs(X,'eps',eps);
end

d = digits;
if d ~= 32
   digits(32);
end

T = X;
[X,stat] = maple('evalf',X);
if stat | findstr(char(X),'NaN')
   X = T;
   for k = 1:prod(size(X))
      [X(k),stat] = maple('evalf',X(k));
      if stat | findstr(char(X(k)),'NaN')
         if strcmp(X(k).s,'Error, division by zero')
            X(k) = Inf;
         else
            X(k) = NaN;
         end
      end
   end
end

if d ~= 32
   digits(d);
end

X = char(X);
X = map2mat(X);
[m,n] = size(sym(X));

if isa(X, 'double')
    D = reshape(X,m,n);
else
    D = reshape(eval(X),m,n);
end

%-------------------------

function r = map2mat(r)
% MAP2MAT Maple to MATLAB string conversion.
%   MAP2MAT(r) converts the Maple string r containing
%   matrix, vector, or array to a valid MATLAB string.
%
%   Examples: map2mat(matrix([[a,b], [c,d]])  returns
%             [a,b;c,d]
%             map2mat(array([[a,b], [c,d]])  returns
%             [a,b;c,d]
%             map2mat(vector([[a,b,c,d]])  returns
%             [a,b,c,d]

% Deblank.
r(findstr(r,' ')) = [];
% Special case of the empty matrix or vector
if strcmp(r,'vector([])') | strcmp(r,'matrix([])') | ...
   strcmp(r,'array([])')
   r = [];
else
   % Remove matrix, vector, or array from the string.
   r = strrep(r,'matrix([[','['); r = strrep(r,'array([[','[');
   r = strrep(r,'vector([','['); r = strrep(r,'],[',';');
   r = strrep(r,']])',']'); r = strrep(r,'])',']');
end
