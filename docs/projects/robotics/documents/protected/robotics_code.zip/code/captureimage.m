%CAPTUREIMAGE Captures an image from the camera.
%
%   To capture the image, the external program I_VIEW is used. The
%   image is captured, converted to gray scale and saved in
%   c:\myfile.tif.

!del /q "c:\myfile.bmp"
!del /q "c:\myfile.tif"
!i_view32.exe /scanhidden /convert=c:\myfile.bmp
%!i_view32.exe /scan /convert=c:\myfile.bmp
!i_view32.exe c:\myfile.bmp /gray /convert=c:\myfile.tif


