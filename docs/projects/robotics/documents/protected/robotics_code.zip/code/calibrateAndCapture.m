function [image, imagefull, xabs, yabs, xscale, yscale, pixels] = calibrateAndCapture()
%CALIBRATEANDCAPTURE Captures an image, processes it and get referential information.
%
%   [image, imagefull, xabs, yabs, xscale, yscale, pixels] = calibrateAndCapture()
%
%   The previous command will acquire an image on the current TWAIN device and
%   filter it using a 3x3 moving average filter. The image is then cut to remove the
%   top part (which include robot and shadows from overhead lighting). That image is
%   returned in the image variable (though the referential is removed)
%
%   In imagefull is returned the same image as in image, but with the referential
%   present.
%
%   The xabs and yabs value are the x and y positions, in CMs, of the upper left corner
%   of the returned image.
%
%   The xscale and yscale are the centimeters/pixels conversion factors.
%
%   The pixels value contains the position of various pixels of interest (used to display
%   referential position and size in the captured image)

% Physical constants
reflenght = 5.3; % in cm
refheight = 5.2; % in cm
xref_base_cm = 3.6 + 20; % in cm
yref_base_cm = 5.55 + 20; % in cm

% Program constants
cutoff_ypos = 150; % in pixels: tells the program where to cut off the image
ref_ypos = 165; % in pixels: tells the program where the referential section of the image begins
ref_xpos = ref_ypos; % in pixelsL tells the program how large the referential section is
h = ones(3) * 1/9; % 3x3 moving average filter

% Capture the image from the TWAIN source
captureimage;
raw = im2double(imread('c:\myfile.tif'));

% Filter the image 
image_filtered = conv2(raw, h, 'same');

% Cut off the top part of the image
cutimage = image_filtered(cutoff_ypos + 1:1:size(image_filtered,1),:);

% Get the referential part of the image
refimage = cutimage(ref_ypos + 1:1:size(cutimage,1),1:1:ref_xpos);
refimage(find(refimage < 0.55)) = 0; % convert image to black and white
refimage(find(refimage >= 0.55)) = 1;
% figure(4)
% imshow(refimage)

% Find largest row: the first pixel of this row will be the x position of
% the referential and the width of the black pixels will be used to
% calculate the xscale
sum_row = inf;
ref_x_pixels = -1;
for i = (1+5):1:(size(refimage,1)-5)
    sumthing = sum(refimage(:,i));
    if sumthing < sum_row
        ref_x_pixels = i;
        sum_row = sumthing;
    end
end
ref_x_pixels;
ref_width_pixels  = size(refimage,2) - sum_row;
xscale = reflenght / ref_width_pixels;

% Find largest columnL the last pixel of this row will be the y position
% of the referential and the height of the black pixels will be used to
% calculate the yscale
sum_col = inf;
ref_y_pixels = -1;
for i = (1+5):1:(size(refimage,2)-5)
    sumthing = sum(refimage(i,:));
    if sumthing < sum_col
        ref_y_pixels = i;
        sum_col = sumthing;
    end
end
ref_y_pixels;
ref_height_pixels  = size(refimage,1) - sum_col;
yscale = refheight / ref_height_pixels;

% Find first row pixel
tempx = ref_x_pixels; tempy = ref_y_pixels; tempimg = refimage(1:1:size(refimage,1)-5, 5:1:size(refimage,2)-5);
ref_x_pixels = find(tempimg(tempy, :) < 0.5);
ref_x_pixels = ref_x_pixels(1) + 5;

% Find last column pixel
ref_y_pixels = find(tempimg(:, tempx) < 0.5);
ref_y_pixels = ref_y_pixels(size(ref_y_pixels,1));

% Bring back in reference to image (cropped)
ref_x_pixels = ref_x_pixels;
ref_y_pixels = ref_ypos + ref_y_pixels;

% Remove referential from returned image
image = cutimage;
image(ref_y_pixels-ref_height_pixels:1:size(image,1), 1:1:ref_x_pixels+ref_width_pixels) = 1;
imagefull = cutimage;

xabs = xref_base_cm - ref_x_pixels * xscale;
yabs = yref_base_cm - ref_y_pixels * yscale;
pixels = [[ref_x_pixels, ref_y_pixels];
          [ref_x_pixels + ref_width_pixels, ref_y_pixels];
          [ref_x_pixels, ref_y_pixels - ref_height_pixels]];

% Output all this to console for the user
disp(['Calibrated data: Upper left corner of cropped image is at ' sprintf('(%d, %d) cms', xabs, yabs)]);
disp(['                 Referential is at ' sprintf('(%d, %d) pixels', ref_x_pixels, ref_y_pixels) ]);
disp(['                 Referential is of dimentions ' sprintf('(%d, %d) pixels ', ref_width_pixels, ref_height_pixels) ]);
disp(['                 Scale is ' sprintf('(%d, %d)', xscale, yscale) ' cm/pixels'])
        
