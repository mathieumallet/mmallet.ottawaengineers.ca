function [Solution] = FindSolutions(IKEqs, Thetas, XVal, YVal, ZVal, RotVal)
%FINDSOLUTIONS Solves a set of IK equations for specific X, Y, Z and rotation values
%
%   [Solution] = FindSolutions(IKEqs, Thetas, XVal, YVal, ZVal, RotVal)
%   
%   The previous command will return a matrix containing the possible solutions
%   to the inverse kinematics equations.
%
%   IKEqs needs to be a symbolic 4x4 matrix representing the position of the
%   robot's gripper in relation to its base.
%
%   Thetas needs to be a matrix containing the symbolic values to solve for.
%
%   XVal, YVal and ZVal need to be positions, in CMs, for which Theta values
%   need to be calculated
%
%   RotVal needs to be the desired rotation of the gripper, in radians

warning off;

% Solve IK equations
[t1, t2, t3, t4, t5] = ...
eval(['solve(''' char(IKEqs(1)) '= ' sprintf('%f', XVal) ''',' ...
            '''' char(IKEqs(2)) '= ' sprintf('%f', YVal) ''',' ...
            '''' char(IKEqs(3)) '= ' sprintf('%f', ZVal) ''',' ...
            '''' char(Thetas(1)) ' = ' char(IKEqs(4)) ''',' ...
            '''' char(Thetas(2)) ' = ' char(IKEqs(5)) ''',' ...
            '''' char(Thetas(3)) ' = ' char(IKEqs(6)) ''',' ...
            '''' char(Thetas(4)) ' = ' char(IKEqs(7)) ''',' ...
            '''' char(Thetas(5)) ' = ' char(IKEqs(8)) ''', Thetas(1), Thetas(2), Thetas(3), Thetas(4), Thetas(5))']);
warning on;

% Convert angles to degrees
Theta1 = emhdouble(t1 * 180 / pi);
Theta2 = emhdouble(t2 * 180 / pi);
Theta3 = emhdouble(t3 * 180 / pi);
Theta4 = emhdouble(t4 * 180 / pi);

% Voodo magic: We do not solve for the gripper angle. Instead, we
% calculate the gripper's angle from the theta1, theta2 and desired
% rotation.
Theta5 = emhdouble((t2 + t1 + RotVal - pi/2) * 180 / pi);

% Return solutions in a matrix
Solution = [Theta1 Theta2 Theta3 Theta4 Theta5];
