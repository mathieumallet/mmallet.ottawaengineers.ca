function [xpos, ypos, rotation, pixels] = findObjectPosition(image, xabs, yabs, xscale, yscale)
%FINDOBJECTPOSITION Finds the position and rotation of a rectangular, black object within an image.
%
%   [xpos, ypos, rotation, pixels] = findObjectPosition(image, xabs, yabs, xscale, yscale)
%
%   The previous command requires a cropped and filtered image as input. Also required
%   are the xabs, yabs, xscale and yscale values calculated with the captureAndCalibrate
%   command. Type HELP CAPTUREANDCALIBRATE for information on these values.
%
%   The xpos and ypos returned are both in CMs and are in relation to the upper left
%   corner of the cropped image.
%
%   Rotation will be returned in radians.
%
%   The pixels value contains the position of various pixels of interest (used to display
%   objet position and rotation in the captured image)

% Get image to be worked with
objimage = image;
objimage(1:1:20,:) = 1; % erase shadow area
objimage(find(objimage < 0.10)) = 0; % convert image to black and white
objimage(find(objimage >= 0.10)) = 1;
figure(5); imshow(objimage); title('Image used to find object position');

% Initial values
top = -1;
bottom = -1;
left = -1;
right = -1;


% Find top edge of the object
sumthing = 1;
for i = 1:1:size(objimage,1)
    sumthing = sum(objimage(i,:));
    if (sumthing ~= size(objimage,2))
        top = i;
        break;
    end;
end;

% Find bottom edge of the object
sumthing = size(objimage,1);
for i = 1:1:size(objimage,1)-2
    sumthing = sum(objimage(size(objimage,1) -1 - i,:));
    if (sumthing ~= size(objimage,2))
        bottom = size(objimage,1) -1 - i;
        break;
    end;
end;

% Find left edge of the object
sumthing = 1;
for i = 1:1:size(objimage,2)
    sumthing = sum(objimage(:,i));
    if (sumthing ~= size(objimage,1))
        left = i;
        break;
    end;
end;

% Find right edge of the object
sumthing = size(objimage,2);
for i = 1:1:size(objimage,2)-2
    sumthing = sum(objimage(:,size(objimage,2) -1 -i));
    if (sumthing ~= size(objimage,1))
        right = size(objimage,2) -1 - i;
        break;
    end;
end;

% The center is simply the average of the right, left, bottom
% and top positions of the object
center_x = left + round((right - left)/2);
center_y = top + round((bottom - top)/2);

% Get image used to find rotation
rotimage = image;
rotimage(find(image < 0.25)) = 0; % convert to black and white
rotimage(find(image >= 0.25)) = 1;

% Find rotation of object looking for closest white pixel to center of image
rot = -1;
for j = 1:0.5:min([center_x, center_y, size(rotimage, 1) - center_y, size(rotimage,2) - center_x])
    for i = -pi:pi/180:pi
        newx = j * cos(i) + center_x;
        newy = j * sin(i) + center_y;
        if rotimage(round(newy), round(newx)) == 1  % check if resulting position is a white pixel
            rot = i;
            rot_x = newx;
            rot_y = newy;
            break;
        end
    end
    if rot ~= -1
        break;
    end
end

% Display image used to find rotation
if center_y > 0 & center_x > 0
    objimage(center_y, center_x) = 0.5;
    objimage(round(newy), round(newx)) = 0.5;
    figure(6); imshow(rotimage); title('Image used to find object rotation');
end

% Return values
if center_x <= 0 | center_y <= 0    % Object not found -- return default position
    xpos = 0;
    ypos = 0;
    rotation = 0;
    pixels = [[1, 1]; [1, 1]]
else
    xpos = center_x * xscale;
    ypos = center_y * yscale;
    rotation = rot;
    pixels = [[center_x, center_y];
              [round(newx), round(newy)]];
end

% Display data in the console for the user
disp(['Object data: Position is ' sprintf('(%d, %d) cms', xpos, ypos)]);
disp(['                      or ' sprintf('(%d, %d) pixels', center_x, center_y) ]);
disp(['             Angle is ' sprintf('%d degrees', round(rotation * 180 / pi)) ]);
