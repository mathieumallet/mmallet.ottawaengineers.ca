function command = getParkCommand()
%GETPARKCOMMAND Returns the ROBIX command required to set the robot to a position in
% which it does not block the camera. The command is automatically copied to clipboard

command = 'move 1 to 1400, 2 to 1000, 3 to -1400';
clipboard('copy', command);