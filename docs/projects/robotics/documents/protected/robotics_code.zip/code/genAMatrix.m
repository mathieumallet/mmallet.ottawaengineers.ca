function [returnA] = genAMatrix(dist_l, dist_d, angle_alpha, angle_theta)
%GENAMATRIX Generate the A matrix corresponding to a set of D-H parameters.
%
%   [returnA] = genAMatrix(dist_l, dist_d, angle_alpha, angle_theta)
%
%   The previous command will return an A matrix generated from the
%   Denavit-Hartenberg parameters such that
%     l = dist_l
%     d = dist_d
%     alpha = angle_alpha
%     theta = angle_theta
%   
%   The function works with both symbolic and actual values. If actual values
%   are provided, the angles must be in radians.

returnA = [[emhcos(angle_theta) -emhsin(angle_theta)*emhcos(angle_alpha)  emhsin(angle_theta)*emhsin(angle_alpha) dist_l*emhcos(angle_theta)];
          [emhsin(angle_theta)   emhcos(angle_theta)*emhcos(angle_alpha) -emhcos(angle_theta)*emhsin(angle_alpha) dist_l*emhsin(angle_theta)];
          [0                     emhsin(angle_alpha)                      emhcos(angle_alpha)                     dist_d                    ];
          [0                     0                                        0                                       1                         ]];
