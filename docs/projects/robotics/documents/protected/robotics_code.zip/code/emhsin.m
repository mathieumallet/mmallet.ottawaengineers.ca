function result = emhsin(angle)
%EMHSIN Calculates a cos. If the result is very close to 0, it returns 0.
%If it is very close to 1, it returns 1. If the argument is symbolic,
%sin(angle) is returned.
%
%   EMHSIN(X) is the rounded cosine of the elements of X. 
%

% Handle symbolic values
if isa(angle, 'sym')
    result = sin(angle);
else
    result = emhround(sin(angle));
end

% Round result to 0 if close to 0 and to -1 or 1 if close to -1 or 1.
function result = emhround(data)
if (data < 1e-15 & data > -1e-15)
    result = 0;
elseif ((data > 1 - 1e-15) & (data < 1 + 1e-15))
    result = 1;
elseif ((data > -1 + 1e-15) & (data < -1 - 1e-15))
    result = -1;
else
    result = data;
end