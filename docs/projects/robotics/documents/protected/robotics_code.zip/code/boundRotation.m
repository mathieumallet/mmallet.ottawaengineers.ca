function result = boundRotation(rotation)
%BOUNDROTATION Returns a rotation bounded between -90 and 90 degrees.
%
%   rot = boundRotation(oldrot) returns a rotation between -90 and
%   90 degrees. This is used on to get the angle of the gripper on the
%   robot, knowing that an angle of 0 degrees is the same as an angle of
%   180 degrees.

result = rotation;

if (rotation < -90)
    result = boundRotation(rotation + 180);
end

if (rotation > 90)
    result = boundRotation(rotation - 180);
end