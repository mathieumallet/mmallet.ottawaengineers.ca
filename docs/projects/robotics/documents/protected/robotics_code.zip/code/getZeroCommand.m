function command = getZeroCommand()
%GETPARKCOMMAND Returns the ROBIX command required to move the robot to its
% 'zero' position, e.g. where all Theta parameters are 0. Automatically copies
% the command to clipboard.

pos1 = calcRotationValue(1,0);
pos2 = calcRotationValue(2,0);
pos3 = calcRotationValue(3,0);
pos4 = calcRotationValue(4,0);
pos5 = calcRotationValue(5,0);

command = sprintf('move 1 to %d, 2 to %d, 3 to %d, 4 to %d, 5 to %d, 6 to 0', pos1, pos2, pos3, pos4, pos5);
clipboard('copy', command);