% Main program
close all;
disp('Voodoo Robix -- Late late night version');
disp('Initializing values...');
syms theta1 theta2 theta3 theta4 theta5;
Thetas = [[theta1];[theta2];[theta3];[theta4];[theta5]];
syms MyX  MyY  MyZ  MyRot
verticalClearance = 3;

disp('Calculating A matrices...');

% Complex model -- some precision errors, so we used the
% simplified model instead
% A1 = genAMatrix(9.8,   16.6,   0,      theta1+pi/2);
% A2 = genAMatrix(9.6,    1.0,    pi/2,   theta2);
% A3 = genAMatrix(6,      2.4,    0,      theta3);
% A4 = genAMatrix(0,      3.6,    pi/2,   theta4+pi/2);
% A5 = genAMatrix(0,      11,     0,      theta5);

% Simplified model -- here we calculate the A matrices symbolically
A1 = genAMatrix(9.8,15.7,0,theta1+pi/2);
A2 = genAMatrix(9.6,0,pi/2,theta2);
A3 = genAMatrix(6,0,0,theta3);
A4 = genAMatrix(0,0,pi/2,theta4+pi/2);
A5 = genAMatrix(0,11,0,theta5);

% We then multiply all of our A matrices together to get the position
% of the gripper in relation to the robot's base
QPB = simple(A1*A2*A3*A4*A5);

% Here we precalculate the IK equations to speed up calculations later.
disp('Calculating IK equations...');
IKEqs = FindIKeqs(QPB, MyX, MyY, MyZ);

% The following lines are used to setup the software: the scanning
% program needs to select the proper TWAIN source and the robot
% needs to be put in a 'parking' position which can easily be cut
% off the captured image. This part also allows the user to properly
% align the workspace in respect to the camera.
disp('Copying parking command to clipboard -- paste and run in robix if robot is not parked already');
clipboard('copy', getParkCommand);
disp('Setup: select twain source from i_view and align workspace properly');
!i_view32.exe
disp('Press any key to continue...'); pause;

% main loop
while 1 
    
    % Capture an image, process it and find the referential position and scale
    disp('Capturing image and finding referential...');
    [image, imagefull, xabs, yabs, xscale, yscale, pixels] = calibrateAndCapture;

    % From captured image, find the position and orientation of object to be grasped
    disp('Finding object position and rotation...');
    [xpos, ypos, rotation, pixels2] = findObjectPosition(image, xabs, yabs, xscale, yscale);

    % Display greyscale image of the workspace and overlap color representations
    % of referential position, scale and object position and rotation
    figure(1);
    image_color = cat(3, imagefull, imagefull, imagefull);
    image_color(pixels(3,2):1:pixels(1,2), pixels(3,1):1:pixels(1,1), 1:1:3) = 0;
    image_color(pixels(3,2):1:pixels(1,2), pixels(3,1):1:pixels(1,1), 1) = 1;
    image_color(pixels(1,2):1:pixels(2,2), pixels(1,1):1:pixels(2,1), 1:1:3) = 0;
    image_color(pixels(1,2):1:pixels(2,2), pixels(1,1):1:pixels(2,1), 1) = 1;
    image_color(pixels2(1,2), pixels2(1,1), 1:1:3) = 0;
    image_color(pixels2(1,2), pixels2(1,1), 1) = 1;
    image_color(pixels2(2,2), pixels2(2,1), 1:1:3) = 0;
    image_color(pixels2(2,2), pixels2(2,1), 1) = 1;
    imshow(image_color); title('Captured image showing referential, object position and rotation')
    
    % Calculate the x, y, z positions in CMs and display them in the console
    commands = 0;
    desired_x = xabs - xpos + 2;
    desired_y = ypos + 4;
    desired_z = 0;
    desired_rotation = rotation;
    disp(sprintf('Absolute position of object is\n (%d, %d, %d), rotation = %d', desired_x, desired_y, desired_z, rotation));
    
    % Solve the IK equations to find the theta values
    % This solve is used to find the pickup position, e.g. when the robot's
    % gripper is over the object
    disp('Using IK to find pickup position...');
    desired_z = desired_z + verticalClearance;
    PickupSol = FindSolutions(IKEqs, Thetas, desired_x, desired_y, desired_z, desired_rotation);
    
    % start creating command list: 
    commands = getZeroCommand; % move the robot to the 'zero' position
    
    % Select one of the solutions from the four possible solutions returned by Findsolutions
    [pickupsolution, pickupcommand] = PickSolution(PickupSol);
    
    if pickupcommand == -1
        disp('Could not find solution for pickup position.');
    else
        commands = sprintf('%s\n%s', commands, pickupcommand); % move the robot to the 'pickup' position
        commands = sprintf('%s\nmove 6 to -1400', commands);  % open gripper
        
        desired_z = desired_z - verticalClearance;  % calculate Z position required to grip the object

        % Solve the IK equations to find the gripping position, e.g. when the
        % robot can close the gripper and grasp the object
        disp('Using IK to find gripping position...');
        GripSol = FindSolutions(IKEqs, Thetas, desired_x, desired_y, desired_z, desired_rotation);
        [grippingsolution, grippingcommand] = PickSolution(GripSol, pickupsolution(1));
        if grippingcommand == -1
            disp('Could not find solution for pickup position.');
        else
            commands = sprintf('%s\n%s', commands, grippingcommand); % move the robot to the 'gripping' position
            commands = sprintf('%s\nmove 6 to 0', commands);  % close gripper
            commands = sprintf('%s\n%s', commands, pickupcommand); % move the robot to the 'pickup' position again
            
            % Move object to opposite side :)
            % This is done by simply mirroring the rotation values that we obtained from the robot
            commands = sprintf('%s\n%s', commands, getZeroCommand); % move to 'zero' position
            [negpickupsolution, negpickupcommand] = PickSolution(MirrorSolution(PickupSol)); % get 'negative' pickup postion
            commands = sprintf('%s\n%s', commands, negpickupcommand); % move robot to 'negative' pickup position
            [neggripsolution, neggripcommand] = PickSolution(MirrorSolution(GripSol), negpickupsolution(1)); % get 'negative' grippping position
            commands = sprintf('%s\n%s', commands, neggripcommand); % move robot to 'negative' gripping position
            commands = sprintf('%s\nmove 6 to -1400', commands);  % open gripper
            commands = sprintf('%s\n%s', commands, negpickupcommand); % move back to 'negative' picku position
            commands = sprintf('%s\n%s', commands, getParkCommand); % go to park position in preparation for next object to be picked up
            
            % Display commands to be used in ROBIX software
            disp('Commands to be run are:');
            commands
            
            % For convinience: automatically copy command list to clipboard
            clipboard('copy', commands);
        end
    end
    
    % Check if we should run the software again
    result = input('Continue? (1 = yes, 2 = no) ');
    if result == 1
       % By using a loop to run again, we can skip the calculation of IK equations, of A matrices and
       % the initial calibration of the software.
    else
       break; % break away from the loop, therefore exiting the program
    end
end