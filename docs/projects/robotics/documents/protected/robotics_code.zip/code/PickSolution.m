function [result, command] = PickSolution(Sol, preferedTheta1)
%PICKSOLUTION Select one of the solutions and return both the picked
% solution and the command used to move the robot to that position.
%
%   [result, command] = PickSolution(Sol) Will return a solution picked
%   from the solutions presented in the matrix Sol. The command used to
%   move the robot to that position is also returned.
%
%   Solutions with imaginary parts are immediatly rejected. Solutions that
%   require the robot to move beyond they're members acceptable angles are
%   also rejected. If no solution can be found, result is set to -1.
%
%   When multiple solutions are found, the optional argument preferedTheta1
%   can be used to select which solution to choose. This is to prevent the
%   robot from moving unnecessarily when going from pickup position to
%   gripping position and vice-versa. If a preferedTheta1 is given, then the
%   returned solution is the one with the theta1 closest to preferedTheta1.

result = [-10000 -10000 -10000 -10000 -10000];
rotationlimit = 1500;
a1 = Sol(:,1);
a2 = Sol(:,2);
a3 = Sol(:,3);
a4 = Sol(:,4);
a5 = Sol(:,5);

for i = 1:1:size(a1,1) % check all solutions
    if (imag(a1(i)) == 0) & (imag(a2(i)) == 0) & (imag(a3(i)) == 0) & (imag(a4(i)) == 0) % eliminate solutions with imaginary parts
        % get 'real' rotation values applied to the actuators
        b1 = calcRotationValue(1, a1(i));
        b2 = calcRotationValue(2, a2(i));
        b3 = calcRotationValue(3, a3(i));
        b4 = calcRotationValue(4, a4(i));
        b5 = calcRotationValue(5, boundRotation(a5(i)));
        
        % Eliminate rotations that are beyond the physical limitations
        % We allow slightly higher rotations than what is possible
        % and bring them back to -1400 < x < 1400. This is to slightly
        % expand the relatively small workspace by sacrificing precision.
        if b1 < rotationlimit & b1 > -rotationlimit
            if b2 < rotationlimit & b2 > -rotationlimit
                if b3 < rotationlimit & b3 > -rotationlimit
                    if b4 < rotationlimit & b4 > -rotationlimit
                        
                        % Bound the actuator values between -1400 and 1400
                        b1 = max(-1400, min(b1, 1400));
                        b2 = max(-1400, min(b2, 1400));
                        b3 = max(-1400, min(b3, 1400));
                        b4 = max(-1400, min(b4, 1400));

                        % Since 0 degress == 180 degrees for gripper, we can do a
                        % different kind of bounding here
                        if (b5 < -1400)
                            b5 = b5 + 1400*2;
                        end
                        if (b5 > 1400)
                            b5 = b5 - 1400*2;
                        end
                        b5 = max(-1400, min(b5, 1400));
                        
                        % pick solution closest to theta1, if preferedTheta1 is supplied
                        if nargin == 1 | result(1) == -10000 | abs(b1 - preferedTheta1) < abs(result(1) - preferedTheta1)
                            result = [b1 b2 b3 b4 b5];
                        end
                    end
                end
            end
        end
    end
end

if result(1) == -10000
    command = -1; % no solution found
else
    % return picked solution and ROBIX command
    command = ['move 1 to ' sprintf('%d', result(1)) ', 2 to ' sprintf('%d', result(2)) ', 3 to ' sprintf('%d', result(3)) ', 4 to ' sprintf('%d', result(4)) ', 5 to ' sprintf('%d', result(5))];
    clipboard('copy', command);
end
