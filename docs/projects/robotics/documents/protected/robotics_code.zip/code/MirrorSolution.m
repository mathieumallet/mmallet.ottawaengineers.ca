function result = MirrorSolution(Sol)
%MIRRORSOLUTION Return the mirror of the specified solution
%
%   solution = MirrorSolution(oldsol) Will return five theta values
%   that correspond to the mirrored position along the Y axis of the robot.
%   For example, if the robot's gripper was positionned at (10,10,0) (on the
%   left side of the workspace), then the returned solution would be
%   at at (-10,10,0) (on the right side of the workspace). 

result = [-Sol(:,1) -Sol(:,2) Sol(:,3) Sol(:,4) -Sol(:,5)];
