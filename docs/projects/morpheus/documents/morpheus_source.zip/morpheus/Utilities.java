/*
 * Created on Jun 22, 2005
 */
package morpheus;

import java.io.*;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.SWT;

/**
 * @author emh
 *
 * This class contains various useful static functions.
 */
public class Utilities {
	
	public static final String APP_NAME = "Morpheus";
	public static final String APP_VERSION = "0.1";
	
	public static String GetAboutText()
	{
		String text = APP_NAME + "\n";
		text += "Version " + APP_VERSION + "\n\n";
		text += "Copyright 2005 Mathieu Mallet\n";
		text += "Visit http://mmallet.ottawaengineers.ca/ for more information.";
		
		return text;
	}
	
	public static StyleRange GetAboutStyleRange()
	{
		StyleRange style = new StyleRange();
		style.start = 0;
		style.length = APP_NAME.length();
		style.fontStyle = SWT.BOLD + SWT.ITALIC;
		return style;
	}

	public static String charToBinaryString(char c)
	{
		String s = "";
		for (int i = 0; i < 8; i++)
			if (((c >> i) & 0x01) == 1)
				s = "1" + s;
			else
				s = "0" + s;
		
		return s;
	}
	
	public static String charToHexString(char c)
	{
		String s = Integer.toHexString(c).toUpperCase();
		if (s.length() == 1)
			s = "0x0" + s;
		else
			s = "0x" + s;
		return s;
	}
	
	public static String charToHexString2(char c)
	{
		String s = Integer.toHexString(c).toUpperCase();
		if (s.length() == 1)
			s = "0" + s;
		return s;
	}
	
	public static char[] extractBytesFromHexLine(String s)
	{
		char[] bytes = new char[8];
		char upper, lower;
		int count = 0;
		
		if (s.length() < 43)
			return null;
		
		for (int i = 9; i < 40; i += 4)
		{
			lower = (char)Integer.parseInt(s.substring(i,i+2), 16);
			upper = (char)Integer.parseInt(s.substring(i+2, i+4), 16);
			bytes[count] = (char)(lower + (upper << 8));
		    count++;
		}
		
		
		return bytes;
	}
	
	/**
	 * Converts a time to the format HH:MM:SS.
	 * @param time Time to be converted, in seconds.
	 * @return
	 */
	public static String getTimeAsString(float time)
	{
		int seconds, minutes, hours;
		String s;
		seconds = (int)time % 60;
		minutes = (int)(time / 60) % 60;
		hours = (int)(time / 60 / 60);
		
		if (seconds < 10)
			s = "0" + seconds;
		else
			s = Integer.toString(seconds);
		
		if (minutes < 10)
			s = "0" + minutes + ":" + s;
		else
			s = Integer.toString(minutes) + ":" + s;
		
		return Integer.toString(hours) + ":" + s;
	}
	
	/**
	 * Converts a time to the format HH:MM.S
	 * @param time Time to be converted, in seconds.
	 * @return
	 */
	public static String getTimeAsString2(float time)
	{
		float minutes;
		int hours;
		String s;
		minutes = ((float)((int)time % 3600) / 60);
		hours = (int)(time / 60 / 60);
		
		if (minutes < 10)
			s = "0" + Float.toString(minutes);
		else
			s = Float.toString(minutes);
		
		return Integer.toString(hours) + ":" + s;
	}	
	
	public static boolean loadNativeLibraries(ClassLoader loader)
	{
		try
		{
			InputStream inputStream = loader.getResourceAsStream("swt-win32-3064.dll");
			File temporaryDll = File.createTempFile("swt-win32-3064", ".dll");
			FileOutputStream outputStream = new FileOutputStream(temporaryDll);
	        byte[] array = new byte[8192];
	        for (int i = inputStream.read(array);
	        	i != -1;
	            i = inputStream.read(array))
	        {
	           	outputStream.write(array, 0, i);
	        }
	        outputStream.close();
	        temporaryDll.deleteOnExit();
	        System.load(temporaryDll.getPath());
	        
			return true;
		}
		catch (Throwable e)
		{
			e.printStackTrace();
            return false;
		}
	
	}
	
	public static char convertByteToChar(byte b)
	{
		return (b < 0) ? (char)(b + 256) : (char)b;
	}
	
	public static int max(int a, int b)
	{
		return (a > b) ? a : b;
	}
	
	public static String floatAsString(float number, int digitsAfterComma)
	{
		if (digitsAfterComma < 0)
			return String.valueOf(number);
		
		float power = (float)Math.pow(10, digitsAfterComma);
		return String.valueOf((float)Math.round(number * power) / power);
	}
}
