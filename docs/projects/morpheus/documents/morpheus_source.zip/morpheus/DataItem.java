/*
 * Created on Jun 22, 2005
 */
package morpheus;

/**
 * @author emh
 *
 * This class is used to contain data items.
 */
public class DataItem {

	// Data Fields
	
	public float Time; // In seconds
	public int EventType = -1;
	public float EventLength = 0; // In seconds
	public char RawData = 0xFF;
	public String EventString;
	public int NumberOfChanges;
	
	public DataItem nextItem = null; // Linked list structure
	

	// Constants
	
	public static final int NO_DATA = -1;
	public static final int PROGRAM_STARTED = 0;
	public static final int REALITY_CHECKED = 1;
	public static final int REM_DETECTED = 2;
	public static final int CUES_GIVEN = 3;
	public static final int ALARM_GIVEN = 4;
	public static final int REM_SCAN_STARTED = 5;
	public static final int PROGRAM_STOPPED = 6;
	public static final int DELAY_300_SEC_STARTED = 7;
	public static final int PRE_ALARM_DELAY_STARTED = 8;
	public static final int DELAY_OVER = 9;
	public static final int NO_REM_DETECTED = 10;
	public static final int INSTANT_SCAN_REQUESTED = 11;
	public static final int NUMBER_OF_CHANGES = 12;
	public static final int COMPRESSED_DATA = 13;
	//public static final int TIME_DELAY = 13;
	
	
	// Static Functions
	
	public static int GetDataType(char RawData)
	{
		switch (RawData)
		{
			case 0xA1:	return PROGRAM_STARTED;
			case 0xA2:	return REALITY_CHECKED;
			case 0xA3:	return REM_DETECTED;
			case 0xA4:	return CUES_GIVEN;
			case 0xA5:	return ALARM_GIVEN;
			case 0xA6:	return REM_SCAN_STARTED;
			case 0xA7:	return PROGRAM_STOPPED;
			case 0xA8:	return DELAY_300_SEC_STARTED;
			case 0xA9:	return PRE_ALARM_DELAY_STARTED;
			case 0xAA:	return DELAY_OVER;
			case 0xAB:	return NO_REM_DETECTED;
			case 0xAC:	return INSTANT_SCAN_REQUESTED;
					
			default:
				if (RawData >= 0xB0 && RawData <= 0xCF)
					return NUMBER_OF_CHANGES;
				if (RawData < 0xA1)
					return REALITY_CHECKED;
				if (RawData >= 0xD0 && RawData < 0xF0)
					return COMPRESSED_DATA;
				
				return NO_DATA;
		}
	}
	
	public static boolean eventTypeUsesTwoBytes(char RawData)
	{
		switch (GetDataType(RawData))
		{
			case PROGRAM_STARTED:
			case PROGRAM_STOPPED:
				return true;
			default:
				return false;
		}
	}
	
	public static String GetEventString(int type, char raw)
	{
		switch (type)
		{
			case PROGRAM_STARTED:			return "Program started";
			case REALITY_CHECKED:			return "Reality check performed";
			case REM_DETECTED:				return "REM activity detected";
			case CUES_GIVEN:				return "Cues given";
			case ALARM_GIVEN:				return "Alarm activated";
			case REM_SCAN_STARTED:			return "REM scan started";
			case PROGRAM_STOPPED:			return "Program stopped";
			case DELAY_300_SEC_STARTED:		return "300 seconds delay started";
			case PRE_ALARM_DELAY_STARTED:	return "Pre-alarm delay started";
			case DELAY_OVER:				return "Delay over";
			case NO_REM_DETECTED:			return "No REM activity detected";
			case INSTANT_SCAN_REQUESTED:	return "Instant REM scan requested";
			
			case NUMBER_OF_CHANGES:
				return (raw - 0xB0) + " movements detected";
				
			//case REALITY_CHECKED:
			//	return "Reality check performed";
				
			default:
				return "Unknown Event Type: " + type;
		}
	}
}
