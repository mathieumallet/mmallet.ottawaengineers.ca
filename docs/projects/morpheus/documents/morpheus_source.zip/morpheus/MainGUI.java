/*
 * Created on Jun 21, 2005
 */
package morpheus;


import morpheus_comm.SerialManager;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.custom.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


/**
 * @author emh
 *
 * Main interface file. This class handles the GUI as well as the drawing of the graph.
 */
public class MainGUI {
	public Display display;
	public Shell shell;
	private Canvas canvas;
	private Table table, configTable;
	private RawData rawData;
	private ProcessedData processedData;
	public Image programIcon;
	private SerialManager serialReader;
	private String selectedSerialPort;
	
	private Color ColorNoREM, ColorREM, ColorBackground, ColorBlack;
	private Color ColorCues, ColorSample, ColorAlarm, ColorRealityCheck;
	private Color ColorOther, ColorUnknown;

	// Configs
	private boolean bHideLastDataPointItem = false;
	private boolean bHideAwakeDataPointsItem = true;
	
	public static void main(String[] args) {
		new MainGUI().run();
	}
	
	public void run() {
		// Initialize Serial interface
		serialReader = new SerialManager();
		serialReader.Initialize();
		
		display = new Display();
		
		ColorNoREM = new Color(display, 255, 204, 204);
		ColorREM = new Color(display, 204, 255, 204);
		ColorBackground = new Color(display, 255, 255, 255);
		ColorBlack = new Color(display, 0, 0, 0);
		ColorCues = new Color(display, 0, 128, 0);
		ColorSample = ColorBlack;
		ColorAlarm = new Color(display, 255, 0, 0);
		ColorRealityCheck = new Color(display, 0, 0, 255);
		ColorOther = new Color(display, 92, 255, 255);
		ColorUnknown = new Color(display, 128, 0, 12);
		
		shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		shell.setText(Utilities.APP_NAME);
		
		InputStream stream = getClass().getClassLoader().getResourceAsStream("morpheus_multires.ico");
		programIcon = new Image(display, stream);
		shell.setImage(programIcon);
		
		createContents(shell);
		
		shell.pack();
		shell.setSize(800,600);
		shell.open();
		
		while (!shell.isDisposed())
		{
			if (!display.readAndDispatch()) 
				display.sleep();
		}
		 
		display.dispose();		
	}
	
	private void createContents(Shell shell)
	{
		createMenus(shell);
		
		SashForm sashForm1 = new SashForm(shell, SWT.VERTICAL);
		
		//Group canvasGroup = new Group(sashForm1, SWT.NONE);
		//canvasGroup.setLayout(new FillLayout());
		//canvasGroup.setText("Graph");
		canvas = new Canvas(sashForm1, SWT.NONE);
		canvas.setBackground(new Color(canvas.getDisplay(), 255, 255, 255));
		canvas.addPaintListener(new CanvasPaintListener());
		
		SashForm sashForm2 = new SashForm(sashForm1, SWT.HORIZONTAL);
		

		// Setup data table
		
		//Group tableGroup = new Group(sashForm2, SWT.NONE);
		//tableGroup.setLayout(new FillLayout());
		//tableGroup.setText("Raw Data");
		table = new Table(sashForm2, SWT.SINGLE);
		TableColumn col1 = new TableColumn(table, SWT.LEFT);
		col1.setText("Time");
		col1.setWidth(80);
		TableColumn col2 = new TableColumn(table, SWT.LEFT);
		col2.setText("Raw");
		col2.setWidth(40);
		TableColumn col3 = new TableColumn(table, SWT.LEFT);
		col3.setText("Event Description");
		col3.setWidth(650);
		
		// Resize last column automatically when control is resized
		table.addControlListener(new ControlListener(){
			public void controlMoved(ControlEvent e){}
			public void controlResized(ControlEvent e)
			{
				int width, i;
				Table table = (Table)e.getSource();
				if (table == null)
					return;
				
				width = table.getSize().x;
				for (i = 0; i < table.getColumnCount() - 1; i++)
					width -= table.getColumn(i).getWidth();
				
				width -= table.getVerticalBar().getSize().x;
				
				if (width > 0)
					table.getColumn(i).setWidth(width);				
			}
			
		});		
		
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		

		// Setup config table
		
		//Group table2Group = new Group(sashForm2, SWT.NONE);
		//table2Group.setLayout(new FillLayout());
		//table2Group.setText("Information");		
		
		configTable = new Table(sashForm2, SWT.SINGLE);
		TableColumn col1b = new TableColumn(configTable, SWT.LEFT);
		col1b.setText("Variable");
		col1b.setWidth(80);
		TableColumn col2b = new TableColumn(configTable, SWT.LEFT);
		col2b.setText("Value");
		col2b.setWidth(80);		
		
		// Make all columns same size
		configTable.addControlListener(new ControlListener(){
			public void controlMoved(ControlEvent e){}
			public void controlResized(ControlEvent e)
			{
				int width, i;
				Table table = (Table)e.getSource();
				if (table == null)
					return;
				
				width = table.getSize().x - table.getVerticalBar().getSize().x;
				
				if (width > 0)
				{
					table.getColumn(0).setWidth(width * 2/3);
					table.getColumn(1).setWidth(width * 1/3);
				}
			}
			
		});				
		
		configTable.setHeaderVisible(true);
		configTable.setLinesVisible(true);	

		// Set control respective sizes
		sashForm1.setWeights(new int[]{4, 3});
		sashForm2.setWeights(new int[]{4, 3});
	
	}
	
	private void createMenus(Shell shell)
	{
		// Create menu bar
		Menu menu = new Menu(shell, SWT.BAR);
		
		// Create menus items for menu bar
		MenuItem fileItem = new MenuItem(menu, SWT.CASCADE);
		fileItem.setText("&File");
		MenuItem viewItem = new MenuItem(menu, SWT.CASCADE);
		viewItem.setText("&View");
		MenuItem optionsItem = new MenuItem(menu, SWT.CASCADE);
		optionsItem.setText("&Options");
		MenuItem helpItem = new MenuItem(menu, SWT.CASCADE);
		helpItem.setText("&Help");
		
		
		// Create file drop down menu
		Menu fileMenu = new Menu(menu);
		fileItem.setMenu(fileMenu);
		
		// Create sub items for 'File' drop down menu
		MenuItem openSampleItem = new MenuItem(fileMenu, SWT.NONE);
		openSampleItem.setText("Open &Sample Data");
		openSampleItem.addSelectionListener(new OpenSampleListener());
		new MenuItem(fileMenu, SWT.SEPARATOR);
		MenuItem openSerialItem = new MenuItem(fileMenu, SWT.NONE);
		openSerialItem.setText("Import from &Serial Port...");
		openSerialItem.addSelectionListener(new OpenSerialListener());
		MenuItem openHEXItem = new MenuItem(fileMenu, SWT.NONE);
		openHEXItem.setText("Import from .&HEX file...");		
		openHEXItem.addSelectionListener(new OpenHEXListener());
		new MenuItem(fileMenu, SWT.SEPARATOR);
		MenuItem openDataItem = new MenuItem(fileMenu, SWT.NONE);
		openDataItem.setText("&Open data...");		
		openDataItem.addSelectionListener(new OpenDataListener());
		MenuItem saveDataItem = new MenuItem(fileMenu, SWT.NONE);
		saveDataItem.setText("&Save data...");	
		saveDataItem.addSelectionListener(new SaveDataListener());
		new MenuItem(fileMenu, SWT.SEPARATOR);
		MenuItem exitItem = new MenuItem(fileMenu, SWT.NONE);
		exitItem.setText("&Exit");		
		exitItem.addSelectionListener(new ExitListener());
		
		
		// Create view drop down menu
		Menu viewMenu = new Menu(menu);
		viewItem.setMenu(viewMenu);
			
		// Create sub items for 'Options' drop down menu
		MenuItem viewEEPROMItem = new MenuItem(viewMenu, SWT.NONE);
		viewEEPROMItem.setText("Raw &EEPROM Data...");		
		viewEEPROMItem.addSelectionListener(new ViewEEPROMListener());				
		
		
		// Create options drop down menu
		Menu optionsMenu = new Menu(menu);
		optionsItem.setMenu(optionsMenu);
			
		// Create sub items for 'Options' drop down menu
		MenuItem serialPortItem = new MenuItem(optionsMenu, SWT.CASCADE);
		serialPortItem.setText("&Serial Port");		
		
		// Create serial port drop down menu
		Menu serialMenu = new Menu(menu);
		serialPortItem.setMenu(serialMenu);
		
		// Get available serial ports
		String[] ports = serialReader.GetPorts();
		if (ports == null || ports.length == 0)
		{
			MenuItem serialItem = new MenuItem(serialMenu, SWT.NONE);
			serialItem.setText("No ports available");
			serialItem.setEnabled(false);
			openSerialItem.setEnabled(false);
		}
		else
		{
			MenuItem serialItem;
			for (int i = 0; i < ports.length; i++)
			{
				serialItem = new MenuItem(serialMenu, SWT.RADIO);
				serialItem.setText(ports[i]);
				serialItem.addSelectionListener(new SelectSerialPortListener());
				if (i == 0)
				{
					serialItem.setSelection(true);
					selectedSerialPort = ports[i];
				}
			}
		}
		new MenuItem(optionsMenu, SWT.SEPARATOR);
		
		MenuItem hideLastDataPointItem = new MenuItem(optionsMenu, SWT.CHECK);
		hideLastDataPointItem.setText("Hide &Last Data Point");		
		hideLastDataPointItem.setSelection(bHideLastDataPointItem);
		hideLastDataPointItem.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				bHideLastDataPointItem = ((MenuItem)e.getSource()).getSelection();
				ProcessData();
			}
			
			public void widgetDefaultSelected(SelectionEvent e) {}			
		});
		
		MenuItem hideAwakeDataPointsItem = new MenuItem(optionsMenu, SWT.CHECK);
		hideAwakeDataPointsItem.setText("Hide &Awake Data");		
		hideAwakeDataPointsItem.setSelection(bHideAwakeDataPointsItem);
		hideAwakeDataPointsItem.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				bHideAwakeDataPointsItem = ((MenuItem)e.getSource()).getSelection();
				ProcessData();
			}
			
			public void widgetDefaultSelected(SelectionEvent e) {}			
		});	
		
		// Create help drop down menu
		Menu helpMenu = new Menu(menu);
		helpItem.setMenu(helpMenu);
			
		// Create sub items for 'Options' drop down menu
		MenuItem aboutItem = new MenuItem(helpMenu, SWT.NONE);
		aboutItem.setText("&About...");		
		aboutItem.addSelectionListener(new AboutListener());	
		
		
		// Set menu bar
		shell.setMenuBar(menu);
	}
	
	class OpenSampleListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			OpenSample();
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}	
	
	class OpenSerialListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			OpenSerial();
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}
	
	class OpenHEXListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			ImportFromHex();
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}
	
	class OpenDataListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			OpenData();
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}
	
	class SaveDataListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			SaveData();	
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}	
	
	class ExitListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			Exit();
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}		
	
	class ViewEEPROMListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			ViewEEPROMData();
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}	
	
	class SelectSerialPortListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			if (((MenuItem)e.getSource()).getSelection())
			{
				selectedSerialPort = ((MenuItem)e.getSource()).getText();
			}
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}
		
	class AboutListener implements SelectionListener {
		public void widgetSelected(SelectionEvent e) {
			About();
		}
		
		public void widgetDefaultSelected(SelectionEvent e) {}
	}
	
	class CanvasPaintListener implements PaintListener {
		public void paintControl(PaintEvent e) {
			int i, numItems = 0, maxchange = 0;
			float f, xseparation, yseparation, maxTime = 0, h, delta, timefactor;
			DataItem item;
			Point p, lastpoint;
			Point CanvasSize = canvas.getSize();
			Point GraphOffset = new Point(30, 20);
			Point GraphEndOffset = new Point(20, 50);
			Point GraphEnd = new Point(CanvasSize.x - GraphEndOffset.x, CanvasSize.y - GraphEndOffset.y);
			Point GraphSize = new Point(GraphEnd.x - GraphOffset.x, GraphEnd.y - GraphOffset.y);
			
			// Stop drawing if there is no processed data
			if (processedData == null)
				return;
			
			// Get max time and item count
			for (item = processedData.data; item != null; item = item.nextItem)
			{
				maxTime = item.Time + item.EventLength;
				numItems++;
				if (item.NumberOfChanges > maxchange)
					maxchange = item.NumberOfChanges;
			}
			maxchange = Utilities.max(maxchange, rawData.Min_AD_Change_For_REM_Detect + 1);
			
			// Calculate separation of marks on the x axis
			xseparation = maxTime / (((float)GraphSize.x) / 20);
			// Round separation up to nearest 5 minute
			xseparation = (int)xseparation + 300 - ((int)xseparation % 300);
			timefactor = GraphSize.x / maxTime;
			h = e.gc.getFontMetrics().getHeight();
			
			// Calculate separation of marks on y axis
			//yseparation = (int)(((float)GraphSize.y) / (rawData.Num_REM_Scans + 1));
			yseparation = (int)(((float)GraphSize.y) / (maxchange + 1));
			delta = 1000;
			
			// Draw background
			e.gc.setBackground(ColorNoREM);
			e.gc.fillRectangle(GraphOffset.x, (int)(GraphEnd.y - (rawData.Min_AD_Change_For_REM_Detect * yseparation - yseparation/2)), GraphSize.x,
					(int)(rawData.Min_AD_Change_For_REM_Detect * yseparation - yseparation/2));
			e.gc.setBackground(ColorREM);
			e.gc.fillRectangle(GraphOffset.x, GraphOffset.y,
					GraphSize.x, GraphSize.y - (int)(rawData.Min_AD_Change_For_REM_Detect * yseparation - yseparation/2));
			e.gc.setBackground(ColorBackground);
			
			// Draw axes
			e.gc.drawLine(GraphOffset.x, GraphOffset.y - 10, GraphOffset.x, GraphEnd.y);
			e.gc.drawLine(GraphOffset.x, GraphEnd.y, GraphEnd.x + 10, GraphEnd.y);
			
			// Draw axes arrows
			e.gc.drawLine(GraphOffset.x, GraphOffset.y - 10,	GraphOffset.x - 3, GraphOffset.y + 3 - 10);
			e.gc.drawLine(GraphOffset.x, GraphOffset.y - 10,	GraphOffset.x + 3, GraphOffset.y + 3 - 10);
			e.gc.drawLine(GraphEnd.x + 10, GraphEnd.y,	GraphEnd.x - 3 + 10, GraphEnd.y + 3);
			e.gc.drawLine(GraphEnd.x + 10, GraphEnd.y,	GraphEnd.x - 3 + 10, GraphEnd.y - 3);
			
			// Draw x axis tick marks & text			
			for (f = 0; f < maxTime; f += xseparation)
			{
				p = new Point(GraphOffset.x + (int)(GraphSize.x * f / maxTime), GraphEnd.y);
				e.gc.drawLine(p.x, p.y, p.x, p.y + 3);
				
				swt.rotated.text.GraphicsUtils.drawVerticalText(Utilities.getTimeAsString2(f), p.x - (int)(h/2), p.y + 5, e.gc, SWT.DOWN);
			}
			
			// Draw y axis tick marks & text
			for (i = 0; i < maxchange + 1; i++)
			{
				p = new Point(GraphOffset.x, (int)(GraphEnd.y - yseparation * i));
				e.gc.drawLine(p.x - 3, p.y, p.x, p.y);
				if (delta > h * 1.5)
				{
					e.gc.drawText(String.valueOf(i), p.x - 20, p.y - (int)(h/2));
					delta = 0;
					
					// Draw longer tick mark on marks with text
					e.gc.drawLine(p.x - 5, p.y, p.x, p.y);
				}
				delta += yseparation;
			}
			
			// Plot data
			p = new Point(GraphOffset.x, GraphEnd.y);
			for (item = processedData.data; item != null; item = item.nextItem)
			{
				lastpoint = p;
				if (item.EventType == DataItem.NO_DATA)
					continue;
				else if (item.EventType == DataItem.NUMBER_OF_CHANGES)
				{
					p = new Point((int)(GraphOffset.x + item.Time * timefactor), (int)(GraphEnd.y - yseparation * item.NumberOfChanges));
				}
				else if (item.EventType == DataItem.REALITY_CHECKED)
				{
					p = new Point((int)(GraphOffset.x + item.Time * timefactor), GraphEnd.y);
				}
				else
				{
					p = new Point((int)(GraphOffset.x + item.Time * timefactor), lastpoint.y);
				}
				
				e.gc.drawLine(lastpoint.x, lastpoint.y, p.x, p.y);
				switch (item.EventType)
				{
					case DataItem.NUMBER_OF_CHANGES:	e.gc.setBackground(ColorSample); break;
					case DataItem.CUES_GIVEN:			e.gc.setBackground(ColorCues); break;
					case DataItem.REALITY_CHECKED:		e.gc.setBackground(ColorRealityCheck); break;
					case DataItem.ALARM_GIVEN:			e.gc.setBackground(ColorAlarm); break;
					case DataItem.NO_REM_DETECTED:		e.gc.setBackground(ColorBlack); break;
					case DataItem.PROGRAM_STARTED:
					case DataItem.PROGRAM_STOPPED:		e.gc.setBackground(ColorOther); break;
					default:							e.gc.setBackground(ColorUnknown); 
														System.out.println("Unknown event type: " +
																item.EventType); break;
				}
				
				
				e.gc.fillOval(p.x-2, p.y-2, 4, 4);
				e.gc.setBackground(ColorBackground);
			}
		}
	}
	
	private void ImportFromHex()
	{
		FileDialog dialog = new FileDialog(shell, SWT.NONE);
		dialog.setFilterNames(new String[]{"Hex Files (*.hex)", "All files"});
		dialog.setFilterExtensions(new String[]{"*.hex", "*.*"});
		String filename = dialog.open();
		
		if (filename != null)
		{
			try {
				rawData = RawData.ImportFromHEXFile(filename);
				ProcessData();
			}
			catch (IOException e) {
				MessageBox msg = new MessageBox(shell,
						SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
				msg.setText("Error");
				msg.setMessage("An error occured while trying to open the file\n'" +
						filename + "'.\nThe reported error was:\n\n" + e.getMessage());
				msg.open();
			}
		}
	}
	
	private void OpenSample()
	{
		try
		{
			InputStream stream = getClass().getClassLoader().getResourceAsStream("sample_data.hex");
			InputStreamReader reader = new InputStreamReader(stream);
			BufferedReader in = new BufferedReader(reader);
			rawData = RawData.ImportFromHEXStream(in);
			ProcessData();
		}
		catch (IOException e) {
			MessageBox msg = new MessageBox(shell,
					SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
			msg.setText("Error");
			msg.setMessage("An error occured while trying to open the sample data.\n" +
					"The reported error was:\n\n" + e.getMessage());
			msg.open();
		}
	}
	
	private void OpenData()
	{
		FileDialog dialog = new FileDialog(shell, SWT.NONE);
		dialog.setFilterNames(new String[]{Utilities.APP_NAME + " Data Files (*.mph)", "All files"});
		dialog.setFilterExtensions(new String[]{"*.mph", "*.*"});
		String filename = dialog.open();
		
		if (filename != null)
		{
			try {
				rawData = RawData.ReadDataFromFile(filename);
				ProcessData();
			}
			catch (IOException e) {
				MessageBox msg = new MessageBox(shell,
						SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
				msg.setText("Error");
				msg.setMessage("An error occured while trying to open the file\n'" +
						filename + "'.\nThe reported error was:\n\n" + e.getMessage());
				msg.open();
			}
		}
	}
	
	private void SaveData()
	{
		FileDialog dialog = new FileDialog(shell, SWT.SAVE);
		dialog.setFilterNames(new String[]{Utilities.APP_NAME + " Data Files (*.mph)", "All files"});
		dialog.setFilterExtensions(new String[]{"*.mph", "*.*"});
		String filename = dialog.open();
		if (filename != null)
		{
			try {
				RawData.SaveDataToFile(rawData, filename);
			}
			catch (IOException e) {
				MessageBox msg = new MessageBox(shell,
						SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
				msg.setText("Error");
				msg.setMessage("An error occured while trying to save the datato the file\n'" +
						filename + "'.\nThe reported error was:\n\n" + e.getMessage());
				msg.open();
			}
		}
	}
	
	private void Exit()
	{
		shell.dispose();
	}
	
	private void OpenSerial()
	{
		serialReader.GetDataFromSerial(this, selectedSerialPort);
	}
	
	private void ProcessData()
	{
		if (rawData == null)
			return;		
		
		// Clear tables
		table.clearAll();
		table.setItemCount(0);
		configTable.clearAll();
		configTable.setItemCount(0);
		
		processedData = ProcessedData.ProcessData(rawData);
		if (processedData == null)
			return;
		
		processedData.PostProcessData(bHideLastDataPointItem, bHideAwakeDataPointsItem);
		
		canvas.redraw();
		DataItem next = processedData.data;
		while (next != null)
		{
			if (next.EventType != DataItem.NO_DATA)
			{
				TableItem item = new TableItem(table,0);
				item.setText(new String[]{"T + " + Utilities.getTimeAsString2(next.Time),
						next.RawData == 0xFF ? "" : Utilities.charToHexString(next.RawData),
						next.EventString });
			}
			next = next.nextItem;
		}
		
	
		// Add config data to config table
		addConfigTableItem("Alarm", processedData.Conf_Alarm_Active == 1 ? "Enabled" : "Disabled");
		addConfigTableItem("Initial delay before scans", String.valueOf((processedData.Conf_Initial_Delay + 1) * 15) + " minutes");
		
		int numberOfCues = -1;
		
		switch (processedData.Conf_Number_Of_Cues) {
			case 0: numberOfCues = 3; break;
			case 1: numberOfCues = 5; break;
			case 2: numberOfCues = 10; break;
			default: numberOfCues = -1; break;
		}
		if (numberOfCues < 0)
			addConfigTableItem("Number of visual cues", "Unknown");
		else
			addConfigTableItem("Number of visual cues", String.valueOf(numberOfCues));
		
		if (processedData.Conf_Use_Sound_Signals == 0)
			addConfigTableItem("Sound cues", "Disabled");
		else if (processedData.Conf_Use_Sound_Signals == 1)
			addConfigTableItem("Sound cues", "1 cue only");
		else
			addConfigTableItem("Sound cues", String.valueOf(numberOfCues) + " cues");
			
		switch (processedData.Conf_Cues_Intensity) {
			case 0: addConfigTableItem("Cues intensity", "Minimum"); break;
			case 1: addConfigTableItem("Cues intensity", "Normal"); break;
			case 2: addConfigTableItem("Cues intensity", "Maximum"); break;
			default: addConfigTableItem("Cues intensity", "Unknown"); break;
		}

		// Add misc other data to config table
		addConfigTableItem("Delay between scans", String.valueOf(processedData.TimeBetweenScans / 60) + " minutes");
		addConfigTableItem("Delay before alarm", String.valueOf(processedData.TimeBeforeAlarmSounds / 60) + " minutes");
		addConfigTableItem("Delay increment on reality check", String.valueOf(processedData.TimeIncrementOnRealityCheck / 60) + " minutes");
		
		addConfigTableItem("A/D precision", rawData.AD_Scan_Mode == 0x0D ? "Coarse" : "Fine");
		addConfigTableItem("A/D jitter threshold", String.valueOf((int)rawData.AD_Jitter_Threshold));
		addConfigTableItem("Number of samples per scan", String.valueOf((int)rawData.Num_REM_Scans));
		
		addConfigTableItem("Minimum changes for REM detect", String.valueOf((int)rawData.Min_AD_Change_For_REM_Detect));
		addConfigTableItem("Time between A/D samples", Utilities.floatAsString(processedData.TimeBetweenADSamples * 1000, 2) + " ms");
		addConfigTableItem("Duration of REM scan", Utilities.floatAsString(processedData.DurationOfREMScan, 2) + " s");
		
		if (processedData.EEPROM_Usage > 0.99999)
			addConfigTableItem("EEPROM usage", "Filled");
		else
			addConfigTableItem("EEPROM usage", Utilities.floatAsString(processedData.EEPROM_Usage * 100, 1) + " %");
		
		if (processedData.compressed_data_bytes == 1)
			addConfigTableItem("Compressed data", "1 byte");
		else
			addConfigTableItem("Compressed data", String.valueOf(processedData.compressed_data_bytes) + " bytes");
		
		addConfigTableItem("Compression ratio", Utilities.floatAsString((float)processedData.compressed_data_bytes / (processedData.compressed_data_bytes + processedData.non_compressed_data_bytes) * 100, 1) + " %");
	}
	
	private void addConfigTableItem(String variable, String value)
	{
		TableItem item = new TableItem(configTable,0);
		item.setText(new String[]{variable, value});
	}	
	
	private void ViewEEPROMData()
	{
		if (rawData == null)
		{
			MessageBox msg = new MessageBox(shell,
					SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
			msg.setText("Error");
			msg.setMessage("No data to display. Try opening a file first.");
			msg.open();
		}
		else
		{
			// Create a new window
			Shell myShell = new Shell(display, SWT.APPLICATION_MODAL + SWT.DIALOG_TRIM);
			myShell.setLayout(new GridLayout());
			myShell.setText("EEPROM Content");
			myShell.setImage(programIcon);
			
			// Create text control
			Text textBox = new Text(myShell, SWT.WRAP); 		
			
			// Fill text control
			String text = "";
			for (int i = 0; i < 16; i++)
			{
				if (text != "")
					text = text + "\n";
				if (i%2 == 1)
					text += "0x" + String.valueOf((i-1)/2) + "8  ";
				else
					text += "0x" + String.valueOf(i/2) + "0  ";
				for (int j = 0; j < 8; j++)
				{
					text += " " + Utilities.charToHexString2(rawData.EEPROM_Data[i*8+j]);
				}
			}
			
			textBox.setText(text);
			textBox.setEditable(false);
			textBox.setFont(new Font(display,"Courier",10,SWT.NORMAL));
			textBox.setBackground(myShell.getBackground());
			
			// Create separator
			Label bar = new Label(myShell, SWT.HORIZONTAL | SWT.SEPARATOR);
			bar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
			
			// Create close button
			Button close = new Button(myShell, SWT.NONE);
			close.setText("Close");
			close.addSelectionListener(new SelectionListener() {
				public void widgetSelected(SelectionEvent e) {
					((Button)e.getSource()).getParent().dispose();
				}
				
				public void widgetDefaultSelected(SelectionEvent e) {}				
			});
			close.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
			myShell.setDefaultButton(close);
			
			myShell.pack();
			myShell.open();	
		}
	}
	
	private void About()
	{
		// Create new dialog
		Shell myShell = new Shell(display, SWT.APPLICATION_MODAL + SWT.DIALOG_TRIM);
		myShell.setLayout(new GridLayout());
		myShell.setText("About " + Utilities.APP_NAME);
		myShell.setImage(programIcon);
		
		// Create image
		InputStream stream = getClass().getClassLoader().getResourceAsStream("morpheus_splash.jpg");
		Image splash = new Image(display, stream);
		Label image = new Label(myShell, SWT.NONE);
		image.setImage(splash);
			
		// Create text box
		StyledText textBox = new StyledText(myShell, SWT.WRAP);
		textBox.setText(Utilities.GetAboutText());
		textBox.setStyleRange(Utilities.GetAboutStyleRange());
		textBox.setEditable(false);
		textBox.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		textBox.setBackground(myShell.getBackground());
		
		// Create separator
		Label bar = new Label(myShell, SWT.HORIZONTAL | SWT.SEPARATOR);
		bar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		// Create button bar
		Composite buttonBar = ButtonsSizer.createButtonBar(myShell);
		
		// Create close button
		Button close = new Button(buttonBar, SWT.NONE);
		close.setText("Close");
		close.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				((Button)e.getSource()).getParent().getParent().dispose();
			}
			
			public void widgetDefaultSelected(SelectionEvent e) {}				
		});
		myShell.setDefaultButton(close);
		ButtonsSizer.setButtonLayoutData(close);
		ButtonsSizer.addButton(buttonBar, close);
		
		myShell.pack();
		myShell.open();			
	}
	
	public void ProcessSerialData(char[] data)
	{
		rawData = RawData.ImportFromSerial(data);
		ProcessData();
	}

}
