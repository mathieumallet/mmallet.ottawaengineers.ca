/*
 * Created on Jun 22, 2005
 */
package morpheus;

import java.util.ArrayList;

/**
 * @author emh
 *
 * This file is used to contain processed data as well as do the processing of the raw data.
 */
public class ProcessedData {
	// Data fields
	public DataItem data = null;	// Linked list
	
	// Post-processing constants
	public float PostActivationDelay; // In seconds
	public float TimeBetweenScans; // In seconds
	public float TimeBeforeAlarmSounds; // In seconds
	public float TimeIncrementOnRealityCheck; // In seconds
	public float TimeBetweenADSamples; // In seconds
	public float DurationOfREMScan; // In seconds
	
	// Configuration values
	public int Conf_Alarm_Active;
	public int Conf_Initial_Delay;
	public int Conf_Use_Sound_Signals;
	public int Conf_Number_Of_Cues;
	public int Conf_Cues_Intensity;
	
	// Other stuff
	public int compressed_data_bytes = 0;
	public int non_compressed_data_bytes = 0;
	public float EEPROM_Usage = -1;
	
	// Constants
	private float TimeConversionFactor = 150; // uc time * factor = time in seconds

	public static ProcessedData ProcessData(RawData raw)
	{
		int i;
		boolean bStop;
		float currentTime;
		ArrayList data;
		char lastValue;
		boolean bAddCuesGivenMessage = false;
		
		DataItem lastItem = null, newItem;
		
		// Instanciate
		ProcessedData p = new ProcessedData();
		
		// Setup configuration values
		p.Conf_Alarm_Active = raw.EEPROM_Data[0];
		p.Conf_Initial_Delay = raw.EEPROM_Data[1];
		p.Conf_Use_Sound_Signals = raw.EEPROM_Data[2];
		p.Conf_Number_Of_Cues = raw.EEPROM_Data[3];
		p.Conf_Cues_Intensity = raw.EEPROM_Data[4];
		
		// Setup time conversion factor
		switch (raw.Timer1_Overflows_Per_150_Seconds)
		{
			case 29:	// 30 seconds timer period
				p.TimeConversionFactor = 30;
				break;
				
			case 59:	// 1 minute timer period
				p.TimeConversionFactor = 60;
				break;
		
			case 147:	// 2.5 minutes timer period
			default:
				p.TimeConversionFactor = 150;
				break;
			
		}
		
		// Setup constants
		p.TimeBetweenScans = raw.Time_Until_Next_Scan * p.TimeConversionFactor;
		p.TimeBeforeAlarmSounds = raw.Time_Until_Alarm_Sounds * p.TimeConversionFactor;
		p.PostActivationDelay = (p.Conf_Initial_Delay + 1) * 15 * 60;
		p.TimeIncrementOnRealityCheck = raw.Time_Increment_On_Reality_Check * p.TimeConversionFactor;
		p.TimeBetweenADSamples = ((1)+(2)+(2)+(raw.Time_Between_AD_Samples*768-raw.Time_Between_AD_Samples)+
				raw.Time_Between_AD_Samples+(raw.Time_Between_AD_Samples*3-1)+(2));
		p.TimeBetweenADSamples *= 2;
		p.TimeBetweenADSamples /= 1000000; // Convert from nanoseconds to seconds
		p.DurationOfREMScan = p.TimeBetweenADSamples * raw.Num_REM_Scans + p.TimeBetweenADSamples;
		
		// Decompress data
		data = new ArrayList(0);
		lastValue = 0x00;
		for (i = 0; i < raw.EEPROM_Data.length; i++)
		{
			if (DataItem.GetDataType(raw.EEPROM_Data[i]) == DataItem.NO_DATA)
			{
				if (p.EEPROM_Usage < 0 && i >= RawData.LOG_DATA_OFFSET
						&& !DataItem.eventTypeUsesTwoBytes(raw.EEPROM_Data[i - 1]))
					p.EEPROM_Usage = (float)(i - 1) / 128;
			}
			else
				p.non_compressed_data_bytes++;
			
			if (DataItem.GetDataType(raw.EEPROM_Data[i]) == DataItem.COMPRESSED_DATA
				&& DataItem.GetDataType(lastValue) != DataItem.PROGRAM_STARTED
				&& DataItem.GetDataType(lastValue) != DataItem.PROGRAM_STOPPED)
			{
				for (int k = 0; k < (raw.EEPROM_Data[i] - 0xD0 + 1); k++)
				{
					data.add(new Character(lastValue));
					if (k != 0)
						p.compressed_data_bytes++;
				}
			}
			else
			{
				lastValue = raw.EEPROM_Data[i];
				data.add(new Character(lastValue));
			}
		}
		if (p.EEPROM_Usage < 0)
			p.EEPROM_Usage = 1;
		
		// Process data
		i = RawData.LOG_DATA_OFFSET; // Start reading eeprom at 0x08
		bStop = false;
		currentTime = 0;
		
		while (!bStop)
		{
			newItem = new DataItem();
			newItem.Time = currentTime;
			if (bAddCuesGivenMessage)
			{
				// Add 'Cues Given' log message
				newItem.RawData = 0xFF;
				newItem.EventType = DataItem.CUES_GIVEN;
				bAddCuesGivenMessage = false;
			}
			else
			{
				// Add whatever message is present in the eeprom
				newItem.RawData = ((Character)data.get(i)).charValue();
				newItem.EventType = DataItem.GetDataType(newItem.RawData);
			}
			newItem.EventString = DataItem.GetEventString(newItem.EventType, newItem.RawData);
			
			switch (newItem.EventType)
			{
				case DataItem.PROGRAM_STARTED:
					newItem.EventLength = p.PostActivationDelay;
					if (i + 1 < data.size())
					{
						i++;
						newItem.EventString = newItem.EventString +
							", battery power = " + Utilities.charToHexString(((Character)data.get(i)).charValue());
					}				
					break;
				
				case DataItem.REALITY_CHECKED:
					// Check if we should shorten previous item's time
					if (lastItem != null && newItem.RawData * p.TimeConversionFactor < p.PostActivationDelay)
					{
						lastItem.EventLength = newItem.RawData * p.TimeConversionFactor - p.TimeIncrementOnRealityCheck;
						if (lastItem.EventLength < 0)
						{
							lastItem.EventLength = 0;
							currentTime = lastItem.Time;
							
						}
						else
						{
							currentTime = lastItem.Time + lastItem.EventLength;
						}
						newItem.Time = currentTime;
					}
					newItem.EventLength = newItem.RawData * p.TimeConversionFactor;
					break;
					
				case DataItem.REM_DETECTED:
					break;
				
				case DataItem.CUES_GIVEN:
					// Readjust previous item's time
					if (lastItem != null)
					{
						lastItem.EventLength = 0;
						currentTime = lastItem.Time;
						newItem.Time = currentTime;
					}
					
					if (p.Conf_Alarm_Active == 1)
						newItem.EventLength = p.TimeBeforeAlarmSounds;
					else
						newItem.EventLength = p.TimeBetweenScans;
					break;
				
				case DataItem.ALARM_GIVEN:
					break;
				
				case DataItem.REM_SCAN_STARTED:
					break;
					
				case DataItem.PROGRAM_STOPPED:
					newItem.EventLength = 60;
					if (i + 1 < data.size())
					{
						i++;
						newItem.EventString = newItem.EventString +
							", battery power = " + Utilities.charToHexString(((Character)data.get(i)).charValue());
					}
					break;
				
				case DataItem.DELAY_300_SEC_STARTED:
					newItem.EventLength = 300;
					break;
					
				case DataItem.PRE_ALARM_DELAY_STARTED:
					newItem.EventLength = p.TimeBeforeAlarmSounds;
					break;
					
				case DataItem.DELAY_OVER:
					break;
				
				case DataItem.NO_REM_DETECTED:
					break;
					
				case DataItem.INSTANT_SCAN_REQUESTED:
					// TODO: Need to add same code as for reality check
					break;
				
				case DataItem.NUMBER_OF_CHANGES:
					newItem.EventLength = p.TimeBetweenScans;
					newItem.NumberOfChanges = newItem.RawData - 0xB0;
					
					// Check if number of changes is over the limit for REM
					// detection
					if (newItem.NumberOfChanges > raw.Min_AD_Change_For_REM_Detect)
					{
						// Check if next item is a 'Cues Given' log message
						if (i + 1 >= data.size() ||
								DataItem.GetDataType(((Character)data.get(i + 1)).charValue()) != DataItem.CUES_GIVEN)
						{
							bAddCuesGivenMessage = true;
						}
					}
					
					break;
					
				case DataItem.NO_DATA:
					break;
			}
			
			currentTime += newItem.EventLength;
			
			if (p.data == null)
			{
				p.data = newItem;
				lastItem = newItem;
			}
			else
			{
				lastItem.nextItem = newItem;
				lastItem = newItem;
			}
			
			if (!bAddCuesGivenMessage)
				i++;
			if (i >= data.size())
			{
				bStop = true;
			}
		}
		
		// Add an empty data item so that last 'real' data item has its event lenght plotted
		// correctly
		if (p.data == null || lastItem == null)
			p.data = new DataItem();
		else
		{
			lastItem.nextItem = new DataItem();
			lastItem.nextItem.Time = lastItem.Time;
		}
		
		return p;
	}
	
	public void PostProcessData(boolean bRemoveLast, boolean bRemoveRealityCheckPairs)
	{
		DataItem item, secondToLastItem, lastItem, item2;
    	float delta;
    	boolean bDeleteGroup;
    	
		if (bRemoveLast)
		{
			secondToLastItem = null;
			// Seek to last item
			for (item = data; item != null; item = item.nextItem)
			{
				if (item.nextItem != null &&
						item.nextItem.EventType != DataItem.NO_DATA)
				{
					secondToLastItem = item;
				}
			}
				
			// Remove last item
			if (secondToLastItem != null)
				if (secondToLastItem.nextItem != null && secondToLastItem.nextItem.nextItem != null)
					secondToLastItem.nextItem = secondToLastItem.nextItem.nextItem;
				
		}
				
        if (bRemoveRealityCheckPairs)
        {
        	lastItem = null;
        	for (item = data; item != null; item = item.nextItem)
        	{
        		if (item.EventType == DataItem.NUMBER_OF_CHANGES)
        		{
        			// Check the next items up to x seconds ahead to see if there was
        			// a reality check
        			delta = 0;
        			bDeleteGroup = false;
        			for (item2 = item; item2 != null && delta <= TimeBetweenScans + 0.0001; item2 = item2.nextItem)
        			{
        				if (item2.EventType == DataItem.REALITY_CHECKED)
        				{
        					bDeleteGroup = true;
        					break;
        				}
        				delta += item2.EventLength;
        			}
        			
        			if (bDeleteGroup && lastItem != null)
        			{
        				lastItem.nextItem = item2;
        				item.nextItem = item2; // So that the for loop skips unlinked items
        			}
        		}
        		
        		lastItem = item;
        	}
        }
	}
}
