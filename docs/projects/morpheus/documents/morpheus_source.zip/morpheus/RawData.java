/*
 * Created on Jun 21, 2005
 */
package morpheus;

import java.io.*;

/**
 * @author emh
 *
 * This class is used to contain raw data. It is also used to save and load this
 * data from binary files as well as import data from .hex files.
 */
public class RawData
	implements java.io.Serializable
{
	public char[] EEPROM_Data = new char[128];
	public char AD_Scan_Mode = 0x0D;
	public char AD_Jitter_Threshold = 2;
	public char Num_REM_Scans = 40;
	public char Time_Between_AD_Samples = 130;
	public char Min_AD_Change_For_REM_Detect = 4;
	public char Time_Until_Next_Scan = 1;
	public char Time_Until_Alarm_Sounds = 2;
	public char Time_Increment_On_Reality_Check = 10;
	public char Timer1_Overflows_Per_150_Seconds = 147;
	
	public static final int TOTAL_NUMBER_OF_BYTES_IN_SERIAL = 143;
	public static final int LOG_DATA_OFFSET = 0x08;
	
	public static RawData CreateSampleRawData()
	{
		RawData data = new RawData();
		
		char tmp[] = {	0x00, 0x04, 0x01, 0x01, 0x01, 0x00, 0x00, 0xFF, 
						0xA1, 0xC0, 0xB3, 0xBC, 0xA4, 0xB3, 0xB2, 0xB2,
						0xB4, 0xA4, 0x0B, 0xB3, 0xB3, 0xB3, 0xB3, 0xB4,
						0xA4, 0xB2, 0xB3, 0xB3, 0xB2, 0xB3, 0xB3, 0xB3,

						0xB4, 0xA4, 0x0B, 0xB3, 0xB3, 0xB3, 0xB3, 0xB4,
						0xA4, 0xB2, 0xB3, 0xB3, 0xB2, 0xB3, 0xB3, 0xB3,
						0xB4, 0xA4, 0x0B, 0xB3, 0xB3, 0xB3, 0xB3, 0xB4,
						0xA4, 0xB2, 0xB3, 0xB3, 0xB2, 0xB3, 0xB3, 0xB3,
						
						0xB4, 0xA4, 0x0B, 0xB3, 0xB3, 0xB3, 0xB3, 0xB4,
						0xA4, 0xB2, 0xB3, 0xB3, 0xB2, 0xB3, 0xB3, 0xB3,
						0xB4, 0xA4, 0x0B, 0xB3, 0xB3, 0xB3, 0xB3, 0xB4,
						0xA4, 0xB2, 0xB3, 0xB3, 0xB2, 0xB3, 0xB3, 0xB3,
						
						0xB4, 0xA4, 0x0B, 0xB3, 0xB3, 0xB3, 0xB3, 0xB4,
						0xA4, 0xB2, 0xB3, 0xB3, 0xB2, 0xB3, 0xB3, 0xB3,
						0xB4, 0xA4, 0x0B, 0x15, 0x0B, 0xB3, 0xB5, 0xA4,
						0xB5, 0xA4, 0x0B, 0xB5, 0xA4, 0x0C, 0xB3, 0xA7  };
		
		data.EEPROM_Data = tmp;
						
		return data;		
	}
	
	public static RawData ImportFromHEXFile(String filename)
		throws IOException
	{
		File inputFile = new File(filename);
		FileReader inFile = new FileReader(inputFile);
		BufferedReader in = new BufferedReader(inFile);
		
		RawData data = ImportFromHEXStream(in);
		
		in.close();
		inFile.close();

		return data;
	}
	
	public static RawData ImportFromHEXStream(BufferedReader in)
		throws IOException
	{
		String currentLine;
		char[] bytes;
		boolean bContinue;
		int count = 0;
		RawData data = new RawData();
		
		currentLine = in.readLine();
		
		// Check if header is correct
		if (!currentLine.equals(":020000040000FA"))
			throw new IOException("Header not found in file. This is most likely not a memory dump file.");
		
		
		// Read configuration data
		bContinue = false;
		while (currentLine != null)
		{
			// Search for configuration data line
			if (currentLine.substring(0, 9).equals(":1007E000"))
			{
				bytes = Utilities.extractBytesFromHexLine(currentLine);
				if (bytes == null)
					throw new IOException("Unable to parse configuration data in file. This is most likely not a memory dump file.");
				
				// Check if there *is* a configuration line...
				if ((bytes[0] & 0x3800) == 0x2800)
				{
					// doh! no configuration line, use defaults.
					bContinue = true;
					break;
				}
				else
				{
					// Read configs.
					data.AD_Scan_Mode = (char)(bytes[0] & 0x00FF);
					data.AD_Jitter_Threshold = (char)(bytes[1] & 0x00FF);
					data.Num_REM_Scans = (char)(bytes[2] & 0x00FF);
					data.Time_Between_AD_Samples = (char)(bytes[3] & 0x00FF);
					data.Min_AD_Change_For_REM_Detect = (char)(bytes[4] & 0x00FF);
					data.Time_Until_Next_Scan = (char)(bytes[5] & 0x00FF);
					data.Time_Until_Alarm_Sounds = (char)(bytes[6] & 0x00FF);
					data.Time_Increment_On_Reality_Check = (char)(bytes[7] & 0x00FF);
					bContinue = true;
					
					// Try to read next line
					currentLine = in.readLine();
					bytes = Utilities.extractBytesFromHexLine(currentLine);
					if (bytes == null)
						throw new IOException("Unable to parse configuration data in file. This is most likely not a memory dump file.");
					
					// Check if there's a saved value, else use default
					if ((bytes[0] & 0x3800) != 0x2800)
						data.Timer1_Overflows_Per_150_Seconds = (char)(bytes[0] & 0x00FF);
					
					break;
				}
			}
			currentLine = in.readLine();
		}
		
		if (!bContinue)
			throw new IOException("Unable to find configuration data in file. This is most likely not a memory dump file.");

		
		// Seek to beginning of EEPROM data
		while (currentLine != null)
		{
			currentLine = in.readLine();
			if (currentLine.substring(0, 9).equals(":10420000"))
				break;
		}
			
		if (currentLine == null)
			throw new IOException("Unable to find EEPROM data in file. This is most likely not a memory dump file.");
		
		
		// Read EEPROM data
		count = 0;
		while (currentLine != null && count < 128)
		{
			bytes = Utilities.extractBytesFromHexLine(currentLine);
			if (bytes == null)
				throw new IOException("Unable to parse EEPROM data in file. This is most likely an incomplete memory dump file.");

			for (int i = 0; i < 8; i++)
				data.EEPROM_Data[count + i] = bytes[i];

			count += 8;
			
			currentLine = in.readLine();
		}
		
		if (count < 128)
			throw new IOException("Unable to find all EEPROM data in file. This is most likely an incomplete memory dump file.");
		
		return data;
	}
	
	public static void SaveDataToFile(RawData data, String filename)
		throws IOException
	{
		if (data == null)
			throw new IOException("RawData object is empty.");
		
		FileOutputStream f_out = new FileOutputStream(filename);
		ObjectOutputStream obj_out = new ObjectOutputStream (f_out);
		obj_out.writeObject(data);
		obj_out.close();
		f_out.close();
	}
	
	public static RawData ReadDataFromFile(String filename)
		throws IOException
	{
		FileInputStream f_in = new FileInputStream(filename);
		ObjectInputStream obj_in = new ObjectInputStream (f_in);
		try {
			Object obj = obj_in.readObject();
			if (obj instanceof RawData)
			{
				return (RawData) obj;
			}
		}
		catch (ClassNotFoundException e) {
			// Handled by throwind an IOException
		}
		
		throw new IOException("Could not find required data in file.");
	}

	public static RawData ImportFromSerial(char[] bytes)
	{
		int i;
		RawData data = new RawData();
		
		// Read eeprom data
		for (i = 0; i < 128; i++)
			data.EEPROM_Data[i] = bytes[i + 2];
		
		i+= 2;
		
		// Read configs.
		data.AD_Scan_Mode = bytes[i++];
		data.AD_Jitter_Threshold = bytes[i++];
		data.Num_REM_Scans = bytes[i++];
		data.Time_Between_AD_Samples = bytes[i++];
		data.Min_AD_Change_For_REM_Detect = bytes[i++];
		data.Time_Until_Next_Scan = bytes[i++];
		data.Time_Until_Alarm_Sounds = bytes[i++];
		data.Time_Increment_On_Reality_Check = bytes[i++];
		data.Timer1_Overflows_Per_150_Seconds = bytes[i++];
		
		return data;
	}
}
