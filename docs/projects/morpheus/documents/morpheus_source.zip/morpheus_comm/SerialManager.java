/*
 * Created on Jul 12, 2005
 */
package morpheus_comm;

import morpheus.MainGUI;
import morpheus.RawData;
import morpheus.Utilities;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.events.ShellListener;
import org.eclipse.swt.graphics.Image;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Enumeration;
import java.util.Vector;

import javax.comm.CommPortIdentifier;

/**
 * @author emh
 *
 * This class is used to manage serial drivers, com ports and
 * serial communications.
 */
public class SerialManager {
	private boolean bInitialized = false;
	
	private SerialReceiver receiver;
	private Shell progressDialog;
	private Shell shell;
	private Display display;
	private MainGUI gui;
	public ProgressBar progress;
	private int progress_value;
	private boolean bCancelled;
	
	/**
	 * This function initializes the driver for serial I/O.
	 * This is necessary because of bone-headed programming of the
	 * javacomm library.
	 */
	public void Initialize()
	{
		if (bInitialized)
			return;
		
		String driverName;
		
		// Get driver name
		Properties commProps = new Properties();
		InputStream propStream = getClass().getClassLoader().getResourceAsStream("morpheus.comm.properties");
		if (propStream == null)
			return;
		try {
			commProps.load(propStream);
			driverName = commProps.getProperty("Driver");
			propStream.close();
			if (driverName == "")
				return;
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return;
		}
		
		if (!driverName.equalsIgnoreCase("com.sun.comm.Win32Driver"))
		{
			System.out.println("Serial communication support is unavailable for this architecture.");
			return;
		}
		
		System.setSecurityManager(null);
		//String driverName = "com.sun.comm.Win32Driver";
		try
		{
			javax.comm.CommDriver commDriver = (javax.comm.CommDriver)Class.forName( driverName ).newInstance();
			commDriver.initialize();
			bInitialized = true;
		}
		catch (ClassNotFoundException e) { e.printStackTrace(); }
		catch (InstantiationException e) { e.printStackTrace(); }
		catch (IllegalAccessException e) { e.printStackTrace(); }			
		catch (java.lang.ClassCastException e) { e.printStackTrace(); }
	}
	
	public String[] GetPorts() {
		if (!bInitialized)
			return null;
		
		String[] ports;
		Vector portsVector = new Vector();
	    CommPortIdentifier portId;
	    Enumeration portList;
	    portList = CommPortIdentifier.getPortIdentifiers();

	    ports = new String[1];
	    
	    while (portList.hasMoreElements()) {
	    	portId = (CommPortIdentifier) portList.nextElement();
	        if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
	        	portsVector.add(new String(portId.getName()));
	        }
	    }

	    if (portsVector.size() == 0)
	    	return null;
	    
	    // Convert Strings enumeration to String[] list
	    ports = new String[portsVector.size()];
	    for (int i = 0; i < portsVector.size(); i++)
	    {
	    	ports[i] = (String) portsVector.elementAt(i);
	    }	    
	    
	    return ports;
	}	
	
	public void GetDataFromSerial(MainGUI gui, String comPort)
	{
		if (!bInitialized)
			return;
		
		// Attempt to open serial port
		if (receiver == null)
			receiver = new SerialReceiver();
		
		bCancelled = false;
		
		if (!receiver.openSerialPort(comPort))
		{
			MessageBox msg = new MessageBox(gui.shell,
					SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
			msg.setText("Error");
			msg.setMessage("Unable to open serial port '" + comPort + "'. Ensure that no other program is currently using it.");
			msg.open();
			return;
		}
		
		// Display status dialog and initiate transfer
		this.gui = gui;
		display = gui.display;
		shell = gui.shell;
		progressDialog = CreateProgressDialog(gui.programIcon);
		receiver.startTransmission(this);
	}
	
	public Shell CreateProgressDialog(Image programIcon)
	{
		// Create new dialog
		Shell myShell = new Shell(display, SWT.APPLICATION_MODAL + SWT.DIALOG_TRIM);
		myShell.setLayout(new GridLayout());
		myShell.setText("Serial communication");
		myShell.setImage(programIcon);
		myShell.addShellListener(new ShellListener(){
			public void shellActivated(ShellEvent e) {}
			public void shellClosed(ShellEvent e) {
				Cancel();
			}
			public void shellDeactivated(ShellEvent e) {}
			public void shellDeiconified(ShellEvent e) {}
			public void shellIconified(ShellEvent e) {}
		});
		
		// Create label
		Label progressText = new Label(myShell, SWT.WRAP);
		progressText.setText("Importing data from serial port...");

		// Create progress bar
		progress = new ProgressBar(myShell, SWT.HORIZONTAL);
		
		// Create separator
		Label bar = new Label(myShell, SWT.HORIZONTAL | SWT.SEPARATOR);
		bar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		// Create cancel button
		Button cancel = new Button(myShell, SWT.NONE);
		cancel.setText("Cancel");
		cancel.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				Cancel();
			}
			
			public void widgetDefaultSelected(SelectionEvent e) {}				
		});
		cancel.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
		myShell.setDefaultButton(cancel);		
		
		myShell.pack();
		myShell.open();
		
		return myShell;
	}
	
	private void Cancel()
	{
		bCancelled = true;
		receiver.abort();
	}
	
	public void SerialReceiverDoneCallback()
	{
		display.syncExec (
			new Runnable() {
				public void run(){
					SerialReceiverDoneCallbackFix();
				}
			}
		);
	}
	
	public void SerialReceiverDoneCallbackFix()
	{
		if (progressDialog != null && !progressDialog.isDisposed())
			progressDialog.dispose();
		
		if (bCancelled)
			return;

		if (!receiver.bDataOK)
		{
			MessageBox msg = new MessageBox(shell,
					SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
			msg.setText("Error");
			msg.setMessage("Unable to acquire data from serial port. Ensure that the device is plugged in, powered up and in the Serial Communication mode.");
			msg.open();
			return;
		}
		
		char[] data = receiver.GetData();
		
		String text = "Data =";
		for (int i = 0; i < data.length; i++)
			text += " " + Utilities.charToHexString(data[i]);
		System.out.println(text);

		// Check if data was received properly

		// First check header...
		if (data[0] != 0xAA || data[1] != 0xCD)
		{
			MessageBox msg = new MessageBox(shell,
					SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
			msg.setText("Error");
			msg.setMessage("Data corruption error: header of received data is incorrect. Check device connections.");
			msg.open();
			return;
		}
		
		// Then check footer...
		if (data[RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL - 4] != 0xCD ||
				data[RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL - 3] != 0xAA)
		{
			MessageBox msg = new MessageBox(shell,
					SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
			msg.setText("Error");
			msg.setMessage("Data corruption error: footer of received data is incorrect. Check device connections.");
			msg.open();
			return;
		}		
	
		// Then check checksums...
		char checksum = 0;
		for (int i = 0; i < RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL - 2; i++)
		{
			checksum = (char)(checksum ^ data[i]);
		}
		char checksum2 = (char)(checksum ^ data[RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL - 2]);
		if (checksum != data[RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL - 2] ||
				checksum2 != data[RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL - 1])
		{
			MessageBox msg = new MessageBox(shell,
					SWT.OK | SWT.ICON_ERROR | SWT.APPLICATION_MODAL);
			msg.setText("Error");
			msg.setMessage("Data corruption error: checksum of received data is incorrect. Check device connections.");
			msg.open();
			return;
		}
		
		gui.ProcessSerialData(data);
	}
	
	public void updateProgress(int value)
	{
		if (progress == null)
			return;
			
		progress_value = value;
		display.syncExec (
			new Runnable() {
				public void run(){
					progress.setSelection(progress_value);
				}
			}
		);
	}
}
