/*
 * Created on Jul 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package morpheus_comm;

import morpheus.Utilities;
import morpheus.RawData;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TooManyListenersException;

import javax.comm.*;

/**
 * @author emh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SerialReceiver implements SerialPortEventListener
{
	private String comPort;
	private InputStream inputStream;
	private OutputStream outputStream;
	private SerialPort serialPort;	
	private SerialManager caller;
	private Timer timeout;
	private char[] serialData;
	private int serialPointer;
	
	private boolean bRunning;
	public boolean bDataOK;
	
	// Constants
	private final int BAUDRATE = 9600;
	private final int DATABITS = SerialPort.DATABITS_8;
    private final int STOPBITS = SerialPort.STOPBITS_1;
    private final int PARITY = SerialPort.PARITY_NONE;
    private final long TIMEOUT_DELAY = 5000;
    
	
	public boolean openSerialPort(String comPort)
	{
		CommPortIdentifier portId;
		
		// Get port ID
		portId = GetPort(comPort);
		if (portId == null)
			return false;
		
		// Open serial port
		try {
			serialPort = (SerialPort) portId.open("Morpheus", 2000);
		}
		catch (PortInUseException e)
		{
			return false;
		}
		
		try {
	        inputStream = serialPort.getInputStream();
	        outputStream = serialPort.getOutputStream();
		}
		catch (IOException e)
		{
			return false;
		}
	    
		try {
	        serialPort.addEventListener(this);
	    } catch (TooManyListenersException e) {
	    	return false;
	    }
	    
	    serialPort.notifyOnDataAvailable(true);		
		
	    try {
			serialPort.setSerialPortParams(BAUDRATE, DATABITS, STOPBITS, PARITY);
		}
		catch (UnsupportedCommOperationException e) {
			return false;
		}
		return true;
	}
	
	public void startTransmission(SerialManager caller)
	{
		// Setup callback
		this.caller = caller;

		// Setup time-out callback
		timeout = new Timer();
		TimerTask timeoutTask = new TimerTask() {
			public void run() {
				timeoutOccured();
			}
		};
		timeout.schedule(timeoutTask, TIMEOUT_DELAY);
		
		// Setup progress data
		if (caller.progress != null)
		{
			caller.progress.setMinimum(0);
			caller.progress.setMaximum(RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL);
			caller.progress.setSelection(0);
		}
		
		// Initialize data
		serialPointer = 0;
		serialData = new char[RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL];
		bDataOK = false;
		bRunning = true;
		
		// Send one byte to device to start serial dumping
	    try {
	    	outputStream.write(0x0f);
	    } catch (IOException e) {
	    	System.out.println("Error writing to serial port");
	    }		
	}
	
	private void timeoutOccured()
	{
		abort();
	}
	
	public void abort()
	{
		bRunning = false;
		cleanUp();
		caller.SerialReceiverDoneCallback();
	}
	
	private void receptionCompleted()
	{
		bRunning = false;
		cleanUp();
		bDataOK = true;
		caller.SerialReceiverDoneCallback();
	}	
	
	private void cleanUp()
	{
		if (timeout != null)
		{
			timeout.cancel();
			timeout = null;
		}
		
		if (inputStream != null)
		{
			synchronized(inputStream)
			{
				try {
					inputStream.close();
				} catch (IOException e)
				{
					System.out.println("Unable to close serial input stream: " + e.getMessage());
				}
				inputStream = null;
				
				try {
					if (outputStream != null)
						outputStream.close();
				} catch (IOException e)
				{
					System.out.println("Unable to close serial output stream: " + e.getMessage());
				}
				outputStream = null;	
				
				serialPort.close();
				serialPort = null;
			}
		}
	}
	
	public char[] GetData()
	{
		return serialData;
	}
	
	
	
	/**
	 * This function gets a CommPortIdentifier from a string describing
	 * a COM port.
	 * @param comPort String describing the port to be open (e.g. 'COM1')
	 * @return A CommPortIdentifier object.
	 */
	private static CommPortIdentifier GetPort(String comPort) {
		Enumeration portList;
	    CommPortIdentifier portId;
	    portList = CommPortIdentifier.getPortIdentifiers();

	    while (portList.hasMoreElements())
	    {
	        portId = (CommPortIdentifier) portList.nextElement();
	        if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
	            if (portId.getName().equals(comPort)) {
	                return portId;
	            }
	        }
	    }
	    return null;
	  }	

	/* (non-Javadoc)
	 * @see javax.comm.SerialPortEventListener#serialEvent(javax.comm.SerialPortEvent)
	 */
	public void serialEvent(SerialPortEvent event) {
		byte[] oneByte = new byte[1];
		int junk;
		switch(event.getEventType()) {
			case SerialPortEvent.DATA_AVAILABLE:
				try {
					if (bRunning)
					{
						while (inputStream != null && inputStream.available() > 0 &&
								serialPointer < RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL)
						{
							junk = inputStream.read(oneByte, 0, 1);
							
							serialData[serialPointer] = Utilities.convertByteToChar(oneByte[0]);

							// Update progress bar
							caller.updateProgress(serialPointer);

							serialPointer++;							
							
							// Check if we received all of the data
							if (serialPointer == RawData.TOTAL_NUMBER_OF_BYTES_IN_SERIAL)
							{
								System.out.println("Received all data.");
								receptionCompleted();
							}
						}
					}
				} catch (IOException e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
				
			default:
				break;
		}

	}	
	
}
