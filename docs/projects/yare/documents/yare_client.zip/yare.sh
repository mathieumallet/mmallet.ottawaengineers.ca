#/bin/sh
echo Starting YARE...
java -classpath comm.jar:jbcl.jar:yare.jar serialcommproj.MainGUI

