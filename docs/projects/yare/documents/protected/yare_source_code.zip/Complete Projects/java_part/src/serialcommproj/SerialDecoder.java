package serialcommproj;

import java.util.Vector;
import java.util.TimerTask;
import java.util.Timer;

/**
 * <p>Title: SerialDecoder</p>
 * <p>Description: Takes raw byte steam received over serial link and checks it's integrity. Creates a serial packet and passes it the actual data stream.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Mathieu Mallet
 * @version 1.0
 */

public class SerialDecoder implements Runnable {
  private Vector MyFIFO;
  private Thread myThread;
  private Vector DataVector;
  private MainGUI gui;
  private CommandManager cmdMan;

  private boolean packetOK[] = new boolean[50];
  private int integrityIndex = 0;
  private IntegrityTimerTask myTimerTask;
  private Timer myTimer;

  public double[] IRLLookup = new double[256];
  public double[] IRMLookup = new double[256];
  public double[] IRRLookup = new double[256];

	/**
	 * Constructor for objects of class SerialDecoder.
	 * @param gui Reference to the MainGUI object.
	 * @param DataVector Reference to the DataVector object. This object contains decoded SerialPacket objects.
	 */
  public SerialDecoder(MainGUI gui, Vector DataVector) {
    this.DataVector = DataVector;
    this.gui = gui;
    FillLookupTables();
    myTimerTask = new IntegrityTimerTask(gui, this);
    myTimer = new Timer();
    myTimer.scheduleAtFixedRate(myTimerTask, 10, 500);
    Init();
  }

	/**
	 * Initialises the object.
	 *
	 */
  public void Init() {
    int i;
    for (i = 0; i < packetOK.length; i++)
      packetOK[i] = true;

    MyFIFO = new Vector();
    myThread = new Thread(this);
    myThread.start();
  }

  /**
   * Threaded code. Processes elements when they are available and suspends itself otherwise.
   */
  public void run() {
    while(true) {
        if (MyFIFO.isEmpty()) {
          myThread.suspend();
        }
        else {
          Process(MyFIFO.firstElement());
          MyFIFO.remove(0);
        }
    }
  }

  /**
   * Used to signal the thread that a packet is ready to be processed.
   * @param data Array containing the raw data.
   */
  public void AddPacket(Object data) {
    MyFIFO.add(data);
    myThread.resume();
  }

  /**
   * Returns and removes a single SerialPacket from the DataVector. 
   * @return The first SerialPacket object of the DataVector vector.
   */
  public SerialPacket RemoveData() {
    SerialPacket aPacket;
    aPacket = (SerialPacket)DataVector.get(0);
    DataVector.remove(0);
    return aPacket;
  }

	/**
	 * Processes a raw byte stream, checks for reliability and creates a SerialPacket out of it.
	 * @param myData Array of bytes containing the data to be processed.
	 */
  public void Process(Object myData) {
    byte[] RawData = new byte[45];
    int i, j, bitCount, byteCount;
    byte b1, b2, b3;
    byte[] Packet1 = new byte[13];
    byte[] Packet2 = new byte[13];
    byte[] Packet3 = new byte[13];
    byte[] Packet = new byte[13];

    RawData = (byte[])myData;

    byteCount = 0;
    bitCount = 0;
    for (i = 0; i < 15; i++) {
      b1 = RawData[i];
      b2 = RawData[i+15];
      b3 = RawData[i+30];
      for (j = 0; j < 7; j++) {
        if (bitCount == 8) {
          bitCount = 0;
          byteCount++;
          if (byteCount >= 13)
            break;
          Packet1[byteCount] = 0;
          Packet2[byteCount] = 0;
          Packet3[byteCount] = 0;
        }
        if (((b1 >> j) & 1) == 1)
          Packet1[byteCount] |= (1 << bitCount);
        if (((b2 >> j) & 1) == 1)
          Packet2[byteCount] |= (1 << bitCount);
        if (((b3 >> j) & 1) == 1)
          Packet3[byteCount] |= (1 << bitCount);
        bitCount++;
      }
    }

    for (i = 0; i < 13; i++) {
      Packet[i] = (byte)((int)Packet1[i] & (int)Packet2[i]);
      Packet[i] = (byte)((int)Packet[i] | ((int)Packet3[i] & (int)Packet2[i]));
      Packet[i] = (byte)((int)Packet[i] | ((int)Packet1[i] & (int)Packet3[i]));
    }

    if (CalcSum(Packet)) {
      addPacketIntegrity(true);
      AddDataToStack(Packet);
    }
    else {
      addPacketIntegrity(false);
    }

  }

	/**
	 * Calculates 8-bit checksum on the given 12 bytes and check weather the checksum matches the 13th byte.
	 * @param bits Array containing 12 bytes of data and 1 byte of checksum.
	 * @return True if the checksum matches, false otherwise.
	 */
  private boolean CalcSum(byte[] bits) {
    byte checksum;
    int i, sum;

    checksum = 0;
    for (i = 0; i < 12; i++) {
      checksum += bits[i];
    }

    return bits[12] == checksum;
  }

 	/**
 	 * Adds a stream of bytes to the 'waiting to be processed' vector.
 	 * @param bits Array of bytes to be processed.
 	 */
  private void AddDataToStack(byte[] bits) {
    SerialPacket data = new SerialPacket(bits, gui);
    DataVector.add(data);
    if (gui != null)
      gui.PacketAvailable();
    if (cmdMan != null)
      cmdMan.CheckCommand(data);
  }

	/**
	 * Updates overall integrity from the integrity of the last received packet.
	 * @param OK True if last packet was ok, false if it was corrupt.
	 */
  private void addPacketIntegrity(boolean OK) {
    packetOK[integrityIndex] = OK;
    integrityIndex = (integrityIndex + 1) % packetOK.length;
    gui.updateLastPacket(OK);
  }

	/**
	 * Returns packet integrity.
	 * @return Value between 0 and 1 describing integrity of received data.
	 */
  public float getPacketIntegrity() {
    int i, result = 0;

    for (i = 0; i < packetOK.length; i++)
      if (packetOK[i])
        result++;

    return (float)result / packetOK.length;
  }

	/**
	 * Class used to generate timer events. Used to update the integrity of the packets on the GUI every second or so.
	 * 
	 */
  public class IntegrityTimerTask extends TimerTask {
    private MainGUI gui;
    private SerialDecoder decoder;
    public void run() {
      gui.updateIntegrity(decoder.getPacketIntegrity());
    }

    public IntegrityTimerTask(MainGUI gui, SerialDecoder decoder) {
      this.gui = gui;
      this.decoder = decoder;
    }
  }

	/**
	 * Clear all data.
	 * @param newDataVector Reference to new DataVector object.
	 */
  public void ClearData(Vector newDataVector) {
    MyFIFO = new Vector();
    DataVector = newDataVector;
    cmdMan = null;
    System.out.println("Serialdecoder data cleared.");
  }

	/**
	 * Sets a reference to a command manager. If a command manager is present, this class will notify it each time a packet is sucessfully received.
	 * @param cmdMan Reference to a CommandManager object.
	 */
  public void SetCommandManager(CommandManager cmdMan) {
    this.cmdMan = cmdMan;
  }

	/**
	 * Removes reference to a command manager.
	 *
	 */
  public void UnsetCommandManager() {
    cmdMan = null;
  }

	/**
	 * Fills lookup tables used to calculate distances from IR sensor codes.
	 *
	 */
  private void  FillLookupTables() {
    int i;
    for (i = 0; i < 70; i++) {
      IRLLookup[i] = 10000;
      IRMLookup[i] = 10000;
      IRRLookup[i] = 10000;
    }

    IRLLookup[70] = 3.637833e+002;
    IRLLookup[71] = 3.342585e+002;
    IRLLookup[72] = 3.064359e+002;
    IRLLookup[73] = 2.802928e+002;
    IRLLookup[74] = 2.558067e+002;
    IRLLookup[75] = 2.329550e+002;
    IRLLookup[76] = 2.117152e+002;
    IRLLookup[77] = 1.920646e+002;
    IRLLookup[78] = 1.739807e+002;
    IRLLookup[79] = 1.574409e+002;
    IRLLookup[80] = 1.424226e+002;
    IRLLookup[81] = 1.289033e+002;
    IRLLookup[82] = 1.168602e+002;
    IRLLookup[83] = 1.062710e+002;
    IRLLookup[84] = 9.711291e+001;
    IRLLookup[85] = 8.936344e+001;
    IRLLookup[86] = 83;
    IRLLookup[87] = 78;
    IRLLookup[88] = 7.434086e+001;
    IRLLookup[89] = 72;
    IRLLookup[90] = 7.068199e+001;
    IRLLookup[91] = 69;
    IRLLookup[92] = 66;
    IRLLookup[93] = 63;
    IRLLookup[94] = 60;
    IRLLookup[95] = 57;
    IRLLookup[96] = 54;
    IRLLookup[97] = 5.218241e+001;
    IRLLookup[98] = 51;
    IRLLookup[99] = 4.958608e+001;
    IRLLookup[100] = 48;
    IRLLookup[101] = 4.647325e+001;
    IRLLookup[102] = 45;
    IRLLookup[103] = 4.352091e+001;
    IRLLookup[104] = 42;
    IRLLookup[105] = 4.044313e+001;
    IRLLookup[106] = 39;
    IRLLookup[107] = 3.781150e+001;
    IRLLookup[108] = 3.683923e+001;
    IRLLookup[109] = 36;
    IRLLookup[110] = 3.522139e+001;
    IRLLookup[111] = 3.447415e+001;
    IRLLookup[112] = 3.373984e+001;
    IRLLookup[113] = 33;
    IRLLookup[114] = 3.224217e+001;
    IRLLookup[115] = 3.147788e+001;
    IRLLookup[116] = 3.072464e+001;
    IRLLookup[117] = 30;
    IRLLookup[118] = 2.931811e+001;
    IRLLookup[119] = 2.867975e+001;
    IRLLookup[120] = 2.808234e+001;
    IRLLookup[121] = 2.752328e+001;
    IRLLookup[122] = 27;
    IRLLookup[123] = 2.650956e+001;
    IRLLookup[124] = 2.604760e+001;
    IRLLookup[125] = 2.560941e+001;
    IRLLookup[126] = 2.519026e+001;
    IRLLookup[127] = 2.478546e+001;
    IRLLookup[128] = 2.439027e+001;
    IRLLookup[129] = 24;
    IRLLookup[130] = 2.361092e+001;
    IRLLookup[131] = 2.322331e+001;
    IRLLookup[132] = 2.283845e+001;
    IRLLookup[133] = 2.245761e+001;
    IRLLookup[134] = 2.208206e+001;
    IRLLookup[135] = 2.171310e+001;
    IRLLookup[136] = 2.135199e+001;
    IRLLookup[137] = 21;
    IRLLookup[138] = 2.065816e+001;
    IRLLookup[139] = 2.032641e+001;
    IRLLookup[140] = 2.000447e+001;
    IRLLookup[141] = 1.969203e+001;
    IRLLookup[142] = 1.938879e+001;
    IRLLookup[143] = 1.909445e+001;
    IRLLookup[144] = 1.880870e+001;
    IRLLookup[145] = 1.853124e+001;
    IRLLookup[146] = 1.826177e+001;
    IRLLookup[147] = 18;
    IRLLookup[148] = 1.774562e+001;
    IRLLookup[149] = 1.749839e+001;
    IRLLookup[150] = 1.725806e+001;
    IRLLookup[151] = 1.702439e+001;
    IRLLookup[152] = 1.679713e+001;
    IRLLookup[153] = 1.657603e+001;
    IRLLookup[154] = 1.636086e+001;
    IRLLookup[155] = 1.615137e+001;
    IRLLookup[156] = 1.594731e+001;
    IRLLookup[157] = 1.574845e+001;
    IRLLookup[158] = 1.555453e+001;
    IRLLookup[159] = 1.536531e+001;
    IRLLookup[160] = 1.518055e+001;
    IRLLookup[161] = 15;
    IRLLookup[162] = 1.482345e+001;
    IRLLookup[163] = 1.465079e+001;
    IRLLookup[164] = 1.448193e+001;
    IRLLookup[165] = 1.431680e+001;
    IRLLookup[166] = 1.415530e+001;
    IRLLookup[167] = 1.399737e+001;
    IRLLookup[168] = 1.384292e+001;
    IRLLookup[169] = 1.369186e+001;
    IRLLookup[170] = 1.354412e+001;
    IRLLookup[171] = 1.339961e+001;
    IRLLookup[172] = 1.325826e+001;
    IRLLookup[173] = 1.311997e+001;
    IRLLookup[174] = 1.298467e+001;
    IRLLookup[175] = 1.285227e+001;
    IRLLookup[176] = 1.272270e+001;
    IRLLookup[177] = 1.259587e+001;
    IRLLookup[178] = 1.247171e+001;
    IRLLookup[179] = 1.235012e+001;
    IRLLookup[180] = 1.223102e+001;
    IRLLookup[181] = 1.211435e+001;
    IRLLookup[182] = 12;
    IRLLookup[183] = 1.188791e+001;
    IRLLookup[184] = 1.177798e+001;
    IRLLookup[185] = 1.167014e+001;
    IRLLookup[186] = 1.156431e+001;
    IRLLookup[187] = 1.146041e+001;
    IRLLookup[188] = 1.135834e+001;
    IRLLookup[189] = 1.125804e+001;
    IRLLookup[190] = 1.115941e+001;
    IRLLookup[191] = 1.106238e+001;
    IRLLookup[192] = 1.096687e+001;
    IRLLookup[193] = 1.087279e+001;
    IRLLookup[194] = 1.078006e+001;
    IRLLookup[195] = 1.068860e+001;
    IRLLookup[196] = 1.059832e+001;
    IRLLookup[197] = 1.050916e+001;
    IRLLookup[198] = 1.042101e+001;
    IRLLookup[199] = 1.033381e+001;
    IRLLookup[200] = 1.024747e+001;
    IRLLookup[201] = 1.016191e+001;
    IRLLookup[202] = 1.007705e+001;
    IRLLookup[203] = 9.992799e+000;
    IRLLookup[204] = 9.909083e+000;
    IRLLookup[205] = 9.825818e+000;
    IRLLookup[206] = 9.742923e+000;
    IRLLookup[207] = 9.660316e+000;
    IRLLookup[208] = 9.577914e+000;
    IRLLookup[209] = 9.495637e+000;
    IRLLookup[210] = 9.413402e+000;
    IRLLookup[211] = 9.331128e+000;
    IRLLookup[212] = 9.248732e+000;
    IRLLookup[213] = 9.166134e+000;
    IRLLookup[214] = 9.083250e+000;
    IRLLookup[215] = 9;
    IRLLookup[216] = 8.916301e+000;
    IRLLookup[217] = 8.832072e+000;
    IRLLookup[218] = 8.747231e+000;
    IRLLookup[219] = 8.661696e+000;
    IRLLookup[220] = 8.575385e+000;
    IRLLookup[221] = 8.488217e+000;
    IRLLookup[222] = 8.400109e+000;
    IRLLookup[223] = 8.310980e+000;
    IRLLookup[224] = 8.220748e+000;
    IRLLookup[225] = 8.129331e+000;
    IRLLookup[226] = 8.036647e+000;
    IRLLookup[227] = 7.942616e+000;
    IRLLookup[228] = 7.847153e+000;
    IRLLookup[229] = 7.750179e+000;
    IRLLookup[230] = 7.651611e+000;
    IRLLookup[231] = 7.551368e+000;
    IRLLookup[232] = 7.449366e+000;
    IRLLookup[233] = 7.345526e+000;
    IRLLookup[234] = 7.239764e+000;
    IRLLookup[235] = 7.132000e+000;
    IRLLookup[236] = 7.022151e+000;
    IRLLookup[237] = 6.910135e+000;
    IRLLookup[238] = 6.795871e+000;
    IRLLookup[239] = 6.679277e+000;
    IRLLookup[240] = 6.560271e+000;
    IRLLookup[241] = 6.438771e+000;
    IRLLookup[242] = 6.314695e+000;
    IRLLookup[243] = 6.187962e+000;
    IRLLookup[244] = 6.058490e+000;
    IRLLookup[245] = 5.926197e+000;
    IRLLookup[246] = 5.791001e+000;
    IRLLookup[247] = 5.652820e+000;
    IRLLookup[248] = 5.511573e+000;
    IRLLookup[249] = 5.367177e+000;
    IRLLookup[250] = 5.219552e+000;
    IRLLookup[251] = 5.068615e+000;
    IRLLookup[252] = 4.914283e+000;
    IRLLookup[253] = 4.756477e+000;
    IRLLookup[254] = 4.595113e+000;
    IRLLookup[255] = 4.430110e+000;

    IRMLookup[70] = 6.815331e+002;
    IRMLookup[71] = 4.758332e+002;
    IRMLookup[72] = 3.220475e+002;
    IRMLookup[73] = 2.125238e+002;
    IRMLookup[74] = 1.396095e+002;
    IRMLookup[75] = 9.565238e+001;
    IRMLookup[76] = 73;
    IRMLookup[77] = 64;
    IRMLookup[78] = 61;
    IRMLookup[79] = 58;
    IRMLookup[80] = 55;
    IRMLookup[81] = 52;
    IRMLookup[82] = 5.054334e+001;
    IRMLookup[83] = 49;
    IRMLookup[84] = 46;
    IRMLookup[85] = 4.412303e+001;
    IRMLookup[86] = 43;
    IRMLookup[87] = 4.154458e+001;
    IRMLookup[88] = 40;
    IRMLookup[89] = 3.880903e+001;
    IRMLookup[90] = 3.788290e+001;
    IRMLookup[91] = 37;
    IRMLookup[92] = 3.599816e+001;
    IRMLookup[93] = 3.495310e+001;
    IRMLookup[94] = 34;
    IRMLookup[95] = 3.323929e+001;
    IRMLookup[96] = 3.263233e+001;
    IRMLookup[97] = 3.210572e+001;
    IRMLookup[98] = 3.158608e+001;
    IRMLookup[99] = 31;
    IRMLookup[100] = 3.029716e+001;
    IRMLookup[101] = 2.951952e+001;
    IRMLookup[102] = 2.873213e+001;
    IRMLookup[103] = 28;
    IRMLookup[104] = 2.737394e+001;
    IRMLookup[105] = 2.684775e+001;
    IRMLookup[106] = 2.640102e+001;
    IRMLookup[107] = 2.601330e+001;
    IRMLookup[108] = 2.566418e+001;
    IRMLookup[109] = 2.533322e+001;
    IRMLookup[110] = 25;
    IRMLookup[111] = 2.464838e+001;
    IRMLookup[112] = 2.427940e+001;
    IRMLookup[113] = 2.389841e+001;
    IRMLookup[114] = 2.351073e+001;
    IRMLookup[115] = 2.312172e+001;
    IRMLookup[116] = 2.273670e+001;
    IRMLookup[117] = 2.236101e+001;
    IRMLookup[118] = 22;
    IRMLookup[119] = 2.165785e+001;
    IRMLookup[120] = 2.133418e+001;
    IRMLookup[121] = 2.102746e+001;
    IRMLookup[122] = 2.073616e+001;
    IRMLookup[123] = 2.045873e+001;
    IRMLookup[124] = 2.019366e+001;
    IRMLookup[125] = 1.993942e+001;
    IRMLookup[126] = 1.969446e+001;
    IRMLookup[127] = 1.945725e+001;
    IRMLookup[128] = 1.922628e+001;
    IRMLookup[129] = 19;
    IRMLookup[130] = 1.877714e+001;
    IRMLookup[131] = 1.855747e+001;
    IRMLookup[132] = 1.834099e+001;
    IRMLookup[133] = 1.812774e+001;
    IRMLookup[134] = 1.791773e+001;
    IRMLookup[135] = 1.771097e+001;
    IRMLookup[136] = 1.750750e+001;
    IRMLookup[137] = 1.730732e+001;
    IRMLookup[138] = 1.711045e+001;
    IRMLookup[139] = 1.691693e+001;
    IRMLookup[140] = 1.672676e+001;
    IRMLookup[141] = 1.653996e+001;
    IRMLookup[142] = 1.635655e+001;
    IRMLookup[143] = 1.617656e+001;
    IRMLookup[144] = 16;
    IRMLookup[145] = 1.582688e+001;
    IRMLookup[146] = 1.565715e+001;
    IRMLookup[147] = 1.549075e+001;
    IRMLookup[148] = 1.532763e+001;
    IRMLookup[149] = 1.516773e+001;
    IRMLookup[150] = 1.501099e+001;
    IRMLookup[151] = 1.485736e+001;
    IRMLookup[152] = 1.470677e+001;
    IRMLookup[153] = 1.455917e+001;
    IRMLookup[154] = 1.441450e+001;
    IRMLookup[155] = 1.427270e+001;
    IRMLookup[156] = 1.413372e+001;
    IRMLookup[157] = 1.399749e+001;
    IRMLookup[158] = 1.386397e+001;
    IRMLookup[159] = 1.373308e+001;
    IRMLookup[160] = 1.360478e+001;
    IRMLookup[161] = 1.347900e+001;
    IRMLookup[162] = 1.335570e+001;
    IRMLookup[163] = 1.323480e+001;
    IRMLookup[164] = 1.311625e+001;
    IRMLookup[165] = 13;
    IRMLookup[166] = 1.288599e+001;
    IRMLookup[167] = 1.277415e+001;
    IRMLookup[168] = 1.266443e+001;
    IRMLookup[169] = 1.255678e+001;
    IRMLookup[170] = 1.245114e+001;
    IRMLookup[171] = 1.234744e+001;
    IRMLookup[172] = 1.224563e+001;
    IRMLookup[173] = 1.214566e+001;
    IRMLookup[174] = 1.204745e+001;
    IRMLookup[175] = 1.195097e+001;
    IRMLookup[176] = 1.185614e+001;
    IRMLookup[177] = 1.176292e+001;
    IRMLookup[178] = 1.167123e+001;
    IRMLookup[179] = 1.158104e+001;
    IRMLookup[180] = 1.149227e+001;
    IRMLookup[181] = 1.140487e+001;
    IRMLookup[182] = 1.131878e+001;
    IRMLookup[183] = 1.123395e+001;
    IRMLookup[184] = 1.115031e+001;
    IRMLookup[185] = 1.106781e+001;
    IRMLookup[186] = 1.098639e+001;
    IRMLookup[187] = 1.090599e+001;
    IRMLookup[188] = 1.082656e+001;
    IRMLookup[189] = 1.074804e+001;
    IRMLookup[190] = 1.067037e+001;
    IRMLookup[191] = 1.059349e+001;
    IRMLookup[192] = 1.051734e+001;
    IRMLookup[193] = 1.044187e+001;
    IRMLookup[194] = 1.036701e+001;
    IRMLookup[195] = 1.029272e+001;
    IRMLookup[196] = 1.021893e+001;
    IRMLookup[197] = 1.014559e+001;
    IRMLookup[198] = 1.007263e+001;
    IRMLookup[199] = 10;
    IRMLookup[200] = 9.927643e+000;
    IRMLookup[201] = 9.855500e+000;
    IRMLookup[202] = 9.783512e+000;
    IRMLookup[203] = 9.711623e+000;
    IRMLookup[204] = 9.639774e+000;
    IRMLookup[205] = 9.567908e+000;
    IRMLookup[206] = 9.495966e+000;
    IRMLookup[207] = 9.423891e+000;
    IRMLookup[208] = 9.351626e+000;
    IRMLookup[209] = 9.279112e+000;
    IRMLookup[210] = 9.206291e+000;
    IRMLookup[211] = 9.133106e+000;
    IRMLookup[212] = 9.059499e+000;
    IRMLookup[213] = 8.985412e+000;
    IRMLookup[214] = 8.910788e+000;
    IRMLookup[215] = 8.835568e+000;
    IRMLookup[216] = 8.759695e+000;
    IRMLookup[217] = 8.683111e+000;
    IRMLookup[218] = 8.605757e+000;
    IRMLookup[219] = 8.527578e+000;
    IRMLookup[220] = 8.448514e+000;
    IRMLookup[221] = 8.368507e+000;
    IRMLookup[222] = 8.287501e+000;
    IRMLookup[223] = 8.205436e+000;
    IRMLookup[224] = 8.122256e+000;
    IRMLookup[225] = 8.037903e+000;
    IRMLookup[226] = 7.952318e+000;
    IRMLookup[227] = 7.865444e+000;
    IRMLookup[228] = 7.777224e+000;
    IRMLookup[229] = 7.687599e+000;
    IRMLookup[230] = 7.596511e+000;
    IRMLookup[231] = 7.503903e+000;
    IRMLookup[232] = 7.409717e+000;
    IRMLookup[233] = 7.313895e+000;
    IRMLookup[234] = 7.216380e+000;
    IRMLookup[235] = 7.117113e+000;
    IRMLookup[236] = 7.016037e+000;
    IRMLookup[237] = 6.913094e+000;
    IRMLookup[238] = 6.808226e+000;
    IRMLookup[239] = 6.701375e+000;
    IRMLookup[240] = 6.592484e+000;
    IRMLookup[241] = 6.481495e+000;
    IRMLookup[242] = 6.368349e+000;
    IRMLookup[243] = 6.252990e+000;
    IRMLookup[244] = 6.135359e+000;
    IRMLookup[245] = 6.015399e+000;
    IRMLookup[246] = 5.893052e+000;
    IRMLookup[247] = 5.768259e+000;
    IRMLookup[248] = 5.640964e+000;
    IRMLookup[249] = 5.511108e+000;
    IRMLookup[250] = 5.378633e+000;
    IRMLookup[251] = 5.243483e+000;
    IRMLookup[252] = 5.105598e+000;
    IRMLookup[253] = 4.964922e+000;
    IRMLookup[254] = 4.821396e+000;
    IRMLookup[255] = 4.674962e+000;

    /*IRRLookup[70] = -1.107190e+003;
    IRRLookup[71] = -9.762634e+002;
    IRRLookup[72] = -8.547699e+002;
    IRRLookup[73] = -7.423728e+002;
    IRRLookup[74] = -6.387356e+002;
    IRRLookup[75] = -5.435215e+002;
    IRRLookup[76] = -4.563942e+002;
    IRRLookup[77] = -3.770171e+002;
    IRRLookup[78] = -3.050536e+002;
    IRRLookup[79] = -2.401671e+002;
    IRRLookup[80] = -1.820213e+002;
    IRRLookup[81] = -1.302794e+002;
    IRRLookup[82] = -8.460490e+001;
    IRRLookup[83] = -4.466134e+001;
    IRRLookup[84] = -1.011214e+001;
    IRRLookup[85] = 1.937925e+001;
    IRRLookup[86] = 4.414938e+001;
    IRRLookup[87] = 6.453478e+001;
    IRRLookup[88] = 8.087201e+001;
    IRRLookup[89] = 9.349761e+001;
    IRRLookup[90] = 1.027481e+002;
    IRRLookup[91] = 1.089601e+002;
    IRRLookup[92] = 1.124701e+002;*/
    for (i = 70; i <= 92; i++)
      IRRLookup[i] = 10000;
    IRRLookup[93] = 1.136146e+002;
    IRRLookup[94] = 1.127302e+002;
    IRRLookup[95] = 1.101535e+002;
    IRRLookup[96] = 1.062209e+002;
    IRRLookup[97] = 1.012691e+002;
    IRRLookup[98] = 9.563455e+001;
    IRRLookup[99] = 8.965382e+001;
    IRRLookup[100] = 8.366345e+001;
    IRRLookup[101] = 78;
    IRRLookup[102] = 73;
    IRRLookup[103] = 69;
    IRRLookup[104] = 66;
    IRRLookup[105] = 63;
    IRRLookup[106] = 60;
    IRRLookup[107] = 57;
    IRRLookup[108] = 54;
    IRRLookup[109] = 5.253968e+001;
    IRRLookup[110] = 51;
    IRRLookup[111] = 48;
    IRRLookup[112] = 4.600916e+001;
    IRRLookup[113] = 45;
    IRRLookup[114] = 4.415723e+001;
    IRRLookup[115] = 4.320446e+001;
    IRRLookup[116] = 42;
    IRRLookup[117] = 4.049352e+001;
    IRRLookup[118] = 39;
    IRRLookup[119] = 3.782721e+001;
    IRRLookup[120] = 3.688883e+001;
    IRRLookup[121] = 36;
    IRRLookup[122] = 3.502096e+001;
    IRRLookup[123] = 3.399238e+001;
    IRRLookup[124] = 33;
    IRRLookup[125] = 3.211228e+001;
    IRRLookup[126] = 3.132843e+001;
    IRRLookup[127] = 3.063037e+001;
    IRRLookup[128] = 30;
    IRRLookup[129] = 2.942097e+001;
    IRRLookup[130] = 2.888384e+001;
    IRRLookup[131] = 2.838089e+001;
    IRRLookup[132] = 2.790441e+001;
    IRRLookup[133] = 2.744668e+001;
    IRRLookup[134] = 27;
    IRRLookup[135] = 2.655801e+001;
    IRRLookup[136] = 2.611977e+001;
    IRRLookup[137] = 2.568573e+001;
    IRRLookup[138] = 2.525630e+001;
    IRRLookup[139] = 2.483192e+001;
    IRRLookup[140] = 2.441301e+001;
    IRRLookup[141] = 24;
    IRRLookup[142] = 2.359340e+001;
    IRRLookup[143] = 2.319403e+001;
    IRRLookup[144] = 2.280279e+001;
    IRRLookup[145] = 2.242057e+001;
    IRRLookup[146] = 2.204829e+001;
    IRRLookup[147] = 2.168683e+001;
    IRRLookup[148] = 2.133710e+001;
    IRRLookup[149] = 21;
    IRRLookup[150] = 2.067614e+001;
    IRRLookup[151] = 2.036497e+001;
    IRRLookup[152] = 2.006569e+001;
    IRRLookup[153] = 1.977746e+001;
    IRRLookup[154] = 1.949945e+001;
    IRRLookup[155] = 1.923085e+001;
    IRRLookup[156] = 1.897082e+001;
    IRRLookup[157] = 1.871855e+001;
    IRRLookup[158] = 1.847321e+001;
    IRRLookup[159] = 1.823396e+001;
    IRRLookup[160] = 18;
    IRRLookup[161] = 1.777062e+001;
    IRRLookup[162] = 1.754564e+001;
    IRRLookup[163] = 1.732503e+001;
    IRRLookup[164] = 1.710872e+001;
    IRRLookup[165] = 1.689667e+001;
    IRRLookup[166] = 1.668884e+001;
    IRRLookup[167] = 1.648517e+001;
    IRRLookup[168] = 1.628562e+001;
    IRRLookup[169] = 1.609013e+001;
    IRRLookup[170] = 1.589867e+001;
    IRRLookup[171] = 1.571118e+001;
    IRRLookup[172] = 1.552762e+001;
    IRRLookup[173] = 1.534793e+001;
    IRRLookup[174] = 1.517208e+001;
    IRRLookup[175] = 15;
    IRRLookup[176] = 1.483165e+001;
    IRRLookup[177] = 1.466694e+001;
    IRRLookup[178] = 1.450579e+001;
    IRRLookup[179] = 1.434810e+001;
    IRRLookup[180] = 1.419379e+001;
    IRRLookup[181] = 1.404276e+001;
    IRRLookup[182] = 1.389493e+001;
    IRRLookup[183] = 1.375020e+001;
    IRRLookup[184] = 1.360849e+001;
    IRRLookup[185] = 1.346970e+001;
    IRRLookup[186] = 1.333376e+001;
    IRRLookup[187] = 1.320056e+001;
    IRRLookup[188] = 1.307002e+001;
    IRRLookup[189] = 1.294205e+001;
    IRRLookup[190] = 1.281656e+001;
    IRRLookup[191] = 1.269345e+001;
    IRRLookup[192] = 1.257265e+001;
    IRRLookup[193] = 1.245406e+001;
    IRRLookup[194] = 1.233759e+001;
    IRRLookup[195] = 1.222315e+001;
    IRRLookup[196] = 1.211065e+001;
    IRRLookup[197] = 12;
    IRRLookup[198] = 1.189112e+001;
    IRRLookup[199] = 1.178391e+001;
    IRRLookup[200] = 1.167828e+001;
    IRRLookup[201] = 1.157414e+001;
    IRRLookup[202] = 1.147142e+001;
    IRRLookup[203] = 1.137000e+001;
    IRRLookup[204] = 1.126981e+001;
    IRRLookup[205] = 1.117076e+001;
    IRRLookup[206] = 1.107275e+001;
    IRRLookup[207] = 1.097570e+001;
    IRRLookup[208] = 1.087952e+001;
    IRRLookup[209] = 1.078411e+001;
    IRRLookup[210] = 1.068940e+001;
    IRRLookup[211] = 1.059528e+001;
    IRRLookup[212] = 1.050166e+001;
    IRRLookup[213] = 1.040847e+001;
    IRRLookup[214] = 1.031561e+001;
    IRRLookup[215] = 1.022299e+001;
    IRRLookup[216] = 1.013052e+001;
    IRRLookup[217] = 1.003811e+001;
    IRRLookup[218] = 9.945667e+000;
    IRRLookup[219] = 9.853110e+000;
    IRRLookup[220] = 9.760345e+000;
    IRRLookup[221] = 9.667283e+000;
    IRRLookup[222] = 9.573834e+000;
    IRRLookup[223] = 9.479908e+000;
    IRRLookup[224] = 9.385417e+000;
    IRRLookup[225] = 9.290270e+000;
    IRRLookup[226] = 9.194378e+000;
    IRRLookup[227] = 9.097651e+000;
    IRRLookup[228] = 9;
    IRRLookup[229] = 8.901335e+000;
    IRRLookup[230] = 8.801567e+000;
    IRRLookup[231] = 8.700606e+000;
    IRRLookup[232] = 8.598363e+000;
    IRRLookup[233] = 8.494748e+000;
    IRRLookup[234] = 8.389671e+000;
    IRRLookup[235] = 8.283043e+000;
    IRRLookup[236] = 8.174774e+000;
    IRRLookup[237] = 8.064775e+000;
    IRRLookup[238] = 7.952956e+000;
    IRRLookup[239] = 7.839228e+000;
    IRRLookup[240] = 7.723501e+000;
    IRRLookup[241] = 7.605685e+000;
    IRRLookup[242] = 7.485691e+000;
    IRRLookup[243] = 7.363430e+000;
    IRRLookup[244] = 7.238812e+000;
    IRRLookup[245] = 7.111746e+000;
    IRRLookup[246] = 6.982145e+000;
    IRRLookup[247] = 6.849917e+000;
    IRRLookup[248] = 6.714975e+000;
    IRRLookup[249] = 6.577227e+000;
    IRRLookup[250] = 6.436584e+000;
    IRRLookup[251] = 6.292958e+000;
    IRRLookup[252] = 6.146258e+000;
    IRRLookup[253] = 5.996394e+000;
    IRRLookup[254] = 5.843278e+000;
    IRRLookup[255] = 5.686820e+000;


  }
}

