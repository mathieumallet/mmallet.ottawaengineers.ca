package serialcommproj;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.Properties;
import java.io.FileOutputStream;
import java.util.Vector;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * <p>Title: MainGUI</p>
 * <p>Description: Main class uses to display the YARE GUI and bind together the other classes.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Mathieu Mallet
 * @version 1.0
 */

public class MainGUI extends JFrame {
  private SerialReceiver receiver;
  private SerialDecoder decoder;
  private XYdecoder points_decoder;
  private CommandManager commandMan;
  private long LastPacketTime;
  private int LastProcessedDataPoint;
  private String ProgramTitleShort = new String("YARE");
  private String ProgramTitle = new String("Yare Automaton for Revealing Exits (YARE)");
  private boolean bMonitorEnabled = false;
  private Vector DataVector;
  private Graphics gfx;
  private MapUpdateTimerTask myTimerTask;
  private Timer myTimer;

  private int counter = 0;
  private boolean mapDisplayLeftIR = true;
  private boolean mapDisplayMiddleIR = false;
  private boolean mapDisplayRightIR = true;
  private boolean bDrawPath = false;
  public float mapscalingfactor = 1;
  public boolean bApplyingPath = false;
  public float xoffset = 0, yoffset = 0;
  private boolean bDrawTraces = false;
  private boolean bDrawWalls = false;
  private boolean bAddingWall = false;
  private int AddWallX, AddWallY;

  private JPanel jPanelControls = new JPanel();
  private JPanel jPanel2 = new JPanel();
  private JPanel jPanelInfo = new JPanel();
  private JPanel jPanelMap = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel1 = new JPanel();
  private JPanel jPanel5 = new JPanel();
  private JPanel jPanel6 = new JPanel();
  private JPanel jPanel7 = new JPanel();
  private JPanel jPanel8 = new JPanel();
  private JPanel jPanel9 = new JPanel();
  private JPanel jPanel10 = new JPanel();
  private GridLayout gridLayout1 = new GridLayout();
  private JLabel jLabel7 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JLabel jLabel9 = new JLabel();
  private VerticalFlowLayout verticalFlowLayout2 = new VerticalFlowLayout();
  private TitledBorder titledBorder1;
  private JTextPane jTextIRL = new JTextPane();
  private JTextPane jTextIRM = new JTextPane();
  private JTextPane jTextIRR = new JTextPane();
  private VerticalFlowLayout verticalFlowLayout3 = new VerticalFlowLayout();
  private JPanel jPanel3 = new JPanel();
  private JPanel jPanel4 = new JPanel();
  private JPanel jPanel11 = new JPanel();
  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JLabel jLabel1 = new JLabel();
  private JTextPane jTextState = new JTextPane();
  private JLabel jLabel2 = new JLabel();
  private JTextPane jTextTime = new JTextPane();
  private JLabel jLabel3 = new JLabel();
  private JTextPane jTextDelta = new JTextPane();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private BoxLayout2 boxLayout23 = new BoxLayout2();
  private JLabel jLabel10 = new JLabel();
  private JLabel jLabel11 = new JLabel();
  private JLabel jLabel12 = new JLabel();
  private JTextPane jTextLeftM = new JTextPane();
  private JTextPane jTextRightM = new JTextPane();
  private JTextPane jTextBumpers = new JTextPane();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JLabel jLabel13 = new JLabel();
  private JLabel jLabel14 = new JLabel();
  private JLabel jLabel15 = new JLabel();
  private VerticalFlowLayout verticalFlowLayout4 = new VerticalFlowLayout();
  private JButton jButStartRF = new JButton();
  private JButton jButStartMonitor = new JButton();
  private JButton jButClearData = new JButton();
  private JButton jButSaveData = new JButton();
  private JButton jButLoadData = new JButton();
  private JButton jButFindPath = new JButton();
  private JButton jButApplyShortestPath = new JButton();
  private JTextPane jTextIntegrity = new JTextPane();
  private JTextPane jTextPacket = new JTextPane();
  private JTextPane jTextRF = new JTextPane();
  private VerticalFlowLayout verticalFlowLayout5 = new VerticalFlowLayout();
  private Component component4;
  private JButton jButQuit = new JButton();
  private JComboBox jComboCommands = new JComboBox();
  private JButton jButSendCmd = new JButton();
  private Component component5;
  private Component component6;
  private JButton jButAbout = new JButton();
  private JPanel jPanel12 = new JPanel();
  private JTextPane jTextNumPackets = new JTextPane();
  private JLabel jLabel6 = new JLabel();
  private BoxLayout2 boxLayout24 = new BoxLayout2();
  private BoxLayout2 boxLayout22 = new BoxLayout2();
  private BoxLayout2 boxLayout21 = new BoxLayout2();
  private JPanel jPanel13 = new JPanel();
  private JLabel jLabel16 = new JLabel();
  private JTextPane jTextProcessed = new JTextPane();
  private BoxLayout2 boxLayout25 = new BoxLayout2();
  private Component component1;
  private Component component3;
  private JCheckBox jCheckLeft = new JCheckBox();
  private JCheckBox jCheckRight = new JCheckBox();
  private JCheckBox jCheckMiddle = new JCheckBox();
  private Component component7;
  private JPanel jPanel14 = new JPanel();
  private JButton jButZoomOut = new JButton();
  private JButton jButZoomIn = new JButton();
  private GridLayout gridLayout2 = new GridLayout();
  private XYLayout xYLayout1 = new XYLayout();
  private JPanel jPanel15 = new JPanel();
  private JButton jButPreviousState = new JButton();
  private JButton jButPreviousPacket = new JButton();
  private JSlider jSliderPackets = new JSlider();
  private JButton jButNextPacket = new JButton();
  private JButton jButNextState = new JButton();
  private BoxLayout2 boxLayout26 = new BoxLayout2();
  private JCheckBox jCheckDrawWalls = new JCheckBox();
  private JCheckBox jCheckDrawPath = new JCheckBox();
  private JCheckBox jCheckDrawTraces = new JCheckBox();
  private map findpath;
  private JButton jButAuto = new JButton();
  private JPanel jPanel16 = new JPanel();
  private JButton jButQueueCmd = new JButton();
  private GridLayout gridLayout3 = new GridLayout();
  private JPanel jPanel17 = new JPanel();
  private JLabel jLabel17 = new JLabel();
  private BoxLayout2 boxLayout27 = new BoxLayout2();
  private VerticalFlowLayout verticalFlowLayout6 = new VerticalFlowLayout();
  private VerticalFlowLayout verticalFlowLayout7 = new VerticalFlowLayout();
  private JTextPane jTextExitState = new JTextPane();
  private JTextPane jTextCommandQueue = new JTextPane();
  
  /**
   * Constructor for objects of class MainGUI
   *
   */
  public MainGUI() {
    Color myColor;
    myColor = Color.lightGray;

    bMonitorEnabled = true;
    ClearData();
    decoder = new SerialDecoder(this, DataVector);
    points_decoder = new XYdecoder(this, DataVector);
    commandMan = new CommandManager(this, null);

    myTimerTask = new MapUpdateTimerTask(this);
    myTimer = new Timer();
    myTimer.scheduleAtFixedRate(myTimerTask, 10, 500);

    try {
      jbInit();

      jPanel1.setBackground(myColor);
      jPanel2.setBackground(myColor);
      jPanel3.setBackground(myColor);
      jPanel4.setBackground(myColor);
      jPanel5.setBackground(myColor);
      jPanel6.setBackground(myColor);
      jPanel7.setBackground(myColor);
      jPanel8.setBackground(myColor);
      jPanel9.setBackground(myColor);
      jPanel10.setBackground(myColor);
      jPanel11.setBackground(myColor);
      jPanelControls.setBackground(myColor);
      jPanelMap.setBackground(myColor);
      jPanelInfo.setBackground(myColor);
      jPanel12.setBackground(myColor);
      jPanel13.setBackground(myColor);
      jPanel14.setBackground(myColor);
      jPanel15.setBackground(myColor);
      jPanel17.setBackground(myColor);

      jTextBumpers.setBackground(myColor);
      jTextDelta.setBackground(myColor);
      jTextIntegrity.setBackground(myColor);
      jTextIRL.setBackground(myColor);
      jTextIRM.setBackground(myColor);
      jTextIRR.setBackground(myColor);
      jTextLeftM.setBackground(myColor);
      jTextRightM.setBackground(myColor);
      jTextPacket.setBackground(myColor);
      jTextState.setBackground(myColor);
      jTextTime.setBackground(myColor);
      jTextRF.setBackground(myColor);
      jTextNumPackets.setBackground(myColor);
      jTextProcessed.setBackground(myColor);
      jTextExitState.setBackground(myColor);
      jTextCommandQueue.setBackground(myColor);

      jSliderPackets.setBackground(myColor);
      jCheckLeft.setBackground(myColor);
      jCheckMiddle.setBackground(myColor);
      jCheckRight.setBackground(myColor);
      jCheckDrawWalls.setBackground(myColor);
      jCheckDrawPath.setBackground(myColor);
      jCheckDrawTraces.setBackground(myColor);

      FillCommandList();

      Dimension dlgSize = new Dimension(950,750);
      setTitle(ProgramTitle);
      setSize(dlgSize);
      setVisible(true);
      repaint();
      show();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

	/**
	 * Main class. Instanciates a MainGUI object.
	 * @param args Arguments -- not used.
	 */
  public static void main(String[] args) {
    MainGUI gui = new MainGUI();
    //Dimension dlgSize = rfMonitor.getPreferredSize();
  }

	/**
	 * Initializes and instanciates the GUI elements.
	 * @throws Exception
	 */
  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    component4 = Box.createHorizontalStrut(8);
    component5 = Box.createHorizontalStrut(8);
    component6 = Box.createHorizontalStrut(8);
    component1 = Box.createHorizontalStrut(8);
    component3 = Box.createHorizontalStrut(8);
    component7 = Box.createHorizontalStrut(8);
    jPanelControls.setBackground(Color.darkGray);
    jPanelControls.setBorder(BorderFactory.createEtchedBorder());
    jPanelControls.setMinimumSize(new Dimension(100, 100));
    jPanelControls.setPreferredSize(new Dimension(125, 125));
    jPanelControls.setLayout(verticalFlowLayout4);
    jPanel2.setBackground(Color.red);
    jPanel2.setPreferredSize(new Dimension(200, 100));
    jPanel2.setLayout(borderLayout1);
    jPanelInfo.setBackground(Color.orange);
    jPanelInfo.setBorder(BorderFactory.createEtchedBorder());
    jPanelInfo.setMinimumSize(new Dimension(100, 100));
    jPanelInfo.setPreferredSize(new Dimension(172, 172));
    jPanelInfo.setLayout(gridBagLayout1);
    jPanelMap.setBackground(Color.green);
    jPanelMap.setBorder(BorderFactory.createEtchedBorder());
    jPanelMap.setMinimumSize(new Dimension(100, 100));
    jPanelMap.addMouseListener(new MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jPanelMap_mouseReleased(e);
      }
      public void mousePressed(MouseEvent e) {
        jPanelMap_mousePressed(e);
      }
    });
    jPanelMap.setLayout(xYLayout1);
    jPanel1.setBackground(Color.magenta);
    jPanel1.setMinimumSize(new Dimension(90, 90));
    jPanel1.setPreferredSize(new Dimension(90, 90));
    jPanel1.setLayout(gridLayout1);
    jPanel6.setBackground(Color.blue);
    jPanel6.setMaximumSize(new Dimension(10, 10));
    jPanel6.setMinimumSize(new Dimension(10, 10));
    jPanel6.setPreferredSize(new Dimension(10, 10));
    jPanel6.setLayout(verticalFlowLayout2);
    jPanel7.setBackground(Color.orange);
    jPanel7.setLayout(verticalFlowLayout7);
    jPanel9.setBackground(Color.green);
    jPanel9.setLayout(verticalFlowLayout6);
    jPanel8.setBackground(Color.pink);
    jPanel8.setLayout(verticalFlowLayout1);
    jPanel5.setBackground(Color.cyan);
    jPanel5.setLayout(verticalFlowLayout5);
    jLabel7.setPreferredSize(new Dimension(76, 23));
    jLabel7.setText("IRL:");
    jLabel8.setPreferredSize(new Dimension(76, 23));
    jLabel8.setText("IRM:");
    jLabel9.setPreferredSize(new Dimension(76, 23));
    jLabel9.setText("IRR:");
    jTextIRL.setBackground(SystemColor.window);
    jTextIRL.setEditable(false);
    jTextIRL.setText("---");
    jTextIRM.setBackground(SystemColor.window);
    jTextIRM.setEditable(false);
    jTextIRM.setText("---");
    jTextIRR.setBackground(SystemColor.window);
    jTextIRR.setEditable(false);
    jTextIRR.setText("---");
    jPanel10.setLayout(verticalFlowLayout3);
    jPanel3.setBackground(Color.red);
    jPanel3.setLayout(boxLayout21);
    jPanel4.setBackground(Color.pink);
    jPanel4.setMaximumSize(new Dimension(100, 100));
    jPanel4.setLayout(boxLayout22);
    jPanel11.setBackground(Color.yellow);
    jPanel11.setMaximumSize(new Dimension(100, 100));
    jPanel11.setLayout(boxLayout23);
    jLabel1.setToolTipText("");
    jLabel1.setText("  State: ");
    jTextState.setBackground(SystemColor.window);
    jTextState.setMaximumSize(new Dimension(300, 23));
    jTextState.setMinimumSize(new Dimension(160, 23));
    jTextState.setPreferredSize(new Dimension(15, 23));
    jTextState.setToolTipText("");
    jTextState.setEditable(false);
    jTextState.setText("---");
    jLabel2.setToolTipText("");
    jLabel2.setText("  Absolute Time: ");
    jTextTime.setBackground(SystemColor.window);
    jTextTime.setEditable(false);
    jTextTime.setText("---");
    jLabel3.setText(" ");
    jTextDelta.setBackground(SystemColor.window);
    jTextDelta.setEditable(false);
    jTextDelta.setText("---");
    jLabel4.setText(" ");
    jLabel5.setText("  Time Delta: ");
    jLabel5.setToolTipText("");
    jLabel10.setText("Right Motor:");
    jLabel10.setPreferredSize(new Dimension(76, 23));
    jLabel11.setText("Left Motor:");
    jLabel11.setPreferredSize(new Dimension(76, 23));
    jLabel12.setText("Bumpers:");
    jLabel12.setPreferredSize(new Dimension(76, 23));
    jTextLeftM.setBackground(SystemColor.window);
    jTextLeftM.setEditable(false);
    jTextLeftM.setText("---");
    jTextRightM.setText("---");
    jTextRightM.setBackground(SystemColor.window);
    jTextRightM.setToolTipText("");
    jTextRightM.setEditable(false);
    jTextBumpers.setBackground(SystemColor.window);
    jTextBumpers.setEditable(false);
    jTextBumpers.setText("---");
    jLabel13.setPreferredSize(new Dimension(76, 23));
    jLabel13.setText("RF Status:");
    jLabel14.setPreferredSize(new Dimension(76, 23));
    jLabel14.setText("Last Packet:");
    jLabel15.setPreferredSize(new Dimension(76, 23));
    jLabel15.setText("Integrity:");
    jButStartRF.setText("Start RF");
    jButStartRF.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButStartRF_mouseReleased(e);
      }
    });
    jButStartMonitor.setActionCommand("Stop Monitor");
    jButStartMonitor.setText("Stop Monitor");
    jButStartMonitor.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButStartMonitor_mouseReleased(e);
      }
    });
    jButClearData.setText("Clear Data");
    jButClearData.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButClearData_mouseReleased(e);
      }
    });
    jButSaveData.setText("Save Data");
    jButSaveData.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButSaveData_mouseReleased(e);
      }
    });
    jButLoadData.setMnemonic('0');
    jButLoadData.setText("Load Data");
    jButLoadData.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButLoadData_mouseReleased(e);
      }
    });
    jButFindPath.setText("Find Path");
    jButFindPath.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButFindPath_mouseReleased(e);
      }
    });
    jButApplyShortestPath.setText("Apply Path");
    jButApplyShortestPath.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButApplyShortestPath_mouseReleased(e);
      }
    });
    jTextIntegrity.setBackground(SystemColor.window);
    jTextIntegrity.setEditable(false);
    jTextIntegrity.setText("---");
    jTextPacket.setBackground(SystemColor.window);
    jTextPacket.setEditable(false);
    jTextPacket.setText("OK");
    jTextRF.setEditable(false);
    jTextRF.setBackground(SystemColor.window);
    jTextRF.setForeground(Color.red);
    jTextRF.setToolTipText("");
    jTextRF.setText("Offline");
    jButQuit.setText("Quit");
    jButQuit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButQuit_actionPerformed(e);
      }
    });
    jButSendCmd.setMargin(new Insets(2, 2, 2, 2));
    jButSendCmd.setText("Send");
    jButSendCmd.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButSendCmd_mouseReleased(e);
      }
    });
	jButAbout.setText("About...");
    jButAbout.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButAbout_mouseReleased(e);
      }
    });
    jTextNumPackets.setText("---");
    jTextNumPackets.setEditable(false);
    jTextNumPackets.setToolTipText("");
    jTextNumPackets.setPreferredSize(new Dimension(15, 23));
    jTextNumPackets.setMinimumSize(new Dimension(150, 23));
    jTextNumPackets.setMaximumSize(new Dimension(300, 23));
    jTextNumPackets.setBackground(SystemColor.window);
    jLabel6.setText("  Packets: ");
    jLabel6.setToolTipText("");
    jPanel12.setLayout(boxLayout24);
    jPanel12.setMaximumSize(new Dimension(300, 23));
    jPanel12.setMinimumSize(new Dimension(300, 23));
    jLabel16.setText("  Processed: ");
    jTextProcessed.setEditable(false);
    jTextProcessed.setText("---");
    jPanel13.setLayout(boxLayout25);
    jSliderPackets.setMaximum(0);
    jSliderPackets.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
      public void mouseDragged(MouseEvent e) {
        jSliderPackets_mouseDragged(e);
      }
    });
    jSliderPackets.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jSliderPackets_mouseReleased(e);
      }
    });
    jCheckLeft.setMargin(new Insets(0, 2, 0, 2));
    jCheckLeft.setSelected(true);
    jCheckLeft.setText("Left IR");
    jCheckLeft.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jCheckLeft_mouseReleased(e);
      }
    });
    jCheckRight.setMargin(new Insets(0, 2, 0, 2));
    jCheckRight.setSelected(true);
    jCheckRight.setText("Right IR");
    jCheckRight.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jCheckRight_mouseReleased(e);
      }
    });
    jCheckMiddle.setMargin(new Insets(0, 2, 0, 2));
    jCheckMiddle.setText("Middle IR");
    jCheckMiddle.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jCheckMiddle_mouseReleased(e);
      }
    });
    jButZoomOut.setMargin(new Insets(2, 0, 2, 0));
    jButZoomOut.setText("Zoom -");
    jButZoomOut.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButZoomOut_mouseReleased(e);
      }
      });    jButZoomIn.setMargin(new Insets(2, 0, 2, 0));
    jButZoomIn.setText("Zoom +");
    jButZoomIn.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButZoomIn_mouseReleased(e);
      }
    });
    jPanel14.setLayout(gridLayout2);
    jButPreviousState.setMargin(new Insets(1, 1, 1, 1));
    jButPreviousState.setText("<<");
    jButPreviousState.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButPreviousState_mouseReleased(e);
      }
    });
    jButPreviousPacket.setMargin(new Insets(1, 1, 1, 1));
    jButPreviousPacket.setText("<");
    jButPreviousPacket.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButPreviousPacket_mouseReleased(e);
      }
    });
    jButNextPacket.setMargin(new Insets(1, 1, 1, 1));
    jButNextPacket.setText(">");
    jButNextPacket.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButNextPacket_mouseReleased(e);
      }
    });
    jButNextState.setMargin(new Insets(1, 1, 1, 1));
    jButNextState.setText(">>");
    jButNextState.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButNextState_mouseReleased(e);
      }
    });
    jPanel15.setLayout(boxLayout26);
    jCheckDrawWalls.setToolTipText("");
    jCheckDrawWalls.setMargin(new Insets(0, 2, 0, 2));
    jCheckDrawWalls.setText("Walls");
    jCheckDrawWalls.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jCheckDrawWalls_mouseReleased(e);
      }
      });    jCheckDrawPath.setToolTipText("");
    jCheckDrawPath.setMargin(new Insets(0, 2, 0, 2));
    jCheckDrawPath.setText("Shortest Path");
    jCheckDrawPath.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jCheckDrawPath_mouseReleased(e);
      }
    });
    jCheckDrawTraces.setToolTipText("");
    jCheckDrawTraces.setMargin(new Insets(0, 2, 0, 2));
    jCheckDrawTraces.setText("Traces");
    jCheckDrawTraces.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jCheckDrawTraces_mouseReleased(e);
      }
    });
    jButAuto.setText("Autonomous");
    jButAuto.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButAuto_mouseReleased(e);
      }
    });
    jButQueueCmd.setMargin(new Insets(2, 2, 2, 2));
    jButQueueCmd.setText("Queue");
    jButQueueCmd.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        jButQueueCmd_mouseReleased(e);
      }
    });
    jPanel16.setLayout(gridLayout3);
    jLabel17.setToolTipText("");
    jLabel17.setText("  Exit Status:  ");
    jPanel17.setLayout(boxLayout27);
    jTextExitState.setEditable(false);
    jTextExitState.setText("---");
    jTextCommandQueue.setBorder(BorderFactory.createEtchedBorder());
    jTextCommandQueue.setMinimumSize(new Dimension(90, 90));
    jTextCommandQueue.setPreferredSize(new Dimension(90, 90));
    jTextCommandQueue.setToolTipText("");
    jTextCommandQueue.setEditable(false);
    jTextCommandQueue.setText("No commands in queue.");
    this.getContentPane().add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jPanelInfo, BorderLayout.NORTH);
    jPanelInfo.add(jPanel1,                    new GridBagConstraints(0, 0, 4, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 0, 5), 0, 0));
    jPanel1.add(jPanel6, null);
    jPanel6.add(jLabel7, null);
    jPanel6.add(jLabel8, null);
    jPanel6.add(jLabel9, null);
    jPanel1.add(jPanel10, null);
    jPanel10.add(jTextIRL, null);
    jPanel10.add(jTextIRM, null);
    jPanel10.add(jTextIRR, null);
    jPanel1.add(jPanel9, null);
    jPanel9.add(jLabel11, null);
    jPanel9.add(jLabel10, null);
    jPanel9.add(jLabel12, null);
    jPanel1.add(jPanel8, null);
    jPanel8.add(jTextLeftM, null);
    jPanel8.add(jTextRightM, null);
    jPanel8.add(jTextBumpers, null);
    jPanel1.add(jPanel7, null);
    jPanel1.add(jPanel5, null);
    jPanel5.add(jTextRF, null);
    jPanel5.add(jTextPacket, null);
    jPanel5.add(jTextIntegrity, null);
    jPanel4.add(jLabel2, null);
    jPanel4.add(jTextTime, null);
    jPanel4.add(jLabel3, null);
    jPanelInfo.add(jPanel17,          new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    jPanel17.add(jLabel17, null);
    jPanelInfo.add(jPanel15,        new GridBagConstraints(0, 5, 6, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    jPanel13.add(jLabel16, null);
    jPanel13.add(jTextProcessed, null);
    jPanelInfo.add(jPanel11,            new GridBagConstraints(3, 2, 1, 3, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    jPanelInfo.add(jPanel3,           new GridBagConstraints(0, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    jPanelInfo.add(jPanel12,                      new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 201, 0));
    jPanel11.add(jLabel5, null);
    jPanel11.add(jTextDelta, null);
    jPanel11.add(jLabel4, null);
    jPanelInfo.add(jPanel13,                    new GridBagConstraints(2, 2, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(-1, 0, 0, 0), 148, 0));
    jPanel3.add(jLabel1, null);
    jPanel3.add(jTextState, null);
    jPanelInfo.add(jPanel4,                  new GridBagConstraints(3, 1, 2, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), -23, 0));
    jPanel12.add(jLabel6, null);
    jPanel12.add(jTextNumPackets, null);
    jPanel2.add(jPanelMap, BorderLayout.CENTER);
    jPanel15.add(jButPreviousState, null);
    jPanel15.add(jButPreviousPacket, null);
    jPanel15.add(jSliderPackets, null);
    jPanel15.add(jButNextPacket, null);
    jPanel15.add(jButNextState, null);
    this.getContentPane().add(jPanelControls, BorderLayout.EAST);
    jPanelControls.add(jButStartRF, null);
    jPanelControls.add(jButStartMonitor, null);
    jPanelControls.add(jButAuto, null);
    jPanelControls.add(component7, null);
    jPanelControls.add(jCheckLeft, null);
    jPanelControls.add(jCheckMiddle, null);
    jPanelControls.add(jCheckRight, null);
    jPanelControls.add(jCheckDrawWalls, null);
    jPanelControls.add(jCheckDrawPath, null);
    jPanelControls.add(jCheckDrawTraces, null);
    jPanelControls.add(jPanel14, null);
    jPanelControls.add(component1, null);
    jPanelControls.add(jButClearData, null);
    jPanelControls.add(jButLoadData, null);
    jPanelControls.add(jButSaveData, null);
    jPanelControls.add(component3, null);
    jPanelControls.add(jButFindPath, null);
    jPanelControls.add(jButApplyShortestPath, null);
    jPanelControls.add(component4, null);
    jPanelControls.add(jComboCommands, null);
    jPanelControls.add(jPanel16, null);
    jPanel16.add(jButSendCmd, null);
    jPanel16.add(jButQueueCmd, null);
    jPanelControls.add(jTextCommandQueue, null);
    jPanelControls.add(component5, null);
	jPanelControls.add(jButAbout, null);
	jPanelControls.add(component6, null);
    jPanelControls.add(jButQuit, null);
    jPanel14.add(jButZoomIn, null);
    jPanel14.add(jButZoomOut, null);
    jPanel7.add(jLabel13, null);
    jPanel7.add(jLabel14, null);
    jPanel7.add(jLabel15, null);
    jPanel17.add(jTextExitState, null);
  }

  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
  
	/**
	 * Displays data about a packet on the GUI.
	 * @param p SerialPacket to be displayed
	 */
  public void DisplayData(SerialPacket p) {
    String tmp;
    double dist;
    if (bMonitorEnabled) {
      dist = Math.round(p.GetDistance(1));
      jTextIRL.setText(dist > 5000 ? "Out of bounds" : String.valueOf(dist) + " cm " + String.valueOf(p.IRL));
      dist = Math.round(p.GetDistance(2));
      jTextIRM.setText(dist > 5000 ? "Out of bounds" : String.valueOf(dist) + " cm " + String.valueOf(p.IRM));
      dist = Math.round(p.GetDistance(3));
      jTextIRR.setText(dist > 5000 ? "Out of bounds" : String.valueOf(dist) + " cm " + String.valueOf(p.IRR));

      tmp = p.lmotor_dir == 0 ? "Forward " : "Backwards ";
      tmp = p.lmotor_speed == 0 ? "Stopped" : tmp + String.valueOf(p.lmotor_speed);
      jTextLeftM.setText(tmp);

      tmp = p.rmotor_dir == 0 ? "Forward " : "Backwards ";
      tmp = p.rmotor_speed == 0 ? "Stopped" : tmp + String.valueOf(p.rmotor_speed);
      jTextRightM.setText(tmp);

      jTextTime.setText(String.valueOf(p.time / 25000000) + " s");
      if (LastPacketTime == -1)
        jTextDelta.setText("---");
      else
        jTextDelta.setText(String.valueOf((p.time - LastPacketTime) / 25000) + " ms");

      if (p.bumperl == true && p.bumperr == true) {
        jTextBumpers.setText("Both");
        jTextBumpers.setForeground(Color.red);
      }
      else if (p.bumperl == true) {
        jTextBumpers.setText("Left");
        jTextBumpers.setForeground(Color.red);
      }
      else if (p.bumperr == true) {
        jTextBumpers.setText("Right");
        jTextBumpers.setForeground(Color.red);
      }
      else {
        jTextBumpers.setText("None");
        jTextBumpers.setForeground(Color.black);
      }

      //jTextState.setText(getStateName(p.system_state) + " (" + SerialReceiver.getBinary(SerialReceiver.GetByteFromInt(p.system_state)) + ")");
      jTextState.setText(getStateName(p.system_state));
      jTextExitState.setText(getExitStateName(p.system_state));

      UpdateNumPackets();

    }

    if (p.time - LastPacketTime < 0 && LastPacketTime != -1) {
      HandleNegativeDeltaTime();
    }

    LastPacketTime = p.time;
  }

	/**
	 * Handler for Start RF button clicks. Starts or stops the RF receiver.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButStartRF_mouseReleased(MouseEvent e) {
    if (receiver == null) {
      StartRF();
    }
    else {
      StopRF();
    }
  }

	/**
	 * Handler for Quit button clicks. Queries the user to quit the program.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButQuit_actionPerformed(ActionEvent e) {
    if (JOptionPane.showConfirmDialog(this, "Do you really want to quit?", ProgramTitleShort, 0, 2) == JOptionPane.YES_OPTION)
      System.exit(0);
  }

	/**
	 * Handler for Start Monitor button clicks. Starts or stops the packet monitor.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButStartMonitor_mouseReleased(MouseEvent e) {
    bMonitorEnabled = !bMonitorEnabled;
    if (bMonitorEnabled)
      jButStartMonitor.setText("Stop Monitor");
    else {
      jButStartMonitor.setText("Start Monitor");
      jTextBumpers.setText("---");
      jTextIRL.setText("---");
      jTextIRM.setText("---");
      jTextIRR.setText("---");
      jTextLeftM.setText("---");
      jTextRightM.setText("---");
      jTextState.setText("---");
      jTextTime.setText("---");
      jTextDelta.setText("---");
    }
  }

	/**
	 * Displays packet integrity on the GUI. Different colors are used for different percentages.
	 * @param integrity Integrity to be used when displaying integrity on the GUI.
	 */
  public void updateIntegrity(float integrity) {
    int myIntegrity;

    if (receiver == null)
      return;

    myIntegrity = (int)(integrity * 100);
    jTextIntegrity.setText(String.valueOf(myIntegrity) + " %");
    if (myIntegrity > 85)
      jTextIntegrity.setForeground(Color.green);
    else if (myIntegrity < 50)
      jTextIntegrity.setForeground(Color.red);
    else
      jTextIntegrity.setForeground(Color.black);
  }

	/**
	 * Update status of last packet on GUI, be it OK or Corrupted.
	 * @param OK Weather the status of the last packet is OK (true) or Corrupted (false).
	 */
  public void updateLastPacket(boolean OK) {
    if (OK) {
      jTextPacket.setText("OK");
      jTextPacket.setForeground(Color.green);
    }
    else {
      jTextPacket.setText("Corrupt");
      jTextPacket.setForeground(Color.red);
    }

  }

	/**
	 * Prompt user to clear the data when negative time is detected. Useful when robot has been reprogrammed.
	 *
	 */
  public void HandleNegativeDeltaTime() {
    if (JOptionPane.showConfirmDialog(this, "Negative Time Delta detected!\n\nThis is probably due to a reprogramming of the robot.\nDo you want to clear the recorded data?\nTrying to decode data containing negative time delta may have unforeseen consequences!", ProgramTitleShort, 0, 2) == JOptionPane.YES_OPTION)
      ClearData();
  }

	/**
	 * Handler for Clear Data button clicks. Clears all data in the program.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButClearData_mouseReleased(MouseEvent e) {
    if (JOptionPane.showConfirmDialog(this, "Are you sure you want to clear the collected data?", ProgramTitleShort, 0, 2) == JOptionPane.YES_OPTION)
      ClearData();
  }

	/**
	 * Clears all program data, including received packets, queued commands and calculated paths.
	 *
	 */
  public void ClearData() {
    DataVector = new Vector();
    if (points_decoder != null)
      points_decoder.ClearData();
    if (decoder != null)
      decoder.ClearData(DataVector);
    if (findpath != null && !bApplyingPath)
      findpath.ClearMazeAndPaths(points_decoder.getXYVector());
    if (commandMan != null && receiver != null)
      commandMan.ClearData(receiver, decoder);
    UpdateNumPackets();
    updateNumProcessedElements();
    LastPacketTime = 0;
    LastProcessedDataPoint = 0;
    xoffset = 0;
    yoffset = 0;
    bApplyingPath = false;
    jCheckDrawPath.setSelected(false); bDrawPath = false;
    jCheckDrawWalls.setSelected(false); bDrawWalls = false;
    jCheckDrawTraces.setSelected(false); bDrawTraces = false;
    jCheckRight.setSelected(true); mapDisplayRightIR = true;
    jCheckLeft.setSelected(true); mapDisplayLeftIR = true;
    jCheckMiddle.setSelected(false); mapDisplayMiddleIR = false;
    ResetApplyingPathButton();
    jTextCommandQueue.setText("No commands in queue.");
  }

	/**
	 * Handler for Save Data button clicks. Queries the user for a filename and saves the RF data to that file.
	 * @param e Mouse event that triggered this function call.
	 */
	private void jButSaveData_mouseReleased(MouseEvent e) {
    FileDialog fd = new FileDialog(this, "Save Received RF Data", FileDialog.SAVE);
    fd.setFile("MyData.robotdata.txt");
    fd.setVisible(true);
    String fileName = fd.getFile();
    String directory = fd.getDirectory();
    if ((fileName != null) && (directory != null)) {
      writeFile(directory + fileName);
    }
  }

	/**
	 * Writes current data RF data to a file.
	 * @param file Filename for data to be written to.
	 */
  private void writeFile(String file) {
    int i;
    Properties newProps;
    FileOutputStream fileOut = null;

    newProps = new Properties();

    for (i = 0; i < DataVector.size(); i++) {
      newProps.put("P" + String.valueOf(i) + "IRL", ((SerialPacket)DataVector.elementAt(i)).getIRLString());
      newProps.put("P" + String.valueOf(i) + "IRM", ((SerialPacket)DataVector.elementAt(i)).getIRMString());
      newProps.put("P" + String.valueOf(i) + "IRR", ((SerialPacket)DataVector.elementAt(i)).getIRRString());

      newProps.put("P" + String.valueOf(i) + "BumperL", ((SerialPacket)DataVector.elementAt(i)).getBumperLString());
      newProps.put("P" + String.valueOf(i) + "BumperR", ((SerialPacket)DataVector.elementAt(i)).getBumperRString());

      newProps.put("P" + String.valueOf(i) + "LMotorDir", ((SerialPacket)DataVector.elementAt(i)).getLMotorDirString());
      newProps.put("P" + String.valueOf(i) + "LMotorSpeed", ((SerialPacket)DataVector.elementAt(i)).getLMotorSpeedString());
      newProps.put("P" + String.valueOf(i) + "RMotorDir", ((SerialPacket)DataVector.elementAt(i)).getRMotorDirString());
      newProps.put("P" + String.valueOf(i) + "RMotorSpeed", ((SerialPacket)DataVector.elementAt(i)).getRMotorSpeedString());

      newProps.put("P" + String.valueOf(i) + "Time", ((SerialPacket)DataVector.elementAt(i)).getTimeString());
      newProps.put("P" + String.valueOf(i) + "SystemState", ((SerialPacket)DataVector.elementAt(i)).getSystemStateString());
      newProps.put("P" + String.valueOf(i) + "Padding", ((SerialPacket)DataVector.elementAt(i)).getPaddingString());

    }

    try {
      fileOut = new FileOutputStream(file);
    } catch (IOException e) {
      System.out.println("Could not open file for writiing: " + file);
    }

    newProps.save(fileOut, "RF Data");

    try {
      fileOut.close();
    } catch (IOException e) {
      System.out.println("Could not close file for writiing: " + file);
    }
  }

	/**
	 * Handler for Load Data button clicks. Queries the user for a filename and loads the RF data in that file.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButLoadData_mouseReleased(MouseEvent e) {
    Properties loadedProps;

    FileDialog fd = new FileDialog(this,
                                   "Load RF Data",
                                   FileDialog.LOAD);
    fd.setVisible(true);
    String file = fd.getFile();
    if (file != null) {
      String dir = fd.getDirectory();
      File f = new File(dir + file);
      try {
        FileInputStream fis = new FileInputStream(f);
        loadedProps = new Properties();
        loadedProps.load(fis);
        fis.close();
        loadData(loadedProps);
      } catch (FileNotFoundException e1) {
        System.err.println(e1);
      } catch (IOException e2) {
        System.err.println(e2);
      }
    }
  }

	/**
	 * Starts the RF interface.
	 *
	 */
  void StartRF() {
    if (receiver != null)
      return;

    jTextIntegrity.setText("---");
    jTextIntegrity.setForeground(Color.black);

    receiver = new SerialReceiver(SerialReceiver.GetPort(), decoder);

    if (receiver != null) {
      jButStartRF.setText("Stop RF");
      jTextRF.setText("Online");
      jTextRF.setForeground(Color.green);
    }
  }

	/**
	 * Stops the RF interface.
	 *
	 */
  void StopRF() {
    if (receiver != null) {
      receiver.KillReceiver();
      receiver = null;
    }
    jButStartRF.setText("Start RF");
    jTextRF.setText("Offline");
    jTextRF.setForeground(Color.red);
    jTextIntegrity.setText("---");
    jTextIntegrity.setForeground(Color.black);
    if (bApplyingPath)
      commandMan.AbortExecution();
  }

	/**
	 * Loads saved RF data from a file.
	 * @param props Filename for data to be loaded from.
	 */
  void loadData(Properties props) {
    int i;
    SerialPacket packet = new SerialPacket(this);
    StopRF();
    ClearData();

    i = 0;
    while(props.getProperty("P" + String.valueOf(i) + "IRL", "NODATA") != "NODATA") {
      packet = new SerialPacket(props.getProperty("P" + String.valueOf(i) + "IRL"),
                                props.getProperty("P" + String.valueOf(i) + "IRM"),
                                props.getProperty("P" + String.valueOf(i) + "IRR"),

                                props.getProperty("P" + String.valueOf(i) + "BumperL"),
                                props.getProperty("P" + String.valueOf(i) + "BumperR"),

                                props.getProperty("P" + String.valueOf(i) + "LMotorDir"),
                                props.getProperty("P" + String.valueOf(i) + "LMotorSpeed"),
                                props.getProperty("P" + String.valueOf(i) + "RMotorDir"),
                                props.getProperty("P" + String.valueOf(i) + "RMotorSpeed"),

                                props.getProperty("P" + String.valueOf(i) + "Time"),
                                props.getProperty("P" + String.valueOf(i) + "SystemState"),
                                props.getProperty("P" + String.valueOf(i) + "Padding"),
                                this);

      DataVector.add(packet);
      //DisplayData(packet);
      i++;
    }
    DisplayData(packet);
    if (i != 0) {
      PacketAvailable();
    }
  }

	/**
	 * Function used to check if a specific state is a waiting state.
	 * @param state Integer representaiton of the queried state.
	 * @return True if the state is a waiting state, False otherwise.
	 */
  public static boolean IsWaitingState(int state) {
    return ((state & 0x20) == 0x20);
  }

	/**
	 * Function to obtain the long name of a state.
	 * @param state Integer representation of the queried state.
	 * @return The name of the specified state.
	 */
  public String getStateName(int state) {
    if (IsWaitingState(state))
      return "Waiting for command";

    switch (state) {
      case 0: return "Initialisation";
      case 1: return "Idle";
      case 2: return "Following right wall";
      case 3: return "Clearing corner";
      case 4: return "Turning 90 degrees clockwise";
      case 5: return "Looking for wall at right";
      case 6: return "Turning 90 degrees counterclockwise";
      case 7: return "Following left wall";
      case 8: return "Looking for wall at left";
      case 9: return "Looking for wall in front";
      case 10: return "Going to autonomous mode";

      case 13: return "Executing command";
      case 14: return "Waiting for command (ERROR -- check this)";
      case 15: return "Unexpected error";
      case -1: return "*Invalid packet*";
      default: return "Unknown state";
    }
  }

	/**
	 * Function to obtain the exit state name from a state.
	 * @param state Integer representation of the state containing the exit state.
	 * @return The name of the exit state.
	 */
  public String getExitStateName(int state) {
    if (IsWaitingState(state)) {
      int exitState;
      exitState = state & 0x0F;
      switch (exitState) {
        case 0: return "None";
        case 1: return "Reset";
        case 2: return "Wall over";
        case 3: return "Hit wall";
        case 4: return "Wall at front";
        case 5: return "Wall cleared";
        case 6: return "Turned 90 degrees CW";
        case 7: return "Wall found";
        case 8: return "Wall not found";
        case 9: return "Turned 90 degrees CCW";
        default: return "Unknown exit state";
      }
    }
    else {
      return "Not applicable";
    }
  }

	/**
	 * Function to be called when a serial packet has ben received. Used to signal to the decoder that a packet is ready to be processed.
	 *
	 */
  public void PacketAvailable() {
    if (DataVector.size() != 0) {
      DisplayData((SerialPacket)DataVector.lastElement());
      points_decoder.PacketAvailable();
    }
  }

	/**
	 * Updates the number of packets displayed on the screen as well as the lenght of the slider.
	 *
	 */
  private void UpdateNumPackets() {
    int numpackets;
    numpackets = DataVector.size();
    jTextNumPackets.setText(String.valueOf(numpackets));
    if (numpackets == 0) {
      jSliderPackets.setMaximum(0);
      jSliderPackets.setValue(0);
    }
    else {
      if (numpackets - 1 != jSliderPackets.getMaximum()) {
        jSliderPackets.setMaximum(numpackets - 1);
        if (jSliderPackets.getValue() != jSliderPackets.getMaximum())
          jSliderPackets.setValue(numpackets - 1);
      }
    }
  }

	/**
	 * Updates the number of processed elements on the GUI.
	 *
	 */
  public void updateNumProcessedElements () {
    int temp;
    if (points_decoder == null)
      return;
    temp = points_decoder.getNumPackets();
    jTextProcessed.setText(String.valueOf(temp));
    LastProcessedDataPoint = temp;
  }

	/**
	 * Handler for Slider control clicks. Updates the currently displayed serial packet.
	 * @param e Mouse event that triggered this function call.
	 */
  void jSliderPackets_mouseReleased(MouseEvent e) {
    UpdateCurrentlyDisplayedPacket();
  }

	/**
	 * Handler for Slider control drags. Updates the currently displayed serial packet.
	 * @param e Mouse event that triggered this function call.
	 */
  void jSliderPackets_mouseDragged(MouseEvent e) {
    UpdateCurrentlyDisplayedPacket();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Updates the GUI to show last processed packet.
	 *
	 */
  void UpdateCurrentlyDisplayedPacket() {
    if (DataVector.size() == 0)
      return;
    if (jSliderPackets.getValue() <= 1)
      LastPacketTime = -1;
    else
      LastPacketTime = ((SerialPacket)DataVector.elementAt(jSliderPackets.getValue() - 1)).time;
    DisplayData((SerialPacket)DataVector.elementAt(jSliderPackets.getValue()));
  }

	/**
	 * Wrapper class to display the map on the GUI. Calls functions from both XYDecoder and map.
	 * @param markerindex The number of the current packet -- used to display a circle at the robot's position. Place -1 to have no marker drawn.
	 */
  void DrawMap(int markerindex) {
    int width = jPanelMap.getWidth();
    int height = jPanelMap.getHeight();
    gfx = jPanelMap.getGraphics();
    if (gfx != null) {
      gfx.setColor(Color.black);
      gfx.fillRect(0,0,width,height);
      points_decoder.DrawMap(gfx, width, height, mapDisplayLeftIR, mapDisplayMiddleIR, mapDisplayRightIR, markerindex, xoffset, yoffset);

      if ((bDrawPath || bDrawTraces || bDrawWalls) && findpath != null)
        findpath.generateMaze(gfx,width/6, height/2, mapscalingfactor, xoffset, yoffset, this, bDrawPath, bDrawTraces, bDrawWalls);

    }
  }

	/**
	 * Handler for Paint events. 
	 */
  public void paint(Graphics gfx) {
    super.paint(gfx);
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Accessor for last element of the received serial packets vector.
	 * @return The last element of the received serial packets vector.
	 */
  public synchronized Object GetLastDataVectorElement() {
    return GetDataVectorElement(DataVector.size() - 1);
  }

	/**
	 * Accessor for a specific element of the received serial packets vector.
	 * @param i Index of the element to be returned.
	 * @return The element #i of the received serial packets vector.
	 */
  public synchronized Object GetDataVectorElement(int i) {
    if (DataVector.size() == 0 || i > DataVector.size() - 1)
      return null;
    else
      return DataVector.elementAt(i);
  }

	/**
	 * Class to generate timer events every x seconds. 
	 * @author Mathieu Mallet
	 *
	 */
  public class MapUpdateTimerTask extends TimerTask {
    private MainGUI gui;
    private SerialDecoder decoder;
    private int LastRedrawWasForThisPacket, temp;
    public void run() {
      temp = gui.LastProcessedDataPoint;
      if (temp != LastRedrawWasForThisPacket) {
        LastRedrawWasForThisPacket = temp;
        gui.DrawMap(jSliderPackets.getValue());
      }
    }

    public MapUpdateTimerTask(MainGUI gui) {
      this.gui = gui;
    }
  }

	/**
	 * Handler for Left check mouse clicks. Toggles the drawing of left IR data.
	 * @param e Mouse event that triggered this function call.
	 */
  void jCheckLeft_mouseReleased(MouseEvent e) {
    mapDisplayLeftIR = jCheckLeft.isSelected();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Handler for Right check mouse clicks. Toggles the drawing of right IR data.
	 * @param e Mouse event that triggered this function call.
	 */
  void jCheckRight_mouseReleased(MouseEvent e) {
    mapDisplayRightIR = jCheckRight.isSelected();
    DrawMap(jSliderPackets.getValue());
  }

	/** 
	 * Handler for Middle check mouse clicks. Toggles the drawing of middle IR data.
	 * @param e Mouse event that triggered this function call.
	 */
  void jCheckMiddle_mouseReleased(MouseEvent e) {
    mapDisplayMiddleIR = jCheckMiddle.isSelected();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Handler for Zoom In button clicks. Increases the zoom level of the map.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButZoomIn_mouseReleased(MouseEvent e) {
    if (points_decoder != null) {
      points_decoder.ZoomIn();
      xoffset -= jPanelMap.getWidth() / 3 / mapscalingfactor;
      DrawMap(jSliderPackets.getValue());
    }
  }

	/**
	 * Handler for Zoom Out button clicks. Decreases the zoom level of the map.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButZoomOut_mouseReleased(MouseEvent e) {
    if (points_decoder != null) {
      points_decoder.ZoomOut();
      xoffset += jPanelMap.getWidth() / 6 / mapscalingfactor;
      DrawMap(jSliderPackets.getValue());
    }
  }

	/**
	 * Handler for Previous State button clicks. Seeks to the previous serial packet whose state is different from the current one.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButPreviousState_mouseReleased(MouseEvent e) {
    int i, state;
    jSliderPackets.setValue(getPreviousStatePacket(jSliderPackets.getValue()));
    UpdateCurrentlyDisplayedPacket();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Handler for Previous Packet button clicks. Displays the previous serial packet following the current one.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButPreviousPacket_mouseReleased(MouseEvent e) {
    int temp = jSliderPackets.getValue();
    if (temp != 0) {
      jSliderPackets.setValue(temp - 1);
      UpdateCurrentlyDisplayedPacket();
      DrawMap(temp - 1);
    }
  }

	/**
	 * Handler for Next Packet button clicks. Displays the next serial packet following the current one.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButNextPacket_mouseReleased(MouseEvent e) {
    int temp = jSliderPackets.getValue();
    if (temp != jSliderPackets.getMaximum()) {
      jSliderPackets.setValue(temp + 1);
      UpdateCurrentlyDisplayedPacket();
      DrawMap(temp + 1);
    }
  }

	/**
	 * Handler for NextState button clicks. Seeks in the received serial packets list to the packet with a different state than the current one.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButNextState_mouseReleased(MouseEvent e) {
    int i, state;
    jSliderPackets.setValue(getNextStatePacket(jSliderPackets.getValue()));
    UpdateCurrentlyDisplayedPacket();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Seeks backwards in the serial packet vector for a packet whose state differers from the current packet.
	 * @param myindex Index of the packet to be used as 'current' packet.
	 * @return The index of the previous packet. Returns 0 if no state change found.
	 */
  public int getPreviousStatePacket(int myindex) {
    int i, state;
    if (myindex < 0)
      return 0;
    if (myindex >= DataVector.size())
      return myindex;

    state = ((SerialPacket)GetDataVectorElement(myindex)).system_state;

    for (i = myindex; i > 0; i--)
      if (state != ((SerialPacket)GetDataVectorElement(i)).system_state)
        return i;

    return 0;
  }

	/**
	 * Seeeks forward in the serial packet vector for a packet whose state differs from the current packet.
	 * @param myindex Index of the packet to be used as 'current' packet.
	 * @return The index of the previous packet. Returns DataVector.size() if no state change found.
	 */
  public int getNextStatePacket(int myindex) {
    int i, state;
    if (myindex < 0)
      return 0;
    if (myindex >= DataVector.size())
      return myindex;

    state = ((SerialPacket)GetDataVectorElement(myindex)).system_state;

    for (i = myindex; i < DataVector.size(); i++)
      if (state != ((SerialPacket)GetDataVectorElement(i)).system_state)
        return i;

    return DataVector.size();
  }

	/**
	 * Convenience function: converts a string to an object.
	 * @param item String to be converted.
	 * @return An object containing the string.
	 */
  private Object makeObj(final String item)  {
    return new Object() {
      public String toString() {
        return item;
      }
    };
  }

	/**
	 * Handler for Find Path button clicks. Uses the map class to find the path in the maze.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButFindPath_mouseReleased(MouseEvent e) {
    if (points_decoder == null)
      return;

    if (findpath == null)
      findpath = new map(points_decoder.getXYVector());

    findpath.ClearMazeAndPaths(points_decoder.getXYVector());
    findpath.GenerateWallsVector();
    findpath.GenerateThePathVector();
    findpath.FindOptPathAStar();
    jCheckDrawPath.setSelected(true); bDrawPath = true;
    jCheckDrawWalls.setSelected(true); bDrawWalls = true;
    jCheckRight.setSelected(false); mapDisplayRightIR = false;
    jCheckLeft.setSelected(false); mapDisplayLeftIR = false;
    jCheckMiddle.setSelected(false); mapDisplayMiddleIR = false;
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Handler for Draw Path check mouse clicks. Toggles drawing of the calculated shortest path.
	 * @param e Mouse event that triggered this function call.
	 */
  void jCheckDrawPath_mouseReleased(MouseEvent e) {
    bDrawPath = jCheckDrawPath.isSelected();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Handler for the Draw Traces check mouse clicks. Toggles drawing of the hole-finding traces.
	 * @param e Mouse event that triggered this function call.
	 */
  void jCheckDrawTraces_mouseReleased(MouseEvent e) {
    bDrawTraces = jCheckDrawTraces.isSelected();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Handler for the Draw Walls check mouse clicks. Toggle drawing of the calculated walls.
	 * @param e Mouse event that triggered this function call.
	 */
  void jCheckDrawWalls_mouseReleased(MouseEvent e) {
    bDrawWalls = jCheckDrawWalls.isSelected();
    DrawMap(jSliderPackets.getValue());
  }

	/**
	 * Accessor used to get a reference to the serial decoder.
	 * @return A reference to the currently used serial decoder.
	 */
  public SerialDecoder getDecoder() {
    return decoder;
  }

	/**
	 * Fills the Commands combo box with all available manual commands.
	 *
	 */
  public void FillCommandList() {
    jComboCommands.addItem(makeObj(GetCommandShortName(2))); // 0
    jComboCommands.addItem(makeObj(GetCommandShortName(3))); // 1
    jComboCommands.addItem(makeObj(GetCommandShortName(4))); // 2
    jComboCommands.addItem(makeObj(GetCommandShortName(5))); // 3
    jComboCommands.addItem(makeObj(GetCommandShortName(6))); // 4
    jComboCommands.addItem(makeObj(GetCommandShortName(7))); // 5
    jComboCommands.addItem(makeObj(GetCommandShortName(8))); // 6
    jComboCommands.addItem(makeObj(GetCommandShortName(9))); // 7
    jComboCommands.addItem(makeObj(GetCommandShortName(10))); // 8
  }

	/**
	 * Gets a short version of a command from a command id.
	 * @param command Integer version of the command id.
	 * @return String representing the command.
	 */
  public String GetCommandShortName(int command) {
    switch (command) {
      case 2: return "Follow right";
      case 3: return "Clear";
      case 4: return "Turn 90 CW";
      case 5: return "Find right wall";
      case 6: return "Turn 90 CCW";
      case 7: return "Follow left";
      case 8: return "Find left wall";
      case 9: return "Find front wall";
      case 10: return "Autonomous";
      default: return "Unknown command";
    }
  }

	/**
	 * Matches combo box indexes to command id.
	 * @param comboBoxIndex The index of the selected combo box command.
	 * @return Command id.
	 */
  public int getCommandMessage(int comboBoxIndex) {
    switch (comboBoxIndex) {
      case 0: return 2;
      case 1: return 3;
      case 2: return 4;
      case 3: return 5;
      case 4: return 6;
      case 5: return 7;
      case 6: return 8;
      case 7: return 9;
      case 8: return 10;
      default: return 255;
    }
  }

	/**
	 * Handler for Send Command button clicks. Sends the currently selected command over the RF transmitter.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButSendCmd_mouseReleased(MouseEvent e) {
    int cmd;

    if (receiver == null)
      StartRF();
    if (receiver == null)
      return;

    cmd = getCommandMessage(jComboCommands.getSelectedIndex());
    receiver.sendMessage(cmd, 0);

  }

	/**
	 * Handler for Queue Command button clicks. Queues the currently selected command in the Command Manager.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButQueueCmd_mouseReleased(MouseEvent e) {
    int cmd;

    if (receiver == null)
      StartRF();
    if (receiver == null)
      return;

    cmd = getCommandMessage(jComboCommands.getSelectedIndex());
    if (commandMan.bCommandProcessorRunning == false) {
      commandMan.ClearData(receiver, decoder);
      decoder.SetCommandManager(commandMan);
    }
    commandMan.addCommand(cmd);
    commandMan.ExecuteCommandList();
  }

	/**
	 * Handler for Autonomous Mode button clicks. Prompt user for confirmation, then clears current data and queues an Autonomous command in the Command Manager. 
	 * @param e Mouse event that triggered this function call.
	 */
  void jButAuto_mouseReleased(MouseEvent e) {
    int cmd;
    if (JOptionPane.showConfirmDialog(this, "Confirm Autonomous Mode? All current data will be lost.", ProgramTitleShort, 0, 2) == JOptionPane.YES_OPTION) {
      if (receiver == null)
        StartRF();
      if (receiver == null)
        return;
      ClearData();
      cmd = 10;
      if (commandMan.bCommandProcessorRunning == false) {
        commandMan.ClearData(receiver, decoder);
        decoder.SetCommandManager(commandMan);
      }
      commandMan.addCommand(cmd);
      commandMan.ExecuteCommandList();
    }
  }

	/**
	 * Handler for Apply Shortest Path button clicks. Converts calculated path into commands and queues them in the Command Manager. A second click on this button cancels the execution.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButApplyShortestPath_mouseReleased(MouseEvent e) {
    if (bApplyingPath) {
      commandMan.AbortExecution();
      return;
    }

    if (findpath == null || !findpath.IsMazeSolved()) {
      if (JOptionPane.showConfirmDialog(this, "Cannot apply path when shortest path has not been computed. Compute shortest path now?", ProgramTitleShort, 0, JOptionPane.QUESTION_MESSAGE)  == JOptionPane.YES_OPTION) {
        jButFindPath_mouseReleased(e);
        if (findpath == null || !findpath.IsMazeSolved()) {
          JOptionPane.showMessageDialog(this, "Shortest path could not be computed.", ProgramTitleShort, JOptionPane.ERROR_MESSAGE);
          return;
        }
      }
      else
        return;
    }

    if (receiver == null)
      StartRF();
    if (receiver == null)
      return;

    bApplyingPath = true;
    ClearData();
    jButApplyShortestPath.setText("Abort");
    bApplyingPath = true; // cleardata() sets bApplyingPath to false
    jCheckDrawPath.setSelected(true); bDrawPath = true;
    jCheckDrawWalls.setSelected(true); bDrawWalls = true;
    Vector commands = findpath.ConvertoCommand();
    for (int i = 0; i < commands.size(); i++)
      commandMan.addCommand(((String)commands.elementAt(i)));
    commandMan.ExecuteCommandList();
    decoder.SetCommandManager(commandMan);
    //bApplyingPath = false;
  }

	/**
	 * Resets the caption of the Apply Path button.
	 *
	 */
  public void ResetApplyingPathButton() {
    jButApplyShortestPath.setText("Apply path");
  }

	/**
	 * Displays an error message to the user.
	 * @param errormsg Error message to be displayed.
	 */
  public void showError(String errormsg) {
    JOptionPane.showMessageDialog(this, errormsg, ProgramTitleShort, JOptionPane.ERROR_MESSAGE);
  }

	/**
	 * Handler for About button clicks.
	 * @param e Mouse event that triggered this function call.
	 */
  void jButAbout_mouseReleased(MouseEvent e) {
  	String aboutString;
  	aboutString = "Yare Automaton for Revealing Exits\n" + 
  							"Copyright 2003\n" +
  							"\n" +
  							"Software written by:\n" +
  							"  Member of the Fourth Year Project Group MSW1 - Class of September 2003\n" +
  							"  Mathieu Mallet (GUI, RF implementation)\n" + 
  							"  Erick Duschesneau (Packet decoding and interpretation)\n" +
  							"  Bruno Daoust (A* Algorithm)\n" +
  							"  Martin Hurtubise (Debugging)\n" +
  							"  Dominic Bergeron (RF protocols)";
  							 
		JOptionPane.showMessageDialog(this, aboutString, ProgramTitleShort, JOptionPane.INFORMATION_MESSAGE);
  }

	/**
	 * Handler for Map mouse clicks. Recenters the map to the clicked position. If the right button was used, then a wall is added to the positions between mousedown and mouseup.
	 * @param e Mouse event that triggered this function call.
	 */
  void jPanelMap_mouseReleased(MouseEvent e) {
    if (bAddingWall) {
      bAddingWall = false;
      if (findpath == null)
        return;
      findpath.addUserWall((AddWallX - jPanelMap.getWidth() / 6) / mapscalingfactor - xoffset,
                           (AddWallY - jPanelMap.getHeight() / 2) / mapscalingfactor - yoffset,
                           (e.getX() - jPanelMap.getWidth() / 6) / mapscalingfactor - xoffset,
                           (e.getY() - jPanelMap.getHeight() / 2) / mapscalingfactor - yoffset);
      findpath.ClearPathVector();
      findpath.GenerateThePathVector();
      findpath.FindOptPathAStar();
      DrawMap(jSliderPackets.getValue());
    }
    else {
      xoffset -= (e.getX() - jPanelMap.getWidth() / 2) / mapscalingfactor;
      yoffset -= (e.getY() - jPanelMap.getHeight() / 2) / mapscalingfactor ;
      DrawMap(jSliderPackets.getValue());
    }
  }

	/**
	 * Handler for Map mouse presses. If the right button is used, the current position is saved to add a wall when the mouse button is released.
	 * @param e Mouse event that triggered this function call.
	 */
  void jPanelMap_mousePressed(MouseEvent e) {
    if ((e.getModifiers() & MouseEvent.BUTTON3_MASK) != 0 && findpath != null) {
      bAddingWall = true;
      AddWallX = e.getX();
      AddWallY = e.getY();
    }
    else {
      bAddingWall = false;
    }
  }

	/**
	 * Function used to set the text displayed in the Command Queue status box.
	 * @param text Text to be displayed in the Command Queue status box.
	 */
  public void SetCommandQueueText(String text) {
    jTextCommandQueue.setText(text);
  }


}



