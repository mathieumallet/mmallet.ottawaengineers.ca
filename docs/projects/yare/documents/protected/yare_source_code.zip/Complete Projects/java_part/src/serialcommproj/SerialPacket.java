package serialcommproj;

/**
 * <p>Title: SerialPacket</p>
 * <p>Description: Container class used to store data received over RF link.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Mathieu Mallet
 * @version 1.0
 */

public class SerialPacket {

  public int IRL, IRM, IRR;
  public boolean bumperl, bumperr;
  public int lmotor_dir, lmotor_speed;
  public int rmotor_dir, rmotor_speed;
  public long time;
  public int system_state;
  public int padding;
  MainGUI gui;

	/**
	 * Constructor for objects of class SerialPacket. Creates an empty and invalid SerialPacket.
	 * @param gui Reference to a MainGUI object.
	 */
  public SerialPacket(MainGUI gui) {
    IRL = -1; IRM = -1; IRR = -1; bumperl = true; bumperr = true;
    lmotor_dir = -1; lmotor_speed = -1; rmotor_dir = -1; rmotor_dir = -1;
    time = -1;
    system_state = -1;
    padding = -1;
    this.gui = gui;
  }
	
	/**
	 * Constructor for objects of class SerialPacket. Initialises values from encoded data stream. 
	 * @param bits Array containing data encoded on 12 bytes.
	 * @param gui Reference to a MainGUI object.
	 */
  public SerialPacket(byte[] bits, MainGUI gui) {
    byte reconstructed, data;

    this.gui = gui;

    system_state = (GetByteInInt(bits[1]) & 15); // bits 4-7 on 2nd byte
    system_state = (system_state << 2) | ((GetByteInInt(bits[0]) >> 6) & 3); // bits 0-1 on 1st byte

    time = (GetByteInLong(bits[7]) & 15); // bits 4-7 on 8th byte
    time = (time << 8) | GetByteInLong(bits[6]); // bits 0-7 on 7th byte
    time = (time << 8) | GetByteInLong(bits[5]); // bits 0-7 on 6th byte
    time = (time << 8) | GetByteInLong(bits[4]); // bits 0-7 on 5th byte
    time = (time << 8) | GetByteInLong(bits[3]); // bits 0-7 on 5th byte
    time = (time << 8) | GetByteInLong(bits[2]); // bits 0-7 on 3th byte
    time = (time << 4) | ((GetByteInLong(bits[1]) >> 4) & 15); // bits 0-3  on 2nd byte

    rmotor_speed = (bits[7] & 240) >> 4; // bits 0-3 on 8th byte
    rmotor_dir = bits[8] & 1; // bit 0 of 9th byte

    lmotor_speed = (bits[8] & 30) >> 1; // bit 1-4 on 9th byte
    lmotor_dir = (bits[8] & 32) >> 5; // bits 5 on 9th byte

    bumperr = ((bits[8] & 64) >> 6) == 1; // bit 6 on 9th byte
    bumperl = ((bits[8] & 128) >> 7) == 1; // bit 7 of 9th byte

    IRR = GetByteInInt(bits[9]); // 10th byte
    IRM = GetByteInInt(bits[10]); // 11th byte
    IRL = GetByteInInt(bits[11]); // 12th byte

    //System.out.println("Code: " + (IRL < 0 ? IRL + 256 : IRL) + ", Distance: " + GetDistance(3) + " cm");
  }

	/**
	 * Constructor for objects of class SerialPacket. Initialises values from Strings.
	 * @param IRL Code received on left IR sensor.
	 * @param IRM Code received on middle IR sensor.
	 * @param IRR Code received on right IR sensor.
	 * @param bumperl True if left bumper is active, false otherwise.
	 * @param bumperr True if right bumper is active, false otherwise.
	 * @param lmotor_dir Direction in which left motor is turning: 0 for forward, 1 for backwards.
	 * @param lmotor_speed Speed at which left motor turns.
	 * @param rmotor_dir Direction in which right motor is turning: 0 for forward, 1 for backwards.
	 * @param rmotor_speed Speed at which right motor turns.
	 * @param time Time recorded on the robot. Increments by one every 40ns.
	 * @param system_state System state of the robot.
	 * @param padding Unused padding data send by the robot.
	 * @param gui Reference to a MainGUI object.
	 */
  public SerialPacket( String IRL, String IRM, String IRR,
                       String bumperl, String bumperr,
                       String lmotor_dir, String lmotor_speed, String rmotor_dir, String rmotor_speed,
                       String time, String system_state, String padding, MainGUI gui) {

    this.gui = gui;

    this.IRL = Integer.decode(IRL).intValue();
    this.IRL = this.IRL < 0 ? this.IRL + 256 : this.IRL; // hack to make 'bad' data work
    this.IRM = Integer.decode(IRM).intValue();
    this.IRM = this.IRM < 0 ? this.IRM + 256 : this.IRM; // hack to make 'bad' data work
    this.IRR = Integer.decode(IRR).intValue();
    this.IRR = this.IRR < 0 ? this.IRR + 256 : this.IRR; // hack to make 'bad' data work

    this.bumperl = Boolean.getBoolean(bumperl);
    this.bumperr = Boolean.getBoolean(bumperr);

    this.lmotor_dir = Integer.decode(lmotor_dir).intValue();
    this.lmotor_speed = Integer.decode(lmotor_speed).intValue();
    this.rmotor_dir = Integer.decode(rmotor_dir).intValue();
    this.rmotor_speed = Integer.decode(rmotor_speed).intValue();

    this.time = Long.decode(time).longValue();
    this.system_state = Integer.decode(system_state).intValue();
    this.padding = Integer.decode(padding).intValue();

  }

  /**
   * Returns distance in cm for a specific sensor.
   * @param IR Selects which sensor to use: 1 = left, 2 = middle, 3 = right
   * @return Distance in centimeters.
   */
  double GetDistance(int IR) {
    int code;
    switch (IR) {
      case 1:  // Left sensor
        code = (IRL < 0) ? IRL + 256 : IRL;
        return gui.getDecoder().IRLLookup[code] - gui.getDecoder().IRLLookup[223];
        //return (1.9 / Math.tan((float)(code-25)/1000));
        //return (1.9 / Math.tan((float)(code-25)/1000)) - 9.569425;

      case 2:  // Middle sensor
        code = (IRM < 0) ? IRM + 256 : IRM;
        return gui.getDecoder().IRMLookup[code] - gui.getDecoder().IRMLookup[235];
        //return (1.9 / Math.tan((float)(code-25)/1000));
        //return (1.9 / Math.tan((float)(code-25)/1000)) - 9.092463;

      case 3:  // Right sensor
        code = (IRR < 0) ? IRR + 256 : IRR;
        return gui.getDecoder().IRRLookup[code] - gui.getDecoder().IRRLookup[233];
        //return (1.9 / Math.tan((float)(code-25)/1000));
        //return (1.9 / Math.tan((float)(code-25)/1000)) - 9.230684;

      default:
        return -300;
    }
  }

	/**
	 * Converts a byte in long. Needed because java considers 1000000b to represent a negative byte.
	 * @param mybyte Byte to be converted.
	 * @return Long value of passed byte.
	 */
  long GetByteInLong(byte mybyte) {
    return (mybyte < 0) ? mybyte + 256 : mybyte;
  }

  /**
   * Converts a byte in int. Needed because java considers 1000000b to represent a negative byte.
   * @param mybyte Byte to be converted.
   * @return Int value of passed byte.
   */
  int GetByteInInt(byte mybyte) {
    return (mybyte < 0) ? mybyte + 256 : mybyte;
  }

	/**
	 * Converts a long into a string of 0s and 1s.
	 * @param mychars Long to be converted
	 * @return String containing 0s and 1s representing the passed Long.
	 */
  public static String getBinaryString(long mychars) {
    int i,j;
    String returned;

    returned = "";
      for (i = 0; i < 64; i++) {
        if (((mychars >> i) & 1) == 1)
          returned = "1" + returned;
        else
          returned = "0" + returned;
    }
    return returned;
  }

  public String getIRLString() { return String.valueOf(IRL); }
  public String getIRMString() { return String.valueOf(IRM); }
  public String getIRRString() { return String.valueOf(IRR); }

  public String getBumperLString() { return String.valueOf(bumperl); }
  public String getBumperRString() { return String.valueOf(bumperr); }

  public String getLMotorDirString() { return String.valueOf(lmotor_dir); }
  public String getLMotorSpeedString() { return String.valueOf(lmotor_speed); }
  public String getRMotorDirString() { return String.valueOf(rmotor_dir); }
  public String getRMotorSpeedString() { return String.valueOf(rmotor_speed); }

  public String getTimeString() { return String.valueOf(time); }
  public String getSystemStateString() { return String.valueOf(system_state); }
  public String getPaddingString() { return String.valueOf(padding); }

}
