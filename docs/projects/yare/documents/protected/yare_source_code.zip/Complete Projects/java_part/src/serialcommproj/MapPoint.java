package serialcommproj;

/**
 * <p>Title: MapPoint</p>
 * <p>Description: The MapPoint Class encapsulates data that was received from the Robot.  It provides methods to access the x,y coordinates for what was seen on the left, right, and middle IR sensor.  Methods are also provided to access the Robot state, as well as the Robot direction in radians (with respect to the right side of the map). </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Bruno Daoust
 * @version 1.0
 */

public class MapPoint {

  private double LeftX, LeftY;
  private double RightX, RightY;
  private double MiddleX, MiddleY;

  //RobotState = 0: SInit
  //RobotState = 1: SIdle
  //RobotState = 2: SFollow Right
  //RobotState = 3: SClear Of Corner
  //RobotState = 4: STurn 90 degrees Clock Wise
  //RobotState = 5: SFind Wall at right
  //RobotState = 6: STurn 90 degrees counter Clock Wise
  //RobotState = 15: SError
  //RobotState = 32 or higher: SWaiting for Command
  private int RobotState;

  private double RobotX, RobotY, RobotDir;

  /**
   * Default MapPoint constructor.
   */
  public MapPoint() {

  }

  /**
   * This constructor creates a MapPoint object that has all the data needed to
   * display the robot's displacements through the maze.
   *
   * @param LeftX X coordinate of the wall point seen by the left IR sensor.
   * @param LeftY Y coordinate of the wall point seen by the left IR sensor.
   * @param RightX X coordinate of the wall point seen by the right IR sensor.
   * @param RightY Y coordinate of the wall point seen by the right IR sensor.
   * @param MiddleX X coordinate of the wall point seen by the middle IR sensor.
   * @param MiddleY Y coordinate of the wall point seen by the middle IR sensor.
   * @param RobotX X coordinate of the current position of the Robot.
   * @param RobotY Y coordinate of the current position of the Robot.
   * @param RobotDir Direction that the robot is heading, in radians.
   * @param RobotState Current state of the Robot.
   */
  public MapPoint(double LeftX, double LeftY, double RightX, double RightY, double MiddleX, double MiddleY, double RobotX, double RobotY, double RobotDir, int RobotState)
  {
   this.LeftX = LeftX;
   this.LeftY = LeftY;
   this.RightX = RightX;
   this.RightY = RightY;
   this.MiddleX = MiddleX;
   this.MiddleY = MiddleY;
   this.RobotX = RobotX;
   this.RobotY = RobotY;
   this.RobotDir = RobotDir;
   this.RobotState = RobotState;
  }

  /**
   * This method returns the x coordinate of the point seen by the Left IR
   * sensor.
   *
   * @return The x coordinate of the wall point seen by the Left IR sensor.
   */
  public double getLeftX() { return LeftX; }
  
  /**
   * This method returns the y coordinate of the point seen by the Left IR
   * sensor.
   *
   * @return The y coordinate of the wall point seen by the Left IR sensor.
   */
  public double getLeftY() { return LeftY; }
  
  /**
   * This method returns the x coordinate of the point seen by the Right IR
   * sensor.
   *
   * @return The x coordinate of the wall point seen by the Right IR sensor.
   */
  public double getRightX() { return RightX; }
  
  /**
   * This method returns the y coordinate of the point seen by the Right IR
   * sensor.
   *
   * @return The y coordinate of the wall point seen by the Right IR sensor.
   */
  public double getRightY() { return RightY; }
  
  /**
    * This method returns the x coordinate of the point seen by the Middle IR
    * sensor.
    *
    * @return The x coordinate of the wall point seen by the Middle IR sensor.
   */
  public double getMiddleX() { return MiddleX; }
  
  /**
    * This method returns the y coordinate of the point seen by the Middle IR
    * sensor.
    *
    * @return The y coordinate of the wall point seen by the Middle IR sensor.
   */
  public double getMiddleY() { return MiddleY; }
  
  /**
     * This method returns the Robot State.
     *
     * @return The Robot State.
   */
  public int getRobotState() { return RobotState; }
  
  /**
    * This method returns the x coordinate of the Robot's current position.
    *
    * @return The x coordinate of the Robot's current position.
   */
  public double getRobotX() { return RobotX; }
  
  /**
    * This method returns the y coordinate of the Robot's current position.
    *
    * @return The y coordinate of the Robot's current position.
   */
  public double getRobotY() { return RobotY; }
  
  /**
    * This method returns the Robot's current orientation in radians, with
    * respect to the right side of the map.
    *
    * @return The Robot's current orientation in radians.
   */
  public double getRobotDir() { return RobotDir; }
  
}
