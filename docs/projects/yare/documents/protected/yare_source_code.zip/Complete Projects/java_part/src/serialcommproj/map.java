package serialcommproj;

import java.lang.Math;
import java.util.Vector;
import java.awt.*;
import java.awt.geom.*;

/**
 * <p>Title: map</p>
 * <p>Description: Performs maze-solving functions. </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Bruno Daoust, Erick Duchesneau, Mathieu Mallet
 * @version 1.0
 */

public class map
{

  public Vector TheWalls = new Vector();
  private Vector ThePath = new Vector();
  private Vector TheAStarOptimalPath = new Vector();
  public Vector newDataVector = new Vector();
  private MathFunctions DoMath = new MathFunctions();
  private boolean OptAStarPathCalculated = false;
  boolean MazeCanBeSolved = true;
  private Vector XYpoints;
  private Vector commands = new Vector();

  private static double sampleDistanceCM = 10; // how far apart samples are taken on the path to detect holes
  private static double WallHoleThresholdCM = 26; // how 'deep' a hole must be to be detected as a hole
  private static double EndOfWallLenght = 26; // how much of the path to discard at the beginning and end before checking for holes
  private static double HoleInWallPositionOffset = 5; // lenght added to the path before adding a point when a hole in found in the left wall
  private static double maximumAcceptableAngle = Math.PI / 10;
  private static double maximumAcceptableAngle2 = Math.PI / 8;


  private Vector emhTestVector = new Vector();

  /**
   * Constructor for objects of class map.
   */
  public map()
  {
  }
  
  /**
   * Constructor for objects of class map.
   * @param XYpoints A vector of data points to be used.
   */
  public map(Vector XYpoints){
    this.XYpoints = XYpoints;
  }

  /**
   * This method draws the maze using (Double[2]) Wall vectors that contain 2 or more points.
   *
   * @param gfx  The display area.
   * @param x The original x coordinate to set as the centre of the display area.
   * @param y The original y coordinate to set as the centre of the display area.
   * @param zoom The zoom level.
   * @param xoffset The x offset used to recenter the map after a zoom.
   * @param yoffset The y offset used to recenter the map after a zoom.
   * @param gui A reference to the main GUI.
   * @param bDrawPath True if we wish to display the path.
   * @param bDrawTraces True if we wish to display the traces.
   * @param bDrawWalls True if we wish to display the walls.
   */
  public void generateMaze(Graphics gfx, int x, int y, float zoom, float xoffset, float yoffset, MainGUI gui, boolean bDrawPath, boolean bDrawTraces, boolean bDrawWalls) {

    if (bDrawWalls) {
      for(int i=0;i < TheWalls.size();i++)
      {
        if(i <1)
          gfx.setColor(Color.magenta);
        else if(i <2)
          gfx.setColor(Color.red);
        else
          gfx.setColor(Color.cyan);
        for(int j=0;j < ((Vector)(TheWalls.get(i))).size() - 1;j++)
        {
          gfx.drawLine((int)(((double[])(((Vector)(TheWalls.get(i))).get(j)))[0]*zoom + x + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])((((Vector)TheWalls.get(i))).get(j)))[1]*zoom + y + (int)(yoffset * gui.mapscalingfactor)),(int)(((double[])((((Vector)TheWalls.get(i))).get(j+1)))[0]*zoom + x + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])((((Vector)TheWalls.get(i))).get(j+1)))[1]*zoom + y + (int)(yoffset * gui.mapscalingfactor)));
          gfx.drawOval((int)(((double[])(((Vector)(TheWalls.get(i))).get(j)))[0]*zoom + x - 1 + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])((((Vector)TheWalls.get(i))).get(j)))[1]*zoom + y - 1 + (int)(yoffset * gui.mapscalingfactor)),3,3);
        }
      }
    }

    if (bDrawPath) {
      gfx.setColor(Color.yellow);
      for(int k=0;k < ThePath.size() -1;k++)
      {
        gfx.drawLine((int)(((double[])(ThePath.get(k)))[0]*zoom + x + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])(ThePath.get(k)))[1]*zoom + y + (int)(yoffset * gui.mapscalingfactor)),(int)(((double[])(ThePath.get(k+1)))[0]*zoom+x + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])(ThePath.get(k+1)))[1]*zoom+y + (int)(yoffset * gui.mapscalingfactor)));
        gfx.drawOval((int)(((double[])(ThePath.get(k)))[0]*zoom + x - 1 + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])(ThePath.get(k)))[1]*zoom + y - 1 + (int)(yoffset * gui.mapscalingfactor)),3,3);
      }

      if(OptAStarPathCalculated) //(OptPathCalculated)
      {
        gfx.setColor(Color.blue);
        for(int k=0;k < TheAStarOptimalPath.size()-1;k++)
        {
          gfx.drawLine((int)(((double[])(TheAStarOptimalPath.get(k)))[0]*zoom+x + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])(TheAStarOptimalPath.get(k)))[1]*zoom+y + (int)(yoffset * gui.mapscalingfactor)),(int)(((double[])(TheAStarOptimalPath.get(k+1)))[0]*zoom+x + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])(TheAStarOptimalPath.get(k+1)))[1]*zoom+y + (int)(yoffset * gui.mapscalingfactor)));
          gfx.drawOval((int)(((double[])(TheAStarOptimalPath.get(k)))[0]*zoom+x-1 + (int)(xoffset * gui.mapscalingfactor)),(int)(((double[])(TheAStarOptimalPath.get(k)))[1]*zoom+y-1 + (int)(yoffset * gui.mapscalingfactor)),3,3);
        }
      }
    }

    // draw emh test vector
    if (bDrawTraces) {
      MapPoint temp;
      for(int k=0;k < emhTestVector.size();k++)
      {
        temp = (MapPoint)emhTestVector.elementAt(k);
        if (temp.getRobotState() == 1)
          gfx.setColor(Color.pink);
        else
          gfx.setColor(Color.orange);
        gfx.drawLine((int)(temp.getLeftX()*zoom+x + (int)(xoffset * gui.mapscalingfactor)), (int)(temp.getLeftY()*zoom+y + (int)(yoffset * gui.mapscalingfactor)), (int)(temp.getRightX()*zoom+x + (int)(xoffset * gui.mapscalingfactor)), (int)(temp.getRightY()*zoom+y + (int)(yoffset * gui.mapscalingfactor)));
      }
    }
  }

  /**
   * Clears all vectors, replaces XYpoints with new vector.
   *
   * @param newpoints A new set of raw data points.
   */
  public void ClearMazeAndPaths(Vector newpoints)
  {
    TheWalls = new Vector();
    ThePath = new Vector();
    emhTestVector = new Vector();
    TheAStarOptimalPath = new Vector();
    OptAStarPathCalculated = false;
    this.XYpoints = newpoints;
    //System.out.println("Map data cleared.");
    MazeCanBeSolved = false;
  }

  /**
	 * Clears the path vector.
	 *
	 */
  public void ClearPathVector() {
    ThePath = new Vector();
  }
  
  /**
	 * Checks if the maze has been solved.
	 * 
	 * @return     boolean   True if the maze has been solved, false if the maze has not been solved.
	 */
  public boolean IsMazeSolved() {
    return MazeCanBeSolved;
  }

  /**
	 * Finds the optimal path using the A* algoritm.  To work, it needs a path vector, and a wall vector. This functions places the optimal path in TheAStarOptimalPath vector (double[2]).
	 * 
	 */
  public void FindOptPathAStar()
  {
    MazeCanBeSolved = true;
    double dest_x = ((double[])ThePath.get(ThePath.size() - 1))[0];
    double dest_y = ((double[])ThePath.get(ThePath.size() - 1))[1];
    Vector ClosedList = new Vector();
    Vector OpenList = new Vector();
    AStarElem StartPoint = new AStarElem(((double[])ThePath.get(0))[0],((double[])ThePath.get(0))[1],dest_x,dest_y);
    AStarElem PointOnPath;
    ClosedList.clear();
    ClosedList.add(StartPoint);
    int limite = 0;

    while(!(areDoublesEqual(((AStarElem)ClosedList.lastElement()).getPointX(), dest_x) && areDoublesEqual(((AStarElem)ClosedList.lastElement()).getPointY(), dest_y)) && MazeCanBeSolved) // && limite <= 1000)
    {
      limite++;

    //System.out.println("limite : " + limite );
    //System.out.println("lastelemnt :" + ((AStarElem)ClosedList.lastElement()).getPointX());
      for(int i = 0; i < ThePath.size() ; i++) //allPoints_in_Path
      {
        //if(checkIfReachable(((AStarElem)ClosedList.lastElement()).getPointX(),((AStarElem)ClosedList.lastElement()).getPointY(),((int[])ThePath.get(i))[0],((int[])ThePath.get(i))[1],TheWalls))

        // check if point is reachable and if the point is not on the closed list
        if(checkIfReachable(((AStarElem)ClosedList.lastElement()).getPointX(),((AStarElem)ClosedList.lastElement()).getPointY(),((double[])ThePath.get(i))[0],((double[])ThePath.get(i))[1],TheWalls) && !(checkIfPartOfList(((double[])ThePath.get(i))[0],((double[])ThePath.get(i))[1],ClosedList)))
        {
        //if the point is on the open list we check to see if there is a shortest path to get there
        if(checkIfPartOfList(((double[])ThePath.get(i))[0],((double[])ThePath.get(i))[1],OpenList))
        {
          //if a shortest path exists we set the parent yielding the shortest path
          if(checkIfGIsSmaller(getElemFromList(((double[])ThePath.get(i))[0],((double[])ThePath.get(i))[1],OpenList),(AStarElem)ClosedList.lastElement()))
            (getElemFromList(((double[])ThePath.get(i))[0],((double[])ThePath.get(i))[1],OpenList)).setParent((AStarElem)ClosedList.lastElement());
        }
        else //if the point is not on the closed list we must add it to the open list
        {
          OpenList.add(new AStarElem(((double[])ThePath.get(i))[0],((double[])ThePath.get(i))[1],dest_x,dest_y,(AStarElem)ClosedList.lastElement()));
          //System.out.println("add open list: (" + ((double[])ThePath.get(i))[0] + "," +((double[])ThePath.get(i))[1] + "), size = " + OpenList.size() );

        }
       }
      }

      if (OpenList.isEmpty() && !(areDoublesEqual(((AStarElem)ClosedList.lastElement()).getPointX(), dest_x) && areDoublesEqual(((AStarElem)ClosedList.lastElement()).getPointY(), dest_y)))
        MazeCanBeSolved = false;

      //System.out.println("MazeCanBeSolved: " + MazeCanBeSolved);
      if(!OpenList.isEmpty())
      {
       ClosedList.add(FindMinReachF(OpenList,(AStarElem)ClosedList.lastElement()));
       //System.out.println("The last element of the Closed List is :" + ((AStarElem)ClosedList.lastElement()).getPointX());
       OpenList.remove(FindMinReachF(OpenList,(AStarElem)ClosedList.lastElement()));
      }
      }


    //System.out.println("MazeCanBeSolved: " + MazeCanBeSolved);

    PointOnPath = (AStarElem)ClosedList.lastElement();
    TheAStarOptimalPath.clear();
    while(!(PointOnPath == null))
    {
      TheAStarOptimalPath.add(0,new double[2]);
      ((double[])TheAStarOptimalPath.get(0))[0] = PointOnPath.getPointX();
      ((double[])TheAStarOptimalPath.get(0))[1] = PointOnPath.getPointY();
      PointOnPath = PointOnPath.getParent();
    }
    OptAStarPathCalculated = true;
  }
  
  /**
   * Finds the index of an AStarElem in a vector.
   *
   * @param  a   AstarElem we are looking for.
   * @param  v   The vector in which to look.
   * @return     The index of the searched AStarElem element. Returns -1 if the element could not be found.
   */
  public static int myIndexOf(AStarElem a, Vector v) {
    int i;
    AStarElem e;
    for (i = 0; i < v.size(); i++) {
      e = (AStarElem)v.elementAt(i);
      if (areDoublesEqual(e.getF(), a.getF()) &&
          areDoublesEqual(e.getG(), a.getG()) &&
          areDoublesEqual(e.getH(), a.getH()) &&
          areDoublesEqual(e.getPointX(), a.getPointX()) &&
          areDoublesEqual(e.getPointY(), a.getPointY()))
        return i;
    }

    return -1;
  }

  /**
   * This method looks if there is a Wall that intesects a direct line linking two points.  
   *
   * @param  x1   X coordinate of the first x,y point.
   * @param  y1   Y coordinate of the first x,y point.
   * @param  x2   X coordinate of the second x,y point.
   * @param  y2   Y coordinate of the second x,y point.
   * @param  TheWalls    the vector (double[2]) containing all the wall coordinates.
   * @return     True if no wall intersects the line linking the two source points, false otherwise.
   */
  public boolean checkIfReachable(double x1, double y1, double x2, double y2, Vector TheWalls)
  {
    double RobotLength = 10;
    double RobotWidth = 10;
    double StartX = 0, StartY = 0;
    double EndX = 0, EndY = 0;

    boolean intersection = false;
    double angle=0;
    for(int z=0;z<TheWalls.size();z++)
    {
      for(int k=0;k<((Vector)TheWalls.get(z)).size() - 1;k++)
      {
        if(!intersection){
          if(MathFunctions.checkIntersection(x1,y1,x2,y2,((double[])((((Vector)TheWalls.get(z))).get(k)))[0],((double[])((((Vector)TheWalls.get(z))).get(k)))[1],((double[])((((Vector)TheWalls.get(z))).get(k+1)))[0],((double[])((((Vector)TheWalls.get(z))).get(k+1)))[1]))
            return false; //The point is not reachable.

          angle = MathFunctions.FindDir(x1,y1,x2,y2);

          if(!((angle > -1*maximumAcceptableAngle && angle < maximumAcceptableAngle) ||
               (angle > Math.PI/2 -maximumAcceptableAngle && angle < Math.PI/2 + maximumAcceptableAngle) ||
               (Math.abs(angle) > Math.PI -maximumAcceptableAngle) ||
               (angle > -Math.PI/2 -maximumAcceptableAngle && angle < -Math.PI/2 +maximumAcceptableAngle))){
            //System.out.println("Point 1 (x1,y1): (" + x1 + "," + y1 + ")    Point 2 (x2,y2): (" + x2 + "," + y2 + ")   angle: " + angle);
            //System.out.println("false angle = " + angle);
            return false;
          }
        }
      }
    }
    //System.out.println("true angle = " + angle);
    return true; // The point is reachable.
  }

  /**
   * Finds weather a point x,y is part of a double[2] vector.
   *
   * @param  x1   X coordinate of the x,y point
   * @param  y1   Y coordinate of the x,y point
   * @param  TheList   The vector in which to look.
   * @return     True if the point is in the vector, false otherwise.
   */  
  public boolean checkIfPartOfList(double x1, double y1,Vector TheList)
  {
    for(int i = 0; i < TheList.size(); i++)
    {
      //if((((AStarElem)TheList.get(i)).getPointX() == x1) && ((AStarElem)TheList.get(i)).getPointY() == y1)
      //  return true;
      if(areDoublesEqual(((AStarElem)TheList.get(i)).getPointX(), x1) && areDoublesEqual(((AStarElem)TheList.get(i)).getPointY(), y1))
        return true;

    }
    return false;
  }
  
  /**
   * Compares two doubles, checks if they are equal with 0.01 precision.
   *
   * @param  a   First double.
   * @param  b   Second double. 
   * @return  True if the doubles are equal, false otherwise.
   */  
  public static boolean areDoublesEqual(double a, double b) {
    return (Math.abs(a - b) < 0.01);
  }
  
  /**
   * Used in A* algorithm,  compares the G value of the last element in the closed list with an element in the open list.
   *
   * @param  AStarElem_OnOL   Open list element.
   * @param  LastAStarElem_OnCL   Last element in the closed list. 
   * @return  True if the G of the last element in the closed list is smaller then the element in the open list.
   */  
  public boolean checkIfGIsSmaller(AStarElem AStarElem_OnOL, AStarElem LastAStarElem_OnCL)
  {
    if(LastAStarElem_OnCL.getG() + Math.sqrt(Math.pow(LastAStarElem_OnCL.getPointX() - AStarElem_OnOL.getPointX(),2) + Math.pow(LastAStarElem_OnCL.getPointY() - AStarElem_OnOL.getPointY(),2)) < AStarElem_OnOL.getG())
      return true;
    else
      return false;
  }

  /**
   * Find a perticular element in a vector and returns it.
   *
   * @param  x   X value of the required point.
   * @param  y   Y value of the required point.
   * @param  TheList   The vector to look into.
   * @return   The element in the vector that has the same characteristics Returns null if the element could not be found.
   */  
  public AStarElem getElemFromList(double x, double y, Vector TheList)
  {
    for(int i = 0; i < TheList.size(); i++)
    {
      if (areDoublesEqual(((AStarElem)TheList.get(i)).getPointX(), x) && areDoublesEqual(((AStarElem)TheList.get(i)).getPointY(), y))
        return (AStarElem)TheList.get(i);
    }
    return null;
  }

  /**
   * Finds the element in the open list that has the smallest F and that is reachable from the last element of the closed list.
   *
   * @param  AStarElem_OnOL   Vector of open list elements.
   * @param  LastAStarElem_OnCL   Last element in the closed list.
   * @return   The reachable element in the open list with the minimum F.
   */ 
	public AStarElem FindMinReachF(Vector TheOpenList,AStarElem LastAStarElem_OnCL)
  {
    AStarElem TheMin = (AStarElem)TheOpenList.get(0);
    for(int i = 0; i < TheOpenList.size(); i++)
    {
      if(((AStarElem)TheOpenList.get(i)).getF() <= TheMin.getF())
      //if(((AStarElem)TheOpenList.get(i)).getF() <= TheMin.getF() && checkIfReachable(LastAStarElem_OnCL.getPointX(),LastAStarElem_OnCL.getPointY(),((AStarElem)TheOpenList.get(i)).getPointX(),((AStarElem)TheOpenList.get(i)).getPointY(),TheWalls))
        TheMin = (AStarElem)TheOpenList.get(i);
    }
    return TheMin;
  }

  /**
   * Generates a path vector filled with x,y coordinates as double[2]. These coordinates are taken from the positions at which the robot has passed.
   *
   */ 
  public void GenerateThePathVector() {

/*    State	State ID

    SInit	           00
    SIdle	           01
    SFollowRight	   02
    SClearofCorner	   03
    STurn90CW	           04
    SFindWallAtRight	   05
    STurn90CCW	           06
    SError	           0F
    SWaitingForCommand	   2X
*/


    if (XYpoints == null || XYpoints.size() == 0)
      return;

    int i = 0;
    int index;
    int lastState = -1;
    double[] point;
    for (i = 0; i < XYpoints.size(); i++) {
      point = new double[2];
      point[0] = ((MapPoint)XYpoints.elementAt(i)).getRobotX();
      point[1] = ((MapPoint)XYpoints.elementAt(i)).getRobotY();

      if (((MapPoint)XYpoints.elementAt(i)).getRobotState() != lastState &&
          (((MapPoint)XYpoints.elementAt(i)).getRobotState() == 4 ||
          ((MapPoint)XYpoints.elementAt(i)).getRobotState() == 6 ||
          ((MapPoint)XYpoints.elementAt(i)).getRobotState() > 15 ||
          ((MapPoint)XYpoints.elementAt(i)).getRobotState() == 1 )){
        ThePath.add(point);
        index = ThePath.size() - 2;
        while (index >= 0 && findOpeningLeft((double[])ThePath.elementAt(index),point) != null){
          ThePath.insertElementAt(findOpeningLeft((double[])ThePath.elementAt(index),point), index+1);
          index = ThePath.size() - 2;

        }
      }
      lastState = ((MapPoint)XYpoints.elementAt(i)).getRobotState();
    }
  }

  /**
 * Generates a TheWalls vector filled WallVectors that contains with x,y coordinates as double[2]. These coordinates are taken from where the data recorded by the robot as it traveled. Each WallVector should be at least two elements long.
 *
 */ 
  public void GenerateWallsVector() {
    if (XYpoints == null || XYpoints.size() <= 1)
      return;

    int i = 0;
    Vector ThisWall;
    Vector LeftWall;
    boolean added = false;
    boolean done = false;
    double[] point;
    double[] lastpoint;
    int lastState = -1;
    double distance, Checkangle;
    double[] leftpoint = new double[2];
    Point2D.Double firstpoint = new Point2D.Double();

    // convert right IR sensor data into walls
    ThisWall = new Vector();
    LeftWall = new Vector();

    for (i = 0; i < XYpoints.size()-1; i++) {
      point = new double[2];

      if(((MapPoint)XYpoints.elementAt(i)).getRobotState() != ((MapPoint)XYpoints.elementAt(i+1)).getRobotState())
      {
        double tempX = 0;
        double tempY = 0;
        if (!done){
          leftpoint[0] = ((MapPoint)XYpoints.elementAt(i+1)).getLeftX();
          leftpoint[1] = ((MapPoint)XYpoints.elementAt(i+1)).getLeftY();
          LeftWall.add(leftpoint);
          leftpoint = new double[2];
          leftpoint[0] = ((MapPoint)XYpoints.elementAt(i+1)).getRobotX()-10;
          leftpoint[1] = ((MapPoint)XYpoints.elementAt(i+1)).getRobotY();
//  System.out.println("Robot startpoint = (" +leftpoint[0] + "," + leftpoint[1]+")" );
          LeftWall.add(leftpoint);
          leftpoint = new double[2];
          leftpoint[0] = ((MapPoint)XYpoints.elementAt(i+1)).getRightX();
          leftpoint[1] = ((MapPoint)XYpoints.elementAt(i+1)).getRightY();
          LeftWall.add(leftpoint);
          leftpoint = new double[2];
          TheWalls.add(LeftWall);
          LeftWall = new Vector();
          done = true;
        }
        //MapPoint TheMapPoint = ((MapPoint)XYpoints.elementAt(i));
        if(((MapPoint)XYpoints.elementAt(i)).getRobotState()> 15 ||
           //((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 3 ||
           //((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 6 ||
           //((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 15 ||
           ((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 1){
          MapPoint TheMapPoint = ((MapPoint)XYpoints.elementAt(i+1));
          point[0] = TheMapPoint.getRightX();
          point[1] = TheMapPoint.getRightY();
          ThisWall.add(point);
        }

        if(//((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 2 ||
           ((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 3 ||
           ((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 6 ||
           ((MapPoint)XYpoints.elementAt(i+1)).getRobotState() >= 15)// ||
          //((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 1)
        {
          MapPoint TheMapPoint = ((MapPoint)XYpoints.elementAt(i));
          point[0] = TheMapPoint.getRightX();
          point[1] = TheMapPoint.getRightY();
          ThisWall.add(point);

          if(((MapPoint)XYpoints.elementAt(i+1)).getRobotState() == 6)
          {
            if(TheMapPoint.getRobotDir() < Math.PI/4 && TheMapPoint.getRobotDir() > -1*Math.PI/4) //0 degrees
            {
              tempX = TheMapPoint.getMiddleX();
              tempY = TheMapPoint.getRightY();
            }
            if(TheMapPoint.getRobotDir() < (Math.PI/4 + Math.PI/2) && TheMapPoint.getRobotDir() > (-1*Math.PI/4 + Math.PI/2)) //90 degrees
            {
              tempX = TheMapPoint.getRightX();
              tempY = TheMapPoint.getMiddleY();
            }
            if(TheMapPoint.getRobotDir() < (Math.PI/4 - Math.PI/2) && TheMapPoint.getRobotDir() > (-1*Math.PI/4 - Math.PI/2)) //-90 degrees
            {
              tempX = TheMapPoint.getRightX();
              tempY = TheMapPoint.getMiddleY();
            }
            if(Math.abs(TheMapPoint.getRobotDir()) > (Math.PI/4 + Math.PI/2)) //180 degrees
            {
              tempX = TheMapPoint.getMiddleX();
              tempY = TheMapPoint.getRightY();
            }

            point[0] = tempX; //((MapPoint)XYpoints.elementAt(i)).getRightX();
            point[1] = tempY; //((MapPoint)XYpoints.elementAt(i)).getRightY();
            ThisWall.add(point);

          }
        }
      }
    }
    TheWalls.add(ThisWall);
    for (i = 0; i < XYpoints.size(); i++) {

      if((((MapPoint)XYpoints.elementAt(i)).getRobotState() == 2 ||
          ((MapPoint)XYpoints.elementAt(i)).getRobotState() == 3 ||
          ((MapPoint)XYpoints.elementAt(i)).getRobotState() == 5 )){//&&
      //MathFunctions.distance2points(((MapPoint)XYpoints.elementAt(i)).getLeftX(),((MapPoint)XYpoints.elementAt(i)).getLeftY(),((MapPoint)XYpoints.elementAt(i)).getRobotX(),((MapPoint)XYpoints.elementAt(i)).getRobotY()) < 59){// ||
//         ((MapPoint)XYpoints.elementAt(i)).getRobotState() == 5){


      firstpoint.x = ((MapPoint)XYpoints.elementAt(i)).getLeftX();
      firstpoint.y = ((MapPoint)XYpoints.elementAt(i)).getLeftY();
      if(!added && MathFunctions.distance2points(((MapPoint)XYpoints.elementAt(i)).getLeftX(),((MapPoint)XYpoints.elementAt(i)).getLeftY(),((MapPoint)XYpoints.elementAt(i)).getRobotX(),((MapPoint)XYpoints.elementAt(i)).getRobotY()) < 45){
        leftpoint[0] = firstpoint.x;
        leftpoint[1] = firstpoint.y;
        LeftWall.add(leftpoint);
        added = true;
        //System.out.println("firstpoint = (" + leftpoint[0] + "," + leftpoint[1] + "), sizeleftwall = " + LeftWall.size() );
        leftpoint = new double[2];

      }
      //System.out.println("this state = " + ((MapPoint)XYpoints.elementAt(i)).getRobotState() + ", Next state = " + ((MapPoint)XYpoints.elementAt(i+1)).getRobotState() + ", i= " + i );
      distance = firstpoint.distance(((MapPoint)XYpoints.elementAt(i+1)).getLeftX(), ((MapPoint)XYpoints.elementAt(i+1)).getLeftY());
      if(LeftWall.size() > 0)
        Checkangle = MathFunctions.FindDir(((double[])LeftWall.lastElement())[0],((double[])LeftWall.lastElement())[1], ((MapPoint)XYpoints.elementAt(i+1)).getLeftX(),((MapPoint)XYpoints.elementAt(i+1)).getLeftY());
      else
        Checkangle = 0.78120;
      if (((MapPoint)XYpoints.elementAt(i)).getRobotState() != ((MapPoint)XYpoints.elementAt(i+1)).getRobotState() ||
          (!((Checkangle > -1*maximumAcceptableAngle2 && Checkangle < maximumAcceptableAngle2) ||
          (Checkangle > Math.PI/2 -maximumAcceptableAngle2 && Checkangle < Math.PI/2 + maximumAcceptableAngle2) ||
          (Math.abs(Checkangle) > Math.PI -maximumAcceptableAngle2) ||
          (Checkangle > -Math.PI/2 -maximumAcceptableAngle2 && Checkangle < -Math.PI/2 +maximumAcceptableAngle2)) || distance > 7) &&
          MathFunctions.distance2points(((MapPoint)XYpoints.elementAt(i)).getLeftX(),((MapPoint)XYpoints.elementAt(i)).getLeftY(),((MapPoint)XYpoints.elementAt(i)).getRobotX(),((MapPoint)XYpoints.elementAt(i)).getRobotY()) < 59){


        leftpoint[0] = firstpoint.x;
        leftpoint[1] = firstpoint.y;
        LeftWall.add(leftpoint);
        distance = firstpoint.distance(((double[])LeftWall.firstElement())[0],((double[])LeftWall.firstElement())[1]);

        if(distance > 2)
          TheWalls.add(LeftWall);

        leftpoint = new double[2];
        LeftWall = new Vector();
        added = false;
      }
    }
    }
    if (LeftWall.size() > 1)
    {
      firstpoint.x = ((MapPoint)XYpoints.lastElement()).getLeftX();
      firstpoint.y = ((MapPoint)XYpoints.lastElement()).getLeftY();
      leftpoint[0] = firstpoint.x;
      leftpoint[1] = firstpoint.y;
      LeftWall.add(leftpoint);
      //System.out.println("sizeleftwall = " + LeftWall.size() );
      TheWalls.add(LeftWall);
    }


    //System.out.println("TheWall length = " + TheWalls.size());

  }

  /**
   * Generates a command vector to be sent to the robot. The vector is created using the shortest path data.
   *
   */ 
  public Vector ConvertoCommand(){
    int index =0;
    double robotdir,turndir;
    double length,noofdivisions;
    //AStarElem point1,point2,futurpoint;
    double[] point1 = new double[2];
    double[] point2 = new double[2];
    double[] futurPoint = new double[2];
    boolean bTurnedRightLast = false, bTurnedLeftLast = false;

    commands = new Vector();
    while (TheAStarOptimalPath.elementAt(index+1) != TheAStarOptimalPath.lastElement()){

      point1 = (double[])TheAStarOptimalPath.elementAt(index);
      point2 = (double[])TheAStarOptimalPath.elementAt(index+1);
      futurPoint = (double[])TheAStarOptimalPath.elementAt(index+2);

      index++;

      robotdir = -MathFunctions.FindDir(point1,point2);
      turndir = -MathFunctions.FindDir(point2,futurPoint);
//System.out.print("index = " + index + " (turndir - robotdir) > 0 =  " + ((turndir - robotdir) > 0) + "robot dir = " + robotdir + " turn dir = " + turndir + " ");
      if (MathFunctions.BoundPI(turndir - robotdir) > -Math.PI && MathFunctions.BoundPI(turndir - robotdir) < 0){ // turn right
        commands.add("// Turning right at next point...");
        commands.add("clearwall");
        if (!bTurnedRightLast) {
          commands.add("turnright");
          commands.add("findfrontwall");
          commands.add("turnleft");
        }
        commands.add("findrightwall"); // EMH: potential problem -- if so, remove this command
        commands.add("followright");
        findOpeningsCommands(point1, point2, -robotdir, false);
        commands.add("clearwall");
        commands.add("turnright");
        commands.add("findrightwall");
        bTurnedRightLast = true; bTurnedLeftLast = false;
      }
      else if(MathFunctions.BoundPI(turndir - robotdir) < Math.PI && MathFunctions.BoundPI(turndir - robotdir) > 0){ // turn left
        commands.add("// Turning left at next point...");
        commands.add("clearwall");
        if (!bTurnedLeftLast) {
          commands.add("turnleft");
          commands.add("findfrontwall");
          commands.add("turnright");
        }
        commands.add("findleftwall"); // EMH: potential problem -- if so, remove this command
        commands.add("followleft");
        findOpeningsCommands(point1, point2, -robotdir, true);
        commands.add("clearwall");
        commands.add("turnleft");
        commands.add("findleftwall");
        bTurnedRightLast = false; bTurnedLeftLast = true;
      }

    }

    point1 = (double[])TheAStarOptimalPath.elementAt(index);
    point2 = (double[])TheAStarOptimalPath.elementAt(index+1);
    robotdir = MathFunctions.FindDir(point1,point2);
    commands.add("// Going to last point...");
    commands.add("clearwall");
    if (!bTurnedRightLast) {
      commands.add("turnright");
      commands.add("findfrontwall");
      commands.add("turnleft");
    }
    commands.add("findrightwall"); // EMH: potential problem -- if so, remove this command
    commands.add("followright"); // final lap! yay!
    findOpeningsCommands(point1,point2, robotdir,false);
    commands.add("littlehappydance");

    return commands;
  }

 /**
 * Adds commands to the command vector, depending on the wall that is to be followed.
 *
 * @param  point1   The first path point.
 * @param  point2   The second path point.
 * @param  robotdir   The direction in which the robot is facing, in radians.
 * @param  bCheckLeftWall  True if checking the left wall, false if checking the right wall.
 */ 
  public void findOpeningsCommands(double[] point1, double[] point2, double robotdir, boolean bCheckLeftWall) {
    double[] currentpoint = new double[2];
    currentpoint = findOpening(point1, point2, robotdir, bCheckLeftWall);
    while (currentpoint != null) {
      if (bCheckLeftWall) {
        commands.add("// Skipping hole in left wall...");
        commands.add("clearwall");
        commands.add("findleftwall");
        commands.add("followleft");

      }
      else {
        commands.add("// Skipping hole in right wall...");
        commands.add("clearwall");
        commands.add("findrightwall");
        commands.add("followright");
      }
      currentpoint = findOpening(currentpoint, point2, robotdir, bCheckLeftWall);
    }
  }

 /**
 *  Adds a point to the path vector when an opening is found.
 *
 * @param  point1   The first x,y path coordinate.
 * @param  point2   The second x,y path coordinate.
 * @return double[]  The location where the point should be added to the path.  
 */
  public double[] findOpeningLeft(double[] point1, double[] point2) {
    double robotdir;
    robotdir = MathFunctions.FindDir(point1,point2);
    return findOpening(point1, point2, robotdir, true);
  }

  /**
 *  Fnds if there is an opening either on the right wall or left wall, and returns the location on the path of the opening
 *
 * @param  point1   The first x,y path coordinate.
 * @param  point2   The second x,y path coordinate.
 * @param  robotdir   The direction in which the robot is facing, in radians.
 * @param  bCheckLeftWall  True if checking the left wall, false if checking the right wall.
 * @return double[]  Returns the location where the point should be added to the path.
 */ 
  public double[] findOpening(double[] point1, double[] point2, double robotdir, boolean bCheckLeftWall) {
    double x1, y1, x2, y2, xmid, ymid;
    double startx, starty, endx, endy;
    double xtemp, ytemp;
    double distance, tempDist, lastDistance;
    double[] holeLocation = new double[2];
    int i;

    Line2D.Double perpendicular;
    startx = point1[0]; starty = point1[1];
    endx = point2[0]; endy = point2[1];
    x1 = startx + Math.cos(robotdir)*XYdecoder.CMtoXY(EndOfWallLenght);
    y1 = starty + Math.sin(robotdir)*XYdecoder.CMtoXY(EndOfWallLenght);
    x2 = x1; y2 = y1;

    lastDistance = -1; // assign impossible value -- used to see if this is the first distance we find

    while (Math.sqrt((endx - startx)*(endx - startx) + (endy - starty) * (endy - starty)) - EndOfWallLenght >
           Math.sqrt((x2 - startx)*(x2 - startx) + (y2 - starty) * (y2 - starty))) {
      x1 = x2; y1 = y2; // use last end point as start point
      x2 = x1 + Math.cos(robotdir)*XYdecoder.CMtoXY(sampleDistanceCM);
      y2 = y1 + Math.sin(robotdir)*XYdecoder.CMtoXY(sampleDistanceCM);
      xmid = (x1 + x2) / 2; ymid = (y1 + y2) / 2;

      if (bCheckLeftWall)
        perpendicular = MathFunctions.getLeftPerpendicular(x1, y1, x2, y2, robotdir);
      else
        perpendicular = MathFunctions.getRightPerpendicular(x1, y1, x2, y2, robotdir);
      distance = 1e10;

      for (i = 0; i < TheWalls.size(); i++) {
        tempDist = getDistanceFromWall(perpendicular, xmid, ymid, (Vector)TheWalls.elementAt(i));
        //System.out.println("Wall # " + i + " has " + ((Vector)TheWalls.elementAt(i)).size() + " elements. Distance = " + tempDist);
        if (tempDist < distance)
          distance = tempDist;
      }

      if ((distance - lastDistance > XYdecoder.CMtoXY(WallHoleThresholdCM) && (lastDistance != -1) && (lastDistance != 1e10) && (distance != 1e10))) {
        holeLocation[0] = xmid + Math.cos(robotdir)*XYdecoder.CMtoXY(HoleInWallPositionOffset);
        holeLocation[1] = ymid + Math.sin(robotdir)*XYdecoder.CMtoXY(HoleInWallPositionOffset);

        if (lastDistance == 1e10 || distance == 1e10)
          emhTestVector.addElement(new MapPoint(perpendicular.getX1(), perpendicular.getY1(),
              perpendicular.getX2(), perpendicular.getY2(), 0, 0, 0, 0, 0, 1));
        else if (bCheckLeftWall)
          emhTestVector.addElement(new MapPoint(perpendicular.getX1(), perpendicular.getY1(),
              perpendicular.getX1()-Math.cos(robotdir+Math.PI/2)*distance, perpendicular.getY1()-Math.sin(robotdir+Math.PI/2)*distance, 0, 0, 0, 0, 0, 1));
        else
          emhTestVector.addElement(new MapPoint(perpendicular.getX1(), perpendicular.getY1(),
              perpendicular.getX1()-Math.cos(robotdir-Math.PI/2)*distance, perpendicular.getY1()-Math.sin(robotdir-Math.PI/2)*distance, 0, 0, 0, 0, 0, 1));

        //System.out.println("Whee, I'm outputting a hole! I'm so much on crack. distance = " + distance + ", lastdistance = " + lastDistance);

        return holeLocation;
      }
      //System.out.println("Distance = " + distance + ", delta =" +  (distance - lastDistance));
      if (distance != 1e10)
        lastDistance = distance;

      if (lastDistance == 1e10 || distance == 1e10)
        emhTestVector.addElement(new MapPoint(perpendicular.getX1(), perpendicular.getY1(),
            perpendicular.getX2(), perpendicular.getY2(), 0, 0, 0, 0, 0, 0));
      else if (bCheckLeftWall)
        emhTestVector.addElement(new MapPoint(perpendicular.getX1(), perpendicular.getY1(),
            perpendicular.getX1()-Math.cos(robotdir+Math.PI/2)*distance, perpendicular.getY1()-Math.sin(robotdir+Math.PI/2)*distance, 0, 0, 0, 0, 0, 0));
      else
        emhTestVector.addElement(new MapPoint(perpendicular.getX1(), perpendicular.getY1(),
            perpendicular.getX1()-Math.cos(robotdir-Math.PI/2)*distance, perpendicular.getY1()-Math.sin(robotdir-Math.PI/2)*distance, 0, 0, 0, 0, 0, 0));
    }

    return null;
  }

  /**
   * Gets distance from a wall to a point.
   * @param perpendicular Perpendicular line. Needs to intersect the wall to test for distance.
   * @param x X position of the point from which to measure distance.
   * @param y Y position of the point from which to measure distance.
   * @param WallVector Vector of double[2] containing beginning and end points of wall
   * @return Distance from wall, or 1e10 if there is no wall intersecting the perpendicular.
   */
  public static double getDistanceFromWall(Line2D.Double perpendicular, double x, double y, Vector WallVector) {
    double x1, y1, x2, y2;
    Point2D.Double intersection;
    int index = 2;
    double distance, mindistance = 1e10;

    while (index <= WallVector.size()) {
      x1 = ((double[])WallVector.elementAt(index-2))[0];
      y1 = ((double[])WallVector.elementAt(index-2))[1];
      x2 = ((double[])WallVector.elementAt(index-1))[0];
      y2 = ((double[])WallVector.elementAt(index-1))[1];

      //System.out.println("Index =" + index +" Perp = p1(" + (int)perpendicular.x1 + "," + (int)perpendicular.y1 +"), p2("+ (int)perpendicular.x2 + "," + (int)perpendicular.y2 + "), path p1(" +(int)x1 +","+(int)y1+"), p2(" + (int)x2 + "," + (int)y2 +"), intersects? " + perpendicular.intersectsLine(x2, y2, x1, y1) );
      if (perpendicular.intersectsLine(x1, y1, x2, y2)) {
        intersection = MathFunctions.findIntersection(perpendicular, x1, y1, x2, y2);
        distance = intersection.distance(x, y);

        if (distance < mindistance)
          mindistance = distance;
      }

      index++;
    }

    return mindistance;
  }

  /**
 *  Allows a user to add a wall the maze.
 *
 * @param  x1   X coordinate of the first x,y point
 * @param  y1   Y coordinate of the first x,y point
 * @param  x2   X coordinate of the second x,y point
 * @param  y2   Y coordinate of the second x,y point
 */ 
  public void addUserWall(double x1, double y1, double x2, double y2) {
    if (TheWalls == null)
      return;

    double[] point1 = new double[2];
    Vector NewWall = new Vector();
    point1[0] = x1; point1[1] = y1;
    NewWall.add(point1);
    double[] point2 = new double[2];
    point2[0] = x2; point2[1] = y2;
    NewWall.add(point2);
    TheWalls.add(NewWall);
  }

}