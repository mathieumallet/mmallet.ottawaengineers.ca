package serialcommproj;

import java.io.*;
import java.util.*;
import javax.comm.*;

/**
 * <p>Title: SerialReceiver</p>
 * <p>Description: Class used to perform all communications over the serial link.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Mathieu Mallet
 * @version 1.0
 */

public class SerialReceiver implements Runnable, SerialPortEventListener {
  SerialDecoder decoder;

  static final byte STARTBYTE = 1;

  int BufferPos = 0;
  int junk;
  byte[] readBuffer = new byte[45];
  byte[] oneByte = new byte[1];
  boolean bReadingPacket = false;

  InputStream inputStream;
  OutputStream outputStream;
  SerialPort serialPort;
  Thread readThread;

	/**
	 * Gets a reference to the COM2 serial port. 
	 */
  public static CommPortIdentifier GetPort() {
    Enumeration portList;
    CommPortIdentifier portId;
    portList = CommPortIdentifier.getPortIdentifiers();

    while (portList.hasMoreElements()) {
        portId = (CommPortIdentifier) portList.nextElement();
        if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
            if (portId.getName().equals("COM2")) {
            //if (portId.getName().equals("/dev/term/a")) {
                System.out.println("COM2 found.");
                return portId;
            }
        }
    }
    return null;
  }

	/**
	 * Constructor for objects of class SerialReceiver. Opens a connection to a serial port upon instantiation.
	 * @param portId Serial port on which to connect.
	 * @param decoderRef Reference to a SerialDecoder object.
	 */
  public SerialReceiver(CommPortIdentifier portId, SerialDecoder decoderRef) {
    decoder = decoderRef;

    try {
      serialPort = (SerialPort) portId.open("SimpleReadApp", 2000);
    } catch (PortInUseException e) {}
    try {
      inputStream = serialPort.getInputStream();
      outputStream = serialPort.getOutputStream();
    } catch (IOException e) {}
    try {
      serialPort.addEventListener(this);
    } catch (TooManyListenersException e) {}
    serialPort.notifyOnDataAvailable(true);
    try {
      serialPort.setSerialPortParams(19200,
                                     SerialPort.DATABITS_8,
                                     SerialPort.STOPBITS_1,
                                     SerialPort.PARITY_NONE);
    } catch (UnsupportedCommOperationException e) {}
    //readThread = new Thread(this);
    //readThread.start();
  }

	/**
	 * Closes serial port.
	 *
	 */
  public void KillReceiver() {
    serialPort.removeEventListener();
    inputStream = null;
    serialPort.close();
    System.out.println("Serial receiver killed.");
  }

	/**
	 * Threaded code: sleep and only wake to process serial events.
	 */
  public void run() {
      try {
          Thread.sleep(20000);
      } catch (InterruptedException e) {}
  }

	/**
	 * Handler for events of type SerialPortEvent. This class seeks start bytes and, once received, gathers 45 bytes before sending them to the SerialDecoder.
	 */
  public void serialEvent(SerialPortEvent event) {
      switch(event.getEventType()) {
      case SerialPortEvent.BI:
      case SerialPortEvent.OE:
      case SerialPortEvent.FE:
      case SerialPortEvent.PE:
      case SerialPortEvent.CD:
      case SerialPortEvent.CTS:
      case SerialPortEvent.DSR:
      case SerialPortEvent.RI:
      case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
          break;
      case SerialPortEvent.DATA_AVAILABLE:
          try {
              while (inputStream != null && inputStream.available() > 0) {
                junk = inputStream.read(oneByte, 0, 1);

                if (bReadingPacket) { // We're reading packet -- add to buffer
                  readBuffer[BufferPos] = oneByte[0];
                  BufferPos++;
                }
                else if (oneByte[0] == STARTBYTE) { // Seeking start byte...
                  BufferPos = 0;
                  bReadingPacket = true;
                }

                if (BufferPos == 45) { // We have all data -- process the string
                  bReadingPacket = false;
                  BufferPos = 0;
                  decoder.AddPacket(readBuffer);
                }
              }
          } catch (IOException e) {}
          break;
      }
  }

	/**
	 * Gets String representation of a byte as a string of 0s and 1s.
	 * @param mychar Byte to be converted.
	 * @return String representation of the byte as a string of 0s and 1s.
	 */
  public static String getBinary(byte mychar) {
    int i;
    String returned;

    returned = "";
    for (i = 0; i < 8; i++) {
      if (((mychar >> i) & 1) == 1)
        returned = "1" + returned;
      else
        returned = "0" + returned;
    }
    return returned;
  }

	/**
	 * Gets the representation of an array of bytes as a string of 0s and 1s.
	 * @param mychars The array of bytes to be converted.
	 * @return A string of 0s and 1s representing the byte array, with a comma between each group of 8 bits.
	 */
  public static String getBinaryString(byte[] mychars) {
    int i,j;
    String returned;

    returned = "";
    for (j = 0; j < mychars.length; j++) {
      for (i = 7; i >= 0; i--) {
        if (((mychars[j] >> i) & 1) == 1)
          returned = returned + "1";
        else
          returned = returned + "0";
      }
      if (j != mychars.length - 1)
        returned = returned + ", ";
    }
    return returned;
  }
  
  /**
   * Converts a byte in int. Needed because java considers 1000000b to represent a negative byte.
   * @param mybyte Byte to be converted.
   * @return Int value of passed byte.
   */
  int GetByteInInt(byte mybyte) {
    return (mybyte < 0) ? mybyte + 256 : mybyte;
  }

  /**
   * Encodes two bytes in a 15-byte stream and sends it over the serial link.
   * @param Command 8 bits of data to be sent to the robot as Command.
   * @param ExtraData 8 bits of data to be send to the robot as ExtraData.
   */
  public void sendMessage(int Command, int ExtraData) {
    byte byte1, byte2, byte3;
    int part1, part2, part3, part4, checksum;
    byte fullstring[] = new byte[16];
    int i;

    fullstring[0] = 0x01; // start byte

    byte1 = GetByteFromInt(0x80 | (Command & 0x7F));
    byte2 = GetByteFromInt(0x80 | ((Command & 0x80) >> 7) | ((ExtraData & 0x3F) << 1));

    part1 = (Command & 0x1F);
    part2 = (Command >> 5) & 0x07;
    part2 = (part2) | ((ExtraData & 0x03) << 2);
    part3 = (ExtraData >> 2) & 0x1F;
    part4 = (ExtraData >> 7) & 0x01;
    checksum = part1 + part2 + part3 + part4;

    byte3 = GetByteFromInt(0x80 | ((ExtraData >> 6)& 0x03) | ((checksum & 0x1F) << 2));

    for (i = 0; i < 15; i += 3) {
      fullstring[i+1] = byte1;
      fullstring[i+2] = byte2;
      fullstring[i+3] = byte3;
    }

    try {
      outputStream.write(fullstring);
    } catch (IOException e) {
      System.out.println("Error writing to serial port");
    }

  }

  /**
   * Converts an int in byte. Needed because java considers 1000000b to represent a negative byte.
   * @param val Integer to be converted.
   * @return Byte value of passed integer.
   */
  public static byte GetByteFromInt(int val) {
    byte temp;
    temp = Byte.decode(String.valueOf(val > 127 ? val - 256 : val)).byteValue();
    return temp;
  }

}
