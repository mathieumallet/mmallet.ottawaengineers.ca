package serialcommproj;

import java.lang.Math;

/**
 * <p>Title: AStarElem</p>
 * <p>Description: The AStarElem class acts as a container for points that are going to be checked when we are trying to find the optimal path.  An AStarElem object contains the F, G, and H values for a specific (x,y) point on the path as well as it's parent (which is another AStarElem).  The first point that will be added to the closed list has a parent that is null.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Bruno Daoust
 * @version 1.0
 */

public class AStarElem
{
  /**
   *The x coordinate of the current point
   */
  private double point_x;
  /**
   *The y coordinate of the current point
   */
  private double point_y;
  /**
   *The x coordinate of the final destination
   */
  private double dest_x;
  /**
   *The y coordinate of the final destination
   */
  private double dest_y;
  /**
   *The Parent of the curren AStarElem object
   */
  private AStarElem TheParent;

  /**
   * Distance travelled so far from the origin
   */
  private double G;
  /**
   * Estimate of the distance left to travell
   */
  private double H;
  /**
   * The sum of G and H
   */
  private double F;

  /**
   * Constructor for objects of class AStarElem.  This constructor will be
   * used in the case where the AStarElem object we want to create is going to
   * be the first one added to the Closed List.  The parent for this AStarElem
   * is set to null when the object is created and furthermore, the values of F,
   * G and H are calculated.
   *
   * @param x The x position of this point
   * @param y The y position of this point
   * @param x_dest The x position of the destination point
   * @param y_dest The y position of the destination point
   */
  public AStarElem(double x, double y, double x_dest, double y_dest)
  {
    point_x = x;
    point_y = y;
    dest_x = x_dest;
    dest_y = y_dest;
    TheParent = null;
    calcFGH();
  }

  /**
   * Constructor for objects of class AStarElem.  The parent for this AStarElem
   * is set to be the AStarElem that is passed as an argument to the
   * constructor.  Furthermore, when the object is created the values of F,
   * G and H are calculated.
   *
   * @param x The x position of this point
   * @param y The y position of this point
   * @param x_dest The x position of the destination point
   * @param y_dest The y position of the destination point
   * @param TheNewParent The AStarElem that is the parent of this AStarElem
   */
  public AStarElem(double x, double y, double x_dest, double y_dest, AStarElem TheNewParent)
  {
    point_x = x;
    point_y = y;
    dest_x = x_dest;
    dest_y = y_dest;
    TheParent = TheNewParent;
    calcFGH();
  }

  /**
   * This function returns the G value for this AStarElem.
   * @return The G value for this AStarElem.
   */
  public double getG()
  {
    return G;
  }
  /**
   * This function returns the H value for this AStarElem.
   * @return The H value for this AStarElem.
   */
  public double getH()
  {
    return H;
  }
  /**
   * This function returns the F value for this AStarElem.
   * @return The F value for this AStarElem.
   */
  public double getF()
  {
    return F;
  }
  /**
   * This function returns the x coordinate of this AStarElem.
   * @return The x coordinate of this AStarElem.
   */
  public double getPointX()
  {
    return point_x;
  }
  /**
   * This function returns the y coordinate of this AStarElem.
   * @return The y coordinate of this AStarElem.
   */
  public double getPointY()
  {
    return point_y;
  }
  /**
   * This function returns the Parent of this AStarElem.
   * @return The Parent of this AStarElem.
   */
  public AStarElem getParent()
  {
    return TheParent;
  }
  /**
   * This function sets the Parent of this AStarElem to the new Parent provided
   * to the function as an argument.
   *
   * @param TheNewParent The AStarElem that will now become the parent of this
   * AStarElem.
   */
  public void setParent(AStarElem TheNewParent)
  {
    TheParent = TheNewParent;
  }

  /**
   * This function calculates the F (sum of G and H), G (distance travelled so
   * far from the origin), and H (estimate of the distance left to travel)
   * values.
   */
  public void calcFGH()
  {
    if(TheParent == null)
      G = 0;
    else
      G = TheParent.getG() + Math.sqrt(Math.pow(TheParent.getPointX() - point_x,2) + Math.pow(TheParent.getPointY() - point_y,2));

    H = Math.sqrt(Math.pow(dest_x - point_x,2) + Math.pow(dest_y - point_y,2));
    F = G + H;
  }
}