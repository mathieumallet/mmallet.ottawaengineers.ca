package serialcommproj;

import java.awt.geom.*;

/**
 * <p>Title: MathFunctions</p>
 * <p>Description: The MathFunctions Class contains all of the mathematical functions used througout our code. All the functions are static, meaning that you don't have create an instance of MathFunctions to use these functions.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Bruno Daoust, Mathieu Mallet, Erick Duchesneau
 * @version 1.0
 */

public class MathFunctions
{
	
  /**
   * This function takes as parameters a set of 4 points (each point consists
   * of an x and a y value) that are used to specify two lines.  Note that,
   * each line is represented by a set of 2 points.  Once the two lines are
   * defined, the function checks to see if there is an intersection between
   * the two lines.
   *
   * @param x1 X coordinate of the start point of Line 1.
   * @param y1 Y coordinate of the start point of Line 1.
   * @param x2 X coordinate of the end point of Line 1.
   * @param y2 Y coordinate of the end point of Line 1.
   * @param x3 X coordinate of the start point of Line 2.
   * @param y3 Y coordinate of the start point of Line 2.
   * @param x4 X coordinate of the end point of Line 2.
   * @param y4 Y coordinate of the end point of Line 2.
   * @return If the two lines intersect, then this function returns true,
   * otherwise it returns false.
   */
  public static boolean checkIntersection(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
    //Create the first line
    Line2D.Double line1 = new Line2D.Double(x1, y1, x2, y2);
    //Create the second line
    Line2D.Double line2 = new Line2D.Double(x3, y3, x4, y4);
    //Check for an intersection.
    return line1.intersectsLine(line2);
  }

  /**
   * This function takes in two set of points that define a line and then
   * calculates the b and m values for that line.
   *
   * @param x1 The x coordinate of the start point of the line.
   * @param y1 The y coordinate of the start point of the line.
   * @param x2 The x coordinate of the end point of the line.
   * @param y2 The y coordinate of the end point of the line.
   * @return An array containing 3 elements. The first element is the b, the
   * second element is m and the third element is 0 if the slope is not
   * infinite, 1 if it is.
   */
  public static double[] calcBMofLine(double x1, double y1, double x2, double y2)
  {
    //BMArray[0] is the b in y = mx + b
    //BMArray[1] is the m in y = mx + b
    //BMArray[2] is 0 if the slope is not infinite, and 1 if it is.

    double[] BMArray = new double[3];
    if(x1 == x2)
    {
      //The slope is infinite
      BMArray[0] = 0;
      BMArray[1] = 0;
      BMArray[2] = 1;
    }
    else
    {
      //The slope is not infinite, so we can calculate values for m and b
      double b,slope = 0;
      slope = (y2 - y1)/(x2 - x1);
      b = y1 - slope*x1;
      BMArray[0] = b;
      BMArray[1] = slope;
      BMArray[2] = 0;
    }
    return BMArray;
  }

  /**
   * This function takes in a 2D array of points (where points are grouped in
   * x,y pairs) and then finds the linear regression based on the methode of
   * least squares.  The slope and intersection are returned in an array.
   *
   * @param xyArray The 2D array of points.
   * @return An array that contains the b (as the first element of the array)
   * and m (as the second element of the array) values of the calculated line
   * (ie. y = mx + b).
   */
  public static double[] calcLinearReg(double[][] xyArray)
  {
    double sumOfX = 0;
    double sumOfY = 0;
    double sumOfXsquare = 0;
    double sumOfYsquare = 0;
    double sumOfXY = 0;
    double b  = 0;
    double m = 0;
    double[] bm_array = new double[2];

    for(int i = 0; i < xyArray.length; i++)
    {
      sumOfX += xyArray[i][0];
      sumOfY += xyArray[i][1];
      sumOfXsquare += xyArray[i][0]*xyArray[i][0];
      sumOfYsquare += xyArray[i][1]*xyArray[i][1];
      sumOfXY += xyArray[i][0]*xyArray[i][1];
    }

    m = (sumOfXY - (sumOfX*sumOfY)/xyArray.length)/(sumOfXsquare - sumOfX*sumOfX/xyArray.length);
    b = sumOfY/xyArray.length  - m*sumOfX/xyArray.length;
    bm_array[0] = b;
    bm_array[1] = m;
    return bm_array;
  }

  /**
   * Based on a line y1 = m1x + b1, this function finds the projection of the
   * line y2 = m2x + b2 (where y2 is a line of length L/2 that is
   * perpendiculare to y1) on the x an y axis.
   *
   * @param x1 X coordinate of the starting point of the first line.
   * @param y1 Y coordinate of the starting point of the first line.
   * @param x2 X coordinate of the starting point of the second line.
   * @param y2 Y coordinate of the starting point of the second line.
   * @param L Length of the line that will be projected on the x and y axis.
   * @return An array containing the length of the projection on the x axis
   * (first element) and the length of the projection on the y axis (second
   * element).
   */
  public static double[] getXandYProjection(double x1,double y1,double x2,double y2, double L)
  {
    boolean slopeOneIsInfinite = false;
    boolean slopeOneIsZero = false;
    double slope1 = 0, b1 = 0;
    double slope2 = 0, b2 = 0;
    double theta = 0;
    double deltaX = 0, deltaY =0;
    double[] xyProjectionArray = new double[2];

    if(x1 == x2)
    {
      slopeOneIsInfinite = true;
      deltaX = L/2;
      deltaY = 0;
    }

    if(y1 == y2)
    {
      slopeOneIsZero = true;
      deltaX = 0;
      deltaY = L/2;
    }
    if((!slopeOneIsInfinite) && (!slopeOneIsZero))
    {
      slope1 = (y2 - y1)/(x2-x1);
      slope2 = -1/slope1;
      theta = Math.atan(Math.abs(slope2));
      deltaX = ((L/2)*(Math.cos(theta)));
      deltaY = ((L/2)*(Math.sin(theta)));
    }
    xyProjectionArray[0] = deltaX;
    xyProjectionArray[1] = deltaY;
    return xyProjectionArray;
  }

  /**
   * This function takes as parameters a set of 2 points that are used to
   * define a line, as well as an angle indicating the orientation of the Robot.
   * Then, the function finds a line that is perpendicular and to the left
   * (based on the direction of the Robot) of the specified line.
   * Also, the perpendicular line starts midway between the start and
   * end of the specified line.
   *
   * @param x1 X coordinate of the start point of the line.
   * @param y1 Y coordinate of the start point of the line.
   * @param x2 X coordinate of the end point of the line.
   * @param y2 Y coordinate of the end point of the line.
   * @param rot Orientation of the robot in radians with respect to the right
   * side of the map.
   * @return A line that is perpendicular to the line sent as a parameter to
   * the function.
   */
  public static Line2D.Double getLeftPerpendicular(double x1, double y1, double x2, double y2, double rot) {
    double x, y;
    x = (x1 + x2) / 2; y = (y1 + y2) / 2;
    return new Line2D.Double(x, y, x + 50000 * -Math.cos(rot + Math.PI/2), y + 50000 * -Math.sin(rot + Math.PI/2));
  }

  /**
   * This function takes as parameters a set of 2 points that are used to
   * define a line, as well as an angle indicating the orientation of the Robot.
   * Then, the function finds a line that is perpendicular and to the right
   * (based on the direction of the Robot) of the specified line.
   * Also, the perpendicular line starts midway between the start and
   * end of the specified line.
   *
   * @param x1 X coordinate of the start point of the line.
   * @param y1 Y coordinate of the start point of the line.
   * @param x2 X coordinate of the end point of the line.
   * @param y2 Y coordinate of the end point of the line.
   * @param rot orientation of the robot in radians with respect to the right
   * side of the map.
   * @return A line that is perpendicular to the line sent as a parameter to
   * the function.
   */
  public static Line2D.Double getRightPerpendicular(double x1, double y1, double x2, double y2, double rot) {
    double x, y;
    x = (x1 + x2) / 2; y = (y1 + y2) / 2;
    return new Line2D.Double(x, y, x + 50000 * -Math.cos(rot - Math.PI/2), y + 50000 * -Math.sin(rot - Math.PI/2));
  }

  /**
   * This function takes in two double arrays (each double array contains the x
   * coordinate of a point as the first element and the y coordinate of a point
   * as the second element) that are used to define a line.  The angle of that
   * line (with respect to the right side of the map) is then calculated.
   *
   * @param point1 Array containing the x,y coordinates of the first point.
   * @param point2 Array containing the x,y coordinates of the second point.
   * @return The angle between this line and the horizontal.
   */
  public static double FindDir(double[] point1, double[] point2) {
    return Math.atan2(point2[1] - point1[1],point2[0] - point1[0]);
  }

  /**
   * This function takes in two sets of points that are used to define a line.
   * The angle of that line (with respect to the right side of the map)
   * is then calculated.
   *
   * @param x1 X coordinate of the first point.
   * @param y1 Y coordinate of the first point.
   * @param x2 X coordinate of the second point.
   * @param y2 Y coordinate of the second point.
   * @return The angle between this line and the horizontal.
   */
  public static double FindDir(double x1, double y1, double x2, double y2) {
    return Math.atan2(y2 - y1, x2 - x1);
  }

  /**
   * This function takes an angle that is not necessarily between -pi and pi
   * and returns the equivalent angle between -pi and pi.
   * @param angle The angle we want to be bound between -pi and pi
   * @return  If angle< -pi or angle > pi, then an equivalent value between
   * -pi and pi is returned.  Otherwise the angle is returned unchanged.
   */
  public static double BoundPI(double angle){
    if (angle > Math.PI)
      return BoundPI(angle - 2*Math.PI);
    if (angle < -Math.PI)
      return BoundPI(angle + 2*Math.PI);
    return angle;
  }

  /**
   * This function finds the intersection between a line object and a line that
   * is defined by a set of two points.
   *
   * @param line This is a line object that contains the starting point and end
   * point of first line.
   * @param x1 X coordinate of the starting point of the second line.
   * @param y1 Y coordinate of the starting point of the second line.
   * @param x2 X coordinate of the end point of the second line.
   * @param y2 Y coordinate of the end point of the second line.
   * @return A Point2D object containing the x,y coordinates of the point of
   * intersection.
   */
  public static Point2D.Double findIntersection(Line2D.Double line, double x1, double y1, double x2, double y2) {
    Point2D.Double myPoint = new Point2D.Double();
    double num = (y2 - y1) * (x1 - line.getX1()) - (x2 - x1) * (y1 - line.getY1());
    double denum = (y2 - y1) * (line.getX2() - line.getX1()) - (x2 - x1) * (line.getY2() - line.getY1());
    myPoint.x = line.getX1() + (line.getX2() - line.getX1()) * num / denum;
    myPoint.y = line.getY1() + (line.getY2() - line.getY1()) * num / denum;
    return myPoint;
  }

  /**
   * This function finds the point of intersection between line1 and line2
   *
   * @param line1 The first line
   * @param line2 The second line
   * @return The point where line1 and line2 intersect.
   */
  public static Point2D.Double findIntersection(Line2D.Double line1, Line2D.Double line2) {
    return findIntersection(line1, line2.getX1(), line2.getY1(), line2.getX2(), line2.getY2());
  }

  /**
   * This function calculates the distance between two points.
   *
   * @param x1 X coordinate of Point 1.
   * @param y1 Y coordinate of Point 1.
   * @param x2 X coordinate of Point 2.
   * @param y2 Y coordinate of Point 2.
   * @return The distance between Point 1 and Point 2.
   */
  public static double distance2points(double x1, double y1, double x2, double y2){
    return Math.sqrt(Math.pow(x1-x2,2) + Math.pow(y1-y2,2));
  }

}