i = 70:1:255;
%y = spline(xy(:,2), xy(:,1), i);
y = interp1(xy(:,2), xy(:,1), i, 'linear');
figure(1); plot(xy(:,2), xy(:,1));
figure(2); plot(i, y);

data = '';

for j = i
    data = sprintf('%s\nIRRLookup[%d] = %d;', data, j, y(j - 70 + 1))
end