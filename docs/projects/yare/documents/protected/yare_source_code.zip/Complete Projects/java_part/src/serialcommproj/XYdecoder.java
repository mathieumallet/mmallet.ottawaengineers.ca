package serialcommproj;

import java.util.Vector;
import java.awt.Graphics;
import java.awt.Color;

/**
 * <p>Title: XYDecoder</p>
 * <p>Description: Processes SerialPackets in order to obtain x,y positions of the robot and its IR sensor readings.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Erick Duchesneau
 * @version 1.0
 */

public class XYdecoder implements Runnable {
  private Thread myThread;
  private MainGUI gui;
  private int index;
  private SerialPacket lastpoint;
  private Vector XYvector;

  private static double CMCONV = 1;
  private static double TIMECONV = 1;
  private static double WHEELSPACING = 15.5;
  private static double LSENSOR = 26/2;
  private static double RSENSOR = 26/2;
  private static double MSENSOR = 14.5;

  private static double LMSfslow = 11.20; //6.115; //original
  private static double LMSfmedium = LMSfslow; //11.35; //original
  private static double LMSffast = LMSfslow; //11.97; //original
  private static double LMSrfast = -LMSfslow; //-11.8; //original

  private static double RMSfslow = LMSfslow; // 5.945; //original
  private static double RMSfmedium = LMSfslow; //11.16; //original
  private static double RMSffast = LMSfslow; // 11.97; //original
  private static double RMSrfast = -LMSfslow; //-12.04; //original


  private double LeftX, LeftY;
  private double RightX, RightY;
  private double MiddleX, MiddleY;

  private int RobotState;

  private double RobotX, RobotY, RobotDir;

  private boolean zoomed = false;

	/**
	 * constructor 
         * 
	 * @param gui  the main gui
	 * @param DataVector   does nothing  
	 */
  public XYdecoder(MainGUI gui, Vector DataVector) {
    //this.DataVector = DataVector;
    this.gui = gui;
    Init();
  }

	/**
	 *  initializes the vectors and varialbles
	 *
	 */
  public void Init() {
    XYvector = new Vector();
    myThread = new Thread(this);
    myThread.start();
    index = 0;
    //gui.mapscalingfactor = 1;
  }

	/**
	 * used to start and suspend the thread
	 *  
	 */
  public void run() {
    SerialPacket aPacket;
    while(true) {
      aPacket = (SerialPacket)gui.GetDataVectorElement(index);
      if (aPacket == null || lastpoint == aPacket) {
        myThread.suspend();
      }
      else {
        Process(aPacket);
        index++;
      }
    }
  }
  
	/**
	 * used to restart the thread after a suspend 
	 *
	 */
  public void PacketAvailable() {
    myThread.resume();
  }

	/**
	 * Process, converts Serialpacket data into Mappoint data,  transforms raw serial data into xy coordinates for the robot and the walls
	 * 
	 * @param currentpoint  the current serial packet data
	 */
  public void Process(SerialPacket currentpoint) {
    if (lastpoint == null)
    {
      lastpoint = currentpoint;

      LeftX = 0;
      LeftY = CMtoXY(lastpoint.IRL+LSENSOR);
      RightX = 0;
      RightY = -CMtoXY(lastpoint.IRR+RSENSOR);
      MiddleX = CMtoXY(lastpoint.IRM+MSENSOR);
      MiddleY = 0;

      RobotState = lastpoint.system_state;

      RobotX = 0;
      RobotY = 0;
      RobotDir = 0;

      MapPoint newpoint = new MapPoint(LeftX, LeftY, RightX, RightY, MiddleX,
                                       MiddleY, RobotX, RobotY, RobotDir,
                                       RobotState);
      XYvector.add(newpoint);

    }
    else
    {
      //calculates time
      double time;
      time =  (currentpoint.time - lastpoint.time) / (double)25000000;

      //gets the robot speed
      double speedleft = GetSpeed(currentpoint, 1, time);
      double speedright = GetSpeed(currentpoint, 2, time);
      double speed = (speedleft + speedright) / (double)2;

      //must update the direction, current dir + angle variance
      RobotDir = RobotDir + UpdateDir(speedleft, speedright, time);

      // bound robot dir between -PI and PI
      if (RobotDir < -Math.PI)
        RobotDir += Math.PI * 2;
      if (RobotDir > Math.PI)
        RobotDir -= Math.PI * 2;

      //find the new robot coordinats
      //System.out.println("Robot dir = " +RobotDir);
      RobotX =  RobotX + CMtoXY(((double)time*(double)speed)*(double)Math.cos(RobotDir)) ;
      RobotY =  RobotY + CMtoXY(((double)time*(double)speed)*(double)Math.sin(RobotDir)) ;

      RobotState = currentpoint.system_state;

      //find the front, left and right walls
      LeftX = RobotX + TIMEtoXY(currentpoint.GetDistance(1)+LSENSOR)*-Math.cos(RobotDir + Math.PI/(double)2);
      LeftY = RobotY + TIMEtoXY(currentpoint.GetDistance(1)+LSENSOR)*-Math.sin(RobotDir + Math.PI/(double)2);
      RightX = RobotX + TIMEtoXY(currentpoint.GetDistance(3)+RSENSOR)*-Math.cos(RobotDir - Math.PI/(double)2);
      RightY = RobotY + TIMEtoXY(currentpoint.GetDistance(3)+RSENSOR)*-Math.sin(RobotDir - Math.PI/(double)2);
      MiddleX = RobotX + TIMEtoXY(currentpoint.GetDistance(2)+MSENSOR)*Math.cos(RobotDir);
      MiddleY = RobotY + TIMEtoXY(currentpoint.GetDistance(2)+MSENSOR)*Math.sin(RobotDir);

      //done calculations,  now time to get ready for next points.
      lastpoint = currentpoint;
      MapPoint newpoint = new MapPoint(LeftX, LeftY, RightX, RightY, MiddleX,
                                       MiddleY, RobotX, RobotY, RobotDir,
                                       RobotState);
      XYvector.add(newpoint);
			//done
      if (gui != null)
        gui.updateNumProcessedElements();
    }
  }
  
  /**
   *used to convert Cm to Xy point pixel variation
   * 
   * @param cm
   * @return
   */
  public static double CMtoXY(double cm) {
    return cm * (double)CMCONV;
  }

	/**
	 * used to convert time into xy point pixel variation
	 *  
	 * @param time
	 * @return
	 */
  public static double TIMEtoXY(double time) {
    return time*TIMECONV;
  }

	/**
	 * changes the direction the robot is facing
	 * 
	 * @param speedleft  the left wheel speed
	 * @param speedright  the right wheel speed
	 * @param time  the amount of time the wheels have turned at these speeds
	 * @return  returns the angle in rad that the robot is facing
	 */
  public double UpdateDir(double speedleft, double speedright, double time) {
    return (speedleft * time - speedright * time) / WHEELSPACING;
  }

	/**
	 * converts the serial data wheel speeds into cm/sec
	 * 
	 * @param currentpoint  the current serial data packet
	 * @param which  1 for the left wheel, else the right wheel
	 * @param time  never used 
	 * @return
	 */
  public double GetSpeed(SerialPacket currentpoint, int which, double time) {
    if (which == 1) { // left motor
      if (currentpoint.lmotor_dir == 0) {
        switch(currentpoint.lmotor_speed) {
          case 0: return 0;
          case 4: return LMSfslow;
          case 8: return LMSfmedium;
          case 12: return LMSffast;
          default: return 0;
        }
      }
      else {
        switch(currentpoint.lmotor_speed) {
          case 0: return 0;
          case 12: return LMSrfast;
          default: return 0;
        }
      }
    }
    else { // right motor
      if (currentpoint.rmotor_dir == 0) {
        switch(currentpoint.rmotor_speed) {
          case 0: return 0;
          case 4: return RMSfslow;
          case 8: return RMSfmedium;
          case 12: return RMSffast;
          default: return 0;
        }
      }
      else {
        switch(currentpoint.rmotor_speed) {
          case 0: return 0;
          case 12: return RMSrfast;
          //case 12: return -12.04; // original
          default: return 0;
        }
      }
    }

  }
  
  /**
   * clears all vectors
   *
   */
  public void ClearData()
  {
    myThread.suspend();
    XYvector = new Vector();
    index = 0;
    lastpoint = null;
    gui.mapscalingfactor = 1;
    zoomed = false;
    System.out.println("XY decoder data cleared.");
    myThread.resume();
  }

	/**
	 * gets the number of packets that have been decoded thus far
	 * 
	 * @return  returns the number of packets decodted thus far
	 */
  public int getNumPackets() {
    return XYvector.size();
  }

	/**
	 * draws the points in the display area
	 * 
	 * @param gfx  the display area
	 * @param width  the original x position of the display
	 * @param height  the original y position of the display
	 * @param showLeftIR  true if the Left IR data is to be displayed
	 * @param showMiddleIR true if the Middle IR data is to be displayed
	 * @param showRightIR true if the Right IR data is to be displayed
	 * @param markerindex  the current location of the robot
         * @param xoffset  the x offset used to recenter the map after a zoom
         * @param yoffset  the y offset used to recenter the map after a zoom
	 */
  public void DrawMap(Graphics gfx, int width, int height,
                      boolean showLeftIR, boolean showMiddleIR, boolean showRightIR, int markerindex,
                      float xoffset, float yoffset) {
    int i;
    double ThisIRLX, ThisIRLY, ThisIRMX, ThisIRMY, ThisIRRX, ThisIRRY, ThisRobotX, ThisRobotY;
    double robotsize;

    for (i = 0; i < XYvector.size(); i++) {
      ThisIRLX = (((MapPoint)XYvector.elementAt(i)).getLeftX() * gui.mapscalingfactor) + width/6 + (int)(xoffset * gui.mapscalingfactor);
      ThisIRLY = (((MapPoint)XYvector.elementAt(i)).getLeftY() * gui.mapscalingfactor) + height/2 + (int)(yoffset * gui.mapscalingfactor);
      ThisIRMX = (((MapPoint)XYvector.elementAt(i)).getMiddleX() * gui.mapscalingfactor) + width/6 + (int)(xoffset * gui.mapscalingfactor);
      ThisIRMY = (((MapPoint)XYvector.elementAt(i)).getMiddleY() * gui.mapscalingfactor) + height/2 + (int)(yoffset * gui.mapscalingfactor);
      ThisIRRX = (((MapPoint)XYvector.elementAt(i)).getRightX() * gui.mapscalingfactor) + width/6 + (int)(xoffset * gui.mapscalingfactor);
      ThisIRRY = (((MapPoint)XYvector.elementAt(i)).getRightY() * gui.mapscalingfactor) + height/2 + (int)(yoffset * gui.mapscalingfactor);
      ThisRobotX = (((MapPoint)XYvector.elementAt(i)).getRobotX() * gui.mapscalingfactor) + width/6 + (int)(xoffset * gui.mapscalingfactor);
      ThisRobotY = (((MapPoint)XYvector.elementAt(i)).getRobotY() * gui.mapscalingfactor) + height/2 + (int)(yoffset * gui.mapscalingfactor);

      //if (CheckOutOfBounds(ThisIRLX, ThisIRLY, ThisIRMX, ThisIRMY, ThisIRRX, ThisIRRY,
      //                     ThisRobotX, ThisRobotY,
      //                     width, height) && !zoomed) {
      //  gui.mapscalingfactor *= 0.8;
      //}

      if (i != 0) {
        if (showLeftIR) {
          gfx.setColor(Color.red);
          gfx.drawLine((int)ThisIRLX, (int)ThisIRLY, (int)ThisIRLX, (int)ThisIRLY);
        }

        if (showMiddleIR) {
          gfx.setColor(Color.blue);
          gfx.drawLine((int)ThisIRMX, (int)ThisIRMY, (int)ThisIRMX, (int)ThisIRMY);
        }

        if (showRightIR) {
          gfx.setColor(Color.green);
          gfx.drawLine((int)ThisIRRX, (int)ThisIRRY, (int)ThisIRRX, (int)ThisIRRY);
        }

        gfx.setColor(Color.white);
        gfx.drawLine((int)ThisRobotX, (int)ThisRobotY, (int)ThisRobotX, (int)ThisRobotY);

        if (i == markerindex) {
          gfx.setColor(Color.orange);
          robotsize = 20 * gui.mapscalingfactor;
          gfx.drawOval((int)(ThisRobotX - robotsize/2), (int)(ThisRobotY - robotsize/2), (int)robotsize, (int)robotsize);
        }
      }
    }
 }

	/**
	 * Checks if any points are out of bound,  is used to resize the map
         *
	 */
  private boolean CheckOutOfBounds(double a1, double a2, double b1, double b2, double c1, double c2, double d1, double d2, int w, int h) {
    if (a1 > w || a2 > h || b1 > w || b2 > h || c1 > w || c2 > h || d1 > w || d2 > h)
      return true;
    if (a1 < 0 || a2 < 0 || b1 < 0 || b2 < 0 || c1 < 0 || c2 < 0 || d1 < 0 || d2 < 0)
      return true;

    return false;
  }

	/**
	 * shrinks the map by half
	 *
	 */
  public void ZoomOut() {
    gui.mapscalingfactor *= 0.5;
    zoomed = true;
  }

	/**
	 * makes the map twice as big
	 *
	 */
  public void ZoomIn() {
    gui.mapscalingfactor *= 1/0.5;
    zoomed = true;
  }


	/**
	 * alows outside classes to access the xyvector
	 * 
	 * @return returns the XYvector
	 */
  public Vector getXYVector() {
    return XYvector;
  }

}
