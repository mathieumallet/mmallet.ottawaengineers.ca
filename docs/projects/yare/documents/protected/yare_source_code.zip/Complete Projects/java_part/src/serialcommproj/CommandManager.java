package serialcommproj;

import java.util.Vector;

/**
 * <p>Title: CommandManager</p>
 * <p>Description: Class used to queue commands to the robot, send them and ensure that they are received.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Fourth Year Project Group MSW1 - Class of September 2003</p>
 * @author Mathieu Mallet
 * @version 1.0
 */

public class CommandManager {
  static private int WaitingForCommandState = 15;

  MainGUI gui;
  SerialReceiver receiver;
  SerialDecoder decoder;
  Vector commandQueue;
  SerialPacket lastPacket;

  boolean bCommandSent = false;
  boolean bPaused = false;
  boolean bShouldResent = false;
  public boolean bCommandProcessorRunning = false;

  int packetCounter = 0;
  int currentCommand = -1;
  int numResends = 0;
  private int lastState;

	/**
	 * Constructor for objects of class CommandManager.
	 * @param gui Reference to the MainGUI object.
	 * @param receiver Reference to the SerialReceiver object.
	 */
  public CommandManager(MainGUI gui, SerialReceiver receiver) {
    this.gui = gui;
    this.receiver = receiver;
  }

	/**
	 * Clears all queued commands and stops any outgoing commands.
	 * @param receiver New reference to the SerialReceiver object.
	 * @param decoder New reference to the SerialDecoder object.
	 */
  public void ClearData(SerialReceiver receiver, SerialDecoder decoder) {
    bPaused = true;
    this.receiver = receiver;
    this.decoder = decoder;
    if (decoder != null)
      decoder.UnsetCommandManager();
    bCommandProcessorRunning = false;
    commandQueue = new Vector();
    bCommandSent = false;
    bPaused = false;
    bShouldResent = false;
    packetCounter = 0;
    currentCommand= -1;
    lastState = -1;
    numResends = 0;
    System.out.println("Command Manager data cleared.");
  }

	/**
	 * Adds a command to the command queue.
	 * @param command String reference of the command, in 'short command' syntax.
	 */
  public void addCommand(String command) {
    if (command.substring(0,2) == "//")
      return; // do not add 'comment' commands

    if (command == "followright")
      commandQueue.add(new Integer(2));
    else if (command == "clearwall")
      commandQueue.add(new Integer(3));
    else if (command == "turnright") // turn 90 degrees clockwize
      commandQueue.add(new Integer(4));
    else if (command == "findrightwall")
      commandQueue.add(new Integer(5));
    else if (command == "turnleft") // turn 90 degrees counter-clockwize
      commandQueue.add(new Integer(6));
    else if (command == "followleft")
      commandQueue.add(new Integer(7));
    else if (command == "findleftwall")
      commandQueue.add(new Integer(8));
    else if (command == "findfrontwall")
      commandQueue.add(new Integer(9));
    else if (command == "gotoautonomous")
      commandQueue.add(new Integer(10));
    else
      System.out.println("Unknown command found: " + command);

  }

	/**
	 * Adds a command to the command queue.
	 * @param command Integer representation of the command to be send. These are the actual data that is sent to the robot.
	 */
  public void addCommand(int command) {
    commandQueue.add(new Integer(command));
  }

	/**
	 * Sends all command in the command queue to the robot, one after an other.
	 *
	 */
  public void ExecuteCommandList() {
    if (receiver == null) {
      System.out.println("ERROR: RF communications required to control robot");
      return;
    }

    if (bCommandProcessorRunning == true)
      return;

    bCommandProcessorRunning = true;
    ProcessCommand();
  }

	/**
	 * Called to update the reference to the SerialReceiver.
	 * @param receiver New reference to the SerialReceiver object.
	 */
  public void UpdateReceiver(SerialReceiver receiver) {
    this.receiver = receiver;
  }

	/**
	 * Abort execution of command queue.
	 *
	 */
  public void AbortExecution() {
    if (decoder != null)
      decoder.UnsetCommandManager();
    bCommandProcessorRunning = false;
    if (gui.bApplyingPath) {
      gui.bApplyingPath = false;
      gui.StopRF();
      gui.ResetApplyingPathButton();
    }
    gui.SetCommandQueueText("No commands in queue.");
  }

	/**
	 * Try to send the first command in the command queue.
	 *
	 */
  private void ProcessCommand() {
    int command;
    if (commandQueue.size() == 0)  {
      System.out.println("No commands left in command queue.");
      AbortExecution();
      return;
    }

    command = ((Integer)commandQueue.firstElement()).intValue();
    commandQueue.remove(0);

    System.out.println("Sending command " + String.valueOf(command) + " (" + gui.getStateName(command) + ")");

    if (gui != null)
      gui.SetCommandQueueText("Sending '" + gui.GetCommandShortName(command) + "'");

    currentCommand = command;
    SendCommand();

  }

	/**
	 * Sends a specific command to the SerialReceiver.
	 *
	 */
  private void SendCommand() {
    receiver.sendMessage(currentCommand,0);
  }

	/**
	 * Called by the SerialReceiver object: checks if the robot has executed the sent command. If not, resend the command. 
	 * @param p Last received SerialPacket object.
	 */
  public void CheckCommand(SerialPacket p) {
    // handle bumper hits
    if (p.bumperl || p.bumperr) {
      AbortExecution();
      return;
    }

    if (!bCommandSent) {
      if (!MainGUI.IsWaitingState(p.system_state) ||
          (lastState == 0x20 && lastState != p.system_state && numResends > 10)) { // robot changed states!
        if (gui != null)
          gui.SetCommandQueueText("Waiting for completion ('" + gui.GetCommandShortName(currentCommand) + "')");
        bCommandSent = true;
        numResends = 0;
      }
      else {
        // hmm.. check if we should send the command again
        packetCounter++;
        if (packetCounter == 2) {
          packetCounter = 0;
          System.out.println("Resending command...");
          numResends++;
          if (gui != null)
            gui.SetCommandQueueText("Resending '" + gui.GetCommandShortName(currentCommand) + "' (" + String.valueOf(numResends) + " resends)");
          SendCommand();
        }
      }
    }
    else if (bCommandSent && MainGUI.IsWaitingState(p.system_state)) { // robot is back to waiting for command
      bCommandSent = false;
      lastState = -1;
      ProcessCommand(); // process next command
    }

    lastState = p.system_state;

    if (numResends == 100) {
      System.out.println("Too many command retries -- abort.");
      AbortExecution();
      if (gui != null)
        gui.showError("Error: robot did not respond to command '" + gui.GetCommandShortName(currentCommand) +"'");
    }

  }



}